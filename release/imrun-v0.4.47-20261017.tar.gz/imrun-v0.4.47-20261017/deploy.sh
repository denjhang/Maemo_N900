#!/bin/bash
# IMRUN 部署脚本  用法: ./deploy.sh <N900_IP> [ssh_password]
set -e
IP="${1:?用法: $0 <N900_IP> [password]}"
PASS="${2:-123456}"
SSH="sshpass -p $PASS ssh -o StrictHostKeyChecking=no root@$IP"
SCP="sshpass -p $PASS scp -o StrictHostKeyChecking=no"

echo "=== 部署 IMRUN $IP ==="
$SSH 'killall -9 gldemo_imguibin_export; sleep 1' || true

echo "上传主程序..."
$SCP bin/gldemo_imguibin "root@$IP:/home/user/gldemo_imguibin_export"
$SSH 'chmod +x /home/user/gldemo_imguibin_export'

echo "上传插件..."
for p in demo vgmplayer appmgr system; do
    $SCP "plugins/$p.so" "root@$IP:/home/user/imrun/apps/$p/app.so"
done

echo "上传 Flappy Bird + 素材..."
$SSH 'mkdir -p /home/user/imrun/apps/flappy/assets'
$SCP plugins/flappy.so "root@$IP:/home/user/imrun/apps/flappy/app.so"
$SCP plugins/flappy_assets/*.png "root@$IP:/home/user/imrun/apps/flappy/assets/"

echo "启动..."
$SSH "date -s @$(date +%s); export DISPLAY=:0 && nohup /home/user/gldemo_imguibin_export > /tmp/imrun.log 2>&1 &"
sleep 3

echo ""
echo "=== 状态 ==="
$SSH 'pidof gldemo_imguibin_export && echo "✓ 运行中" || echo "✗ 未启动"'
$SSH 'grep BOOTORDER /home/user/audio_dbg.log | tail -1'
echo "部署完成"
