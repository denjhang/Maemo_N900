# IMRUN Release v0.4.47

Nokia N900 ImGui 运行时 + 插件系统（含 PNG 纹理支持与 Flappy Bird）

## 版本信息
- **版本**: v0.4.47
- **架构**: ARM (Nokia N900 / Maemo 5)
- **主程序**: ImGui 1.92.8 docking + GLES1.1

## 本版新增（相对 v0.4.46r）

### PNG 纹理支持
- 主程序集成 stb_image，新增 API：
  - `imrun_load_png(path)` — 解码 PNG 为纹理
  - `imrun_register_texture(tex)` — 注册（上传由渲染循环完成）
- 插件可加载外部 PNG 素材并绘制

### Flappy Bird 游戏（示例插件）
- 原版素材纹理（背景/管道/小鸟）
- 小窗口模式，不遮挡任务栏
- 空格跳跃

## 本版修复的三个渲染 bug

1. **符号扩展**：GL 纹理 ID ≥ 2^31 时 `(intptr_t)` 转换符号扩展成无效值 → 改用零扩展
2. **宿主窗口契约**：插件必须画进宿主窗口，不能自己 `ImGui::Begin/End`
3. **NPOT 纹理**：N900 PowerVR SGX530 不支持非二次幂纹理 → 上传时放大到 POT

详见 `docs/FLAPPY_TEXTURE_DEBUG_NOTES.md`。

## 包含内容

### 主程序
- `bin/gldemo_imguibin` — IMRUN 主程序（~1.4MB）

### 插件
- `plugins/demo.so` — 演示应用
- `plugins/vgmplayer.so` — VGM 音乐播放器
- `plugins/appmgr.so` — 应用管理器
- `plugins/system.so` — 系统设置
- `plugins/flappy.so` + `plugins/flappy_assets/` — Flappy Bird + 纹理素材

### 文档
- `docs/BUILD_GUIDE.md` — 编译指南
- `docs/FLAPPY_TEXTURE_DEBUG_NOTES.md` — 纹理调试手记
- `docs/SESSION_20261017.md` — 会话记录

## 部署

```bash
./deploy.sh 192.168.101.108          # 需要 sshpass
```

## 验证

```bash
ssh root@192.168.101.108 'pidof gldemo_imguibin_export'
ssh root@192.168.101.108 'grep BOOTORDER /home/user/audio_dbg.log | tail -1'
# 应显示：BOOTORDER order_n=5 dyn_n=5
```

## 目标设备
- Nokia N900 / Maemo 5 (Fremantle)
- ARM Cortex-A8 600MHz / PowerVR SGX530 / 256MB RAM

## 更新日志

### v0.4.47
- PNG 纹理加载系统
- Flappy Bird 示例插件
- 修复 3 个渲染 bug（符号扩展 / 宿主窗口 / NPOT）
- 新增 framebuffer 截图自动验证脚本

### v0.4.46r
- PULSE 后端完整实现
- 系统音量实时响应
