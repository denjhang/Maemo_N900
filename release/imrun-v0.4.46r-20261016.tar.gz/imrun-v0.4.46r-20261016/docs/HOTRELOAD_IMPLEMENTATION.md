# IMRUN 插件热重载实现笔记

## 事故回顾：为什么只有一个应用图标？

### 根本原因
**主程序编译时缺少 `-Wl,--export-dynamic` 链接选项**，导致所有插件 dlopen 时因 `undefined symbol` 失败。

### 详细分析

#### 1. 插件加载失败的具体原因

插件 `.so` 文件在 dlopen 时需要访问主程序中的符号：

```
demo.so        需要: audio_wave, audio_amp, audio_start 等音频控制符号
system.so      需要: audio_wave, audio_amp 等音频控制符号  
vgmplayer.so   需要: audio_source_fn, audio_start 等音频接口
appmgr.so      需要: ImGui::TableSetColumnIndex 等 ImGui 符号
```

**没有 `--export-dynamic` 时：**
- 主程序的符号表是私有的，插件无法访问
- dlopen 失败并返回 "undefined symbol: xxx"
- dyn_scan() 中的 `if (!h) continue;` 静默跳过失败的插件
- 结果：只加载成功的插件（碰巧某个插件不需要主程序符号，或者所有插件都失败）

#### 2. 为什么之前没有这个问题？

检查发现：**旧的工作版本也没有 `--export-dynamic`**，但能正常加载所有插件。

**可能的原因：**
1. 旧版本二进制是用不同的编译选项生成的（可能有其他导出机制）
2. 或者旧版本的插件依赖较少，恰好能工作

**本次修改导致问题暴露：**
- 重新编译主程序时，链接器默认不导出符号
- 所有插件 dlopen 全部失败
- 只显示一个图标（可能是某个不依赖主程序符号的插件，或者压根没加载成功任何插件）

#### 3. 调试过程中的错误

**错误做法：**
```bash
# 直接通过 SSH 启动（没有 DISPLAY 环境变量）
ssh root@192.168.101.108 '/home/user/gldemo_imguibin'
# 结果：XOpenDisplay FAIL，无法启动
```

**错误做法2：**
```bash
# 恢复旧版本后用错误方式启动
nohup /home/user/gldemo_imguibin > /dev/null 2>&1 &
# 结果：没有 DISPLAY=:0，X11 连接失败
```

### 解决方案

#### 1. 修复主程序链接选项

**文件：** `build/b_imgui_hotreload.sh`

```bash
arm-linux-gnueabi-g++ --sysroot=$S -nostartfiles -nodefaultlibs \
    -Wl,--dynamic-linker,/lib/ld-linux.so.3 \
    -Wl,--export-dynamic \    # <-- 关键：导出主程序符号供插件使用
    /tmp/gi.o /tmp/ap.o /tmp/ig.o /tmp/imgui.o /tmp/imgui_draw.o /tmp/imgui_tables.o /tmp/imgui_widgets.o /tmp/imgui_demo.o \
    $S/usr/lib/libstdc++.so.6 ./libdl.so.2 -lm -lgcc -lgcc_s -lc \
    -o gldemo_imguibin
```

**作用：**
- 强制链接器将主程序的全局符号导出到动态符号表
- 插件 dlopen 时可以访问这些符号
- 类似于 `-rdynamic` 选项

#### 2. 添加调试日志

**文件：** `build/imgui_gles1.cpp` 中的 `dyn_scan()` 函数

```cpp
static void dyn_scan(void) {
    DIR *d = opendir(APPS_DIR);
    if (!d) { alog_public("DYN_SCAN: opendir FAIL %s", APPS_DIR); return; }
    
    struct dirent *e;
    while ((e = readdir(d)) && g_dyn_n < 8) {
        if (e->d_name[0] == '.') continue;
        
        // ... 省略去重检查 ...
        
        char so[128];
        snprintf(so, sizeof so, APPS_DIR "/%s/app.so", e->d_name);
        void *h = dlopen(so, RTLD_NOW);
        if (!h) {
            // 记录 dlopen 失败原因
            alog_public("DYN_SCAN: dlopen FAIL %s: %s", e->d_name, dlerror());
            continue;
        }
        
        void (*frame)(double) = (void (*)(double))dlsym(h, "imapp_frame");
        if (!frame) {
            alog_public("DYN_SCAN: no imapp_frame %s", e->d_name);
            dlclose(h);
            continue;
        }
        
        // ... 加载成功 ...
        alog_public("DYN_SCAN: loaded %s (%s)", e->d_name, a.name);
    }
    closedir(d);
    alog_public("DYN_SCAN: total=%d plugins", g_dyn_n);
}
```

**修复前的日志：**
```
[     2.089] DYN_SCAN: dlopen FAIL demo: undefined symbol: audio_wave
[     2.090] DYN_SCAN: dlopen FAIL vgmplayer: undefined symbol: audio_source_fn
[     2.090] DYN_SCAN: dlopen FAIL appmgr: undefined symbol: _ZN5ImGui19TableSetColumnIndexEi
[     2.091] DYN_SCAN: dlopen FAIL system: undefined symbol: audio_wave
[     2.092] DYN_SCAN: total=0 plugins
```

**修复后的日志：**
```
[     1.301] DYN_SCAN: loaded demo (DEMO)
[     1.303] DYN_SCAN: loaded vgmplayer (VGM)
[     1.304] DYN_SCAN: loaded appmgr (APPMGR)
[     1.304] DYN_SCAN: loaded system (SETTINGS)
[     1.305] DYN_SCAN: total=4 plugins
```

## 正确的部署方法

### 方法1：使用 Python 脚本（推荐）

**文件：** `build/run_hotreload.py`

```python
#!/usr/bin/env python3
import paramiko
import time

c = paramiko.SSHClient()
c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('192.168.101.108', username='root', password='123456',
          allow_agent=False, look_for_keys=False)

# 1. 时间同步（N900 没有 RTC 电池，时钟会重置到 2009）
i, o, e = c.exec_command('date -s @%d; date' % int(time.time()))
o.channel.settimeout(15)
try:
    print('TIMESYNC:', o.read().decode().strip())
except Exception:
    pass

# 2. 停止旧进程
print("停止旧进程...")
i, o, e = c.exec_command('killall gldemo_imguibin; sleep 1')
o.read()

# 3. 上传文件
print("上传新版本...")
sftp = c.open_sftp()
sftp.put('gldemo_imguibin', '/home/user/gldemo_imguibin')
sftp.put('appmgr_hotreload.so', '/home/user/imrun/apps/appmgr/app.so')
sftp.close()

i, o, e = c.exec_command('chmod +x /home/user/gldemo_imguibin')
o.read()

# 4. 启动新版本（关键：必须设置 DISPLAY=:0）
print("启动新版本...")
i, o, e = c.exec_command(
    'rm -f /tmp/imrun.lock; '
    'export DISPLAY=:0 && '
    'nohup /home/user/gldemo_imguibin > /tmp/imrun.log 2>&1 & '
    'sleep 2; pidof gldemo_imguibin'
)
o.channel.settimeout(15)
try:
    pid = o.read().decode().strip()
    print(f"PID: {pid}")
    if pid:
        print("✓ 启动成功！")
    else:
        print("✗ 启动失败")
        i2, o2, e2 = c.exec_command('tail -20 /tmp/imrun.log')
        print(o2.read().decode())
except Exception as ex:
    print(f"超时或错误: {ex}")

c.close()
```

**使用：**
```bash
cd /mnt/e/working/zcode-projects/Maemo_N900/build
python run_hotreload.py
```

### 方法2：手动 SSH 命令

```bash
# 连接设备
ssh root@192.168.101.108  # 密码: 123456

# 停止旧进程
killall gldemo_imguibin

# 从开发机上传文件（在开发机上执行）
scp build/gldemo_imguibin root@192.168.101.108:/home/user/
scp build/appmgr.so root@192.168.101.108:/home/user/imrun/apps/appmgr/app.so

# 启动新版本（在 N900 上执行，关键是 DISPLAY=:0）
rm -f /tmp/imrun.lock
export DISPLAY=:0
nohup /home/user/gldemo_imguibin > /tmp/imrun.log 2>&1 &

# 检查是否启动成功
pidof gldemo_imguibin

# 查看启动日志
tail -f /home/user/audio_dbg.log
```

### 关键要点

1. **必须设置 `DISPLAY=:0`**
   - N900 的 X11 服务器运行在 `:0` 显示
   - 没有这个环境变量，XOpenDisplay 会失败

2. **必须用 `nohup` 或后台运行**
   - SSH 连接断开时不会杀死进程
   - 输出重定向到文件，避免挂起

3. **删除 `/tmp/imrun.lock`**
   - imrun 有单实例检查
   - 旧进程崩溃可能留下锁文件

4. **编译时必须有 `--export-dynamic`**
   - 否则插件无法加载
   - 检查方法：`grep export-dynamic build/b_imgui_hotreload.sh`

## 热重载功能实现

### 核心函数

**文件：** `build/imgui_gles1.cpp`

```cpp
extern "C" int imrun_dyn_reload(int i) {
    if (i < 0 || i >= g_dyn_n) return -1;
    DynApp &a = g_dyn[i];
    
    /* 1. 保存状态 */
    bool was_open = a.open;
    bool was_mini = a.mini;
    int was_focus = (g_focus == i);
    char id_copy[40], name_copy[40];
    snprintf(id_copy, sizeof id_copy, "%s", a.id);
    snprintf(name_copy, sizeof name_copy, "%s", a.name);
    
    /* 2. 销毁旧实例 */
    if (a.destroy && !a.destroyed) {
        a.destroy();
        a.destroyed = true;
    }
    
    /* 3. dlclose 卸载旧 .so */
    if (a.h) {
        dlclose(a.h);
        a.h = NULL;
    }
    
    /* 4. dlopen 加载新 .so */
    char so[128];
    snprintf(so, sizeof so, APPS_DIR "/%s/app.so", id_copy);
    void *h = dlopen(so, RTLD_NOW);
    if (!h) {
        alog_public("RELOAD FAILED di=%d id=%s err=%s", i, id_copy, dlerror());
        return -2;
    }
    
    /* 5. 解析新符号 */
    void (*frame)(double) = (void (*)(double))dlsym(h, "imapp_frame");
    if (!frame) {
        dlclose(h);
        alog_public("RELOAD FAILED di=%d id=%s no_imapp_frame", i, id_copy);
        return -3;
    }
    
    /* 6. 更新插件槽 */
    a.h = h;
    a.frame = frame;
    a.init = (int (*)(void))dlsym(h, "imapp_init");
    a.destroy = (void (*)(void))dlsym(h, "imapp_destroy");
    a.icon = (void (*)(void *, float, float, float))dlsym(h, "imapp_icon");
    a.sys = (int (*)(void))dlsym(h, "imapp_system");
    
    /* 7. 重新初始化 */
    a.destroyed = false;
    if (a.init) a.init();
    
    /* 8. 恢复名称 */
    const char *(*nm)(void) = (const char *(*)(void))dlsym(h, "imapp_name");
    snprintf(a.name, sizeof a.name, "%s", nm ? nm() : id_copy);
    
    /* 9. 恢复状态 */
    a.open = was_open;
    a.mini = was_mini;
    if (was_focus) g_focus = i;
    
    /* 10. 清除动画状态 */
    a.closing = false;
    a.mfade = false;
    a.fade_k = 1.0f;
    a.fade_end = false;
    
    alog_public("RELOAD OK di=%d id=%s name=%s open=%d", i, id_copy, a.name, a.open);
    return 0;
}
```

### 使用方法

**在 APPMGR 插件中：**

```cpp
// MANAGE 标签页
if (ImGui::Button("REFRESH", ImVec2(100, 30))) {
    /* 热重载所有插件 */
    for (int k = 0; k < n; k++) {
        int ret = imrun_dyn_reload(k);
        if (ret != 0) {
            /* 某个插件重载失败，回退到扫描新插件 */
            imrun_host_rescan();
            break;
        }
    }
}
```

**开发工作流：**

1. 修改插件源码（如 `research/apps/vgmplayer/vgm.cpp`）
2. 编译插件：
   ```bash
   wsl bash -c "
   cd /tmp
   S=/opt/sysroot
   arm-linux-gnueabi-g++ --sysroot=\$S -O2 -fPIC -shared -nostdlib \
       -I/mnt/e/working/zcode-projects/Maemo_N900/build \
       -I/mnt/e/working/zcode-projects/Maemo_N900/build/imgui \
       /mnt/e/working/zcode-projects/Maemo_N900/research/apps/vgmplayer/vgm.cpp \
       -o vgmplayer.so
   "
   ```
3. 上传到 N900：
   ```bash
   wsl scp /tmp/vgmplayer.so root@192.168.101.108:/home/user/imrun/apps/vgmplayer/app.so
   ```
4. 在 imrun 中打开 APPMGR → MANAGE，点击 **REFRESH** 按钮
5. 插件热重载完成，无需重启主程序

## 经验教训

### ❌ 不要做的事

1. **不要假设旧代码能工作就直接复制**
   - 每次修改后必须测试
   - 编译选项可能影响运行时行为

2. **不要静默忽略错误**
   - dlopen 失败必须记录日志
   - 用户看不到的错误 = 无法调试

3. **不要通过 SSH 直接启动 GUI 程序**
   - 必须设置 DISPLAY 环境变量
   - 使用 nohup 避免 SSH 断开时进程被杀

4. **不要盲目恢复备份**
   - 先理解问题原因
   - 备份可能也有同样的问题

### ✅ 应该做的事

1. **编译时导出符号**
   - 主程序使用 `-Wl,--export-dynamic`
   - 插件可以访问主程序的符号

2. **添加详细日志**
   - 每个关键步骤都记录
   - 失败时输出 dlerror()

3. **使用自动化脚本**
   - Python + paramiko 处理部署
   - 避免手动操作出错

4. **测试完整流程**
   - 每次修改后完整测试
   - 检查所有插件是否加载

## 检查清单

部署新版本前：

- [ ] 编译脚本包含 `-Wl,--export-dynamic`
- [ ] 所有插件源码已更新
- [ ] 启动命令包含 `export DISPLAY=:0`
- [ ] 删除旧的锁文件 `/tmp/imrun.lock`
- [ ] 检查日志确认所有插件加载成功
- [ ] 测试热重载功能（APPMGR REFRESH）

---

**日期：** 2026-10-16  
**版本：** IMRUN v0.4 with hot reload support  
**MD5：** 3df3cbcc885e3f2f7fc0667eb544d6b4
