# IMRUN Release

Nokia N900 ImGui 运行时环境 + 插件系统

## 版本信息

- **版本**: v0.4.46r
- **编译日期**: 2026-10-16
- **架构**: ARM (N900)

## 包含内容

### 主程序
- `bin/gldemo_imguibin` - IMRUN 主程序 (~1.4MB)
  - ImGui 1.92.8 docking 分支
  - GLES1.1 渲染后端
  - 4音频后端（SDL/ALSA/AO/PULSE）
  - 插件热重载系统

### 插件
- `plugins/demo.so` - 演示应用（音频测试/振动/按键/字体）
- `plugins/vgmplayer.so` - VGM 音乐播放器
- `plugins/appmgr.so` - 应用管理器
- `plugins/system.so` - 系统设置

### 文档
- `docs/BUILD_GUIDE.md` - 完整编译指南
- `docs/HOTRELOAD_IMPLEMENTATION.md` - 热重载实现
- `docs/PULSE_BACKEND_IMPLEMENTATION.md` - 音频后端架构

## 快速部署

### 方法1：使用部署脚本（需要 sshpass）
```bash
./deploy.sh 192.168.101.108
```

### 方法2：手动部署
```bash
# 上传主程序
scp bin/gldemo_imguibin root@192.168.101.108:/home/user/gldemo_imguibin_export
ssh root@192.168.101.108 'chmod +x /home/user/gldemo_imguibin_export'

# 上传插件
scp plugins/demo.so root@192.168.101.108:/home/user/imrun/apps/demo/app.so
scp plugins/vgmplayer.so root@192.168.101.108:/home/user/imrun/apps/vgmplayer/app.so
scp plugins/appmgr.so root@192.168.101.108:/home/user/imrun/apps/appmgr/app.so
scp plugins/system.so root@192.168.101.108:/home/user/imrun/apps/system/app.so

# 启动
ssh root@192.168.101.108 'export DISPLAY=:0 && /home/user/gldemo_imguibin_export &'
```

## 验证

```bash
# 检查进程
ssh root@192.168.101.108 'pidof gldemo_imguibin_export'

# 检查日志
ssh root@192.168.101.108 'tail -20 /home/user/audio_dbg.log'

# 应该看到
[     1.xxx] BOOTORDER order_n=4 dyn_n=4
```

## 目标设备

- **设备**: Nokia N900
- **OS**: Maemo 5 (Fremantle)
- **CPU**: ARM Cortex-A8 600MHz
- **GPU**: PowerVR SGX530
- **RAM**: 256MB

## 功能特性

### 音频系统
- ✅ 4后端并存（SDL/plughw、PULSE、ALSA、libao）
- ✅ 系统音量实时响应
- ✅ 48000Hz 零重采样
- ✅ 无断流稳定播放

### 插件系统
- ✅ 热重载（无需重启主程序）
- ✅ 独立编译、独立更新
- ✅ 用户可安装自定义插件

### UI
- ✅ ImGui 停靠布局
- ✅ 触摸屏优化
- ✅ 最小化/恢复动画
- ✅ 任务栏管理

## 已知问题

- 无

## 更新日志

### v0.4.46r (2026-10-16)
- PULSE 后端完整实现
- 系统音量实时响应
- 4后端全通过测试

## 技术支持

详细文档请参阅 `docs/` 目录。
