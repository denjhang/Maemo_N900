#!/bin/bash
# IMRUN 部署脚本
# 使用方法: ./deploy.sh <N900_IP>

if [ -z "$1" ]; then
    echo "用法: $0 <N900_IP>"
    echo "示例: $0 192.168.101.108"
    exit 1
fi

N900_IP=$1
N900_USER=root
N900_PASS=123456

echo "=== 部署 IMRUN 到 N900 ($N900_IP) ==="

# 停止运行中的进程
sshpass -p $N900_PASS ssh ${N900_USER}@${N900_IP} 'killall -9 gldemo_imguibin_export; sleep 1'

# 上传主程序
echo "上传主程序..."
sshpass -p $N900_PASS scp bin/gldemo_imguibin ${N900_USER}@${N900_IP}:/home/user/gldemo_imguibin_export
sshpass -p $N900_PASS ssh ${N900_USER}@${N900_IP} 'chmod +x /home/user/gldemo_imguibin_export'

# 上传插件
echo "上传插件..."
sshpass -p $N900_PASS scp plugins/demo.so ${N900_USER}@${N900_IP}:/home/user/imrun/apps/demo/app.so
sshpass -p $N900_PASS scp plugins/vgmplayer.so ${N900_USER}@${N900_IP}:/home/user/imrun/apps/vgmplayer/app.so
sshpass -p $N900_PASS scp plugins/appmgr.so ${N900_USER}@${N900_IP}:/home/user/imrun/apps/appmgr/app.so
sshpass -p $N900_PASS scp plugins/system.so ${N900_USER}@${N900_IP}:/home/user/imrun/apps/system/app.so

# 启动
echo "启动 IMRUN..."
sshpass -p $N900_PASS ssh ${N900_USER}@${N900_IP} "date -s @$(date +%s); export DISPLAY=:0 && nohup /home/user/gldemo_imguibin_export > /tmp/imrun.log 2>&1 &"

sleep 3

# 检查状态
echo ""
echo "=== 检查状态 ==="
sshpass -p $N900_PASS ssh ${N900_USER}@${N900_IP} 'pidof gldemo_imguibin_export && echo "✓ IMRUN 运行中" || echo "✗ IMRUN 未启动"'
sshpass -p $N900_PASS ssh ${N900_USER}@${N900_IP} 'grep BOOTORDER /home/user/audio_dbg.log | tail -1'

echo ""
echo "部署完成！"
