HTTPS video streaming support patch for Belle Refresh, FP1, FP2
v2026.05.04

Use X-Plore with enabled Open4All patch.

1. Install playbackhelper.sis.
2. Copy httpfsys.dll and hxnetwksvc.dll to C:\sys\bin
3. Reboot

Troubleshooting:
If installation fails with message "Component is built-in",
then use "RunInstallServerNotForRom" patch instead of "Install Server RP+" and try again.
If you don't have it, look into "ynstallserver", copy RunInstallServerNotForRom.rmp to C:\patches, and ynstallserver.exe to C:\sys\bin

On some Belle FP2 devices (e.g, 603, 808) it requires c2z4bin patch with DomainSrv to work,
If you don't have it, look at readme.txt in "domainsrv_fp2" (not required for Delight), and copy c2z4bin_THUMB_Belle.rmp to C:\patches

If https playback still doesn't work, make sure you have latest TLS patch from https://nnproject.cc/tls,
and you have set correct access point in video settings (usually Settings>Application settings>Videos>Access point in use).

If it does not work for one specific server, that means it requires SNI, it is not supported by this patch.

Use at your own risk.
Check https://nnproject.cc/bellehttpsplayer/ for updates
