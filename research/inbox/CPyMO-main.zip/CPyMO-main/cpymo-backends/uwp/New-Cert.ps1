$cert = New-SelfSignedCertificate -Type Custom -KeyUsage DigitalSignature -CertStoreLocation "Cert:\CurrentUser\My" -TextExtension @("2.5.29.37={text}1.3.6.1.5.5.7.3.3", "2.5.29.19={text}") -Subject "CN=CPyMO, O=CPyMO, C=US" -FriendlyName "CPyMO"
$password = ConvertTo-SecureString -String "12345" -Force -AsPlainText
Export-PfxCertificate -cert "Cert:\CurrentUser\My\$($cert.Thumbprint)" -FilePath cert.pfx -Password $password
echo "Cert refreshed, thumbprint:"
echo $($cert.Thumbprint)
