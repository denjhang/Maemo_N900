﻿#include "cpymo_prelude.h"
#include "cpymo_movie.h"
#include "cpymo_engine.h"

#ifdef __CXX
#undef av_err2str
#define av_err2str(X) ""
#endif

#ifdef DISABLE_MOVIE
#define DISABLE_FFMPEG_MOVIE
#endif

#ifndef DISABLE_FFMPEG_MOVIE
#include <assert.h>
#include "../cpymo-backends/include/cpymo_backend_movie.h"

#ifdef __CXX
extern "C" {
#endif

#include <libavformat/avformat.h>
#include <libavcodec/avcodec.h>

#ifdef __CXX
}
#endif

typedef struct {
	#ifdef DONT_PASS_PATH_TO_FFMPEG
		cpymo_package_stream_reader stream_reader;
		AVIOContext *io_context;
	#endif

	AVFormatContext *format_context;
	int video_stream_index;

	AVCodecContext *video_codec_context;

	AVPacket *packet;
	AVFrame *video_frame;

	bool no_more_content;
	bool backend_inited;
	bool skip_pressed;

	float current_time;
	float video_current_frame_time;

	char *current_bgm_name;
} cpymo_movie;

static error_t cpymo_movie_send_packets(cpymo_movie *m)
{
	RETRY:
	if (m->no_more_content) return CPYMO_ERR_NO_MORE_CONTENT;

	int err = av_read_frame(m->format_context, m->packet);
	if (err == AVERROR_EOF) {
		m->no_more_content = true;

		err = avcodec_send_packet(m->video_codec_context, NULL);
		if (err < 0) {
			printf("[Error] Could not flush audio codec: %s.\n", av_err2str(err));
		}

		if (err < 0) {
			return CPYMO_ERR_UNKNOWN;
		}
	}
	else if (err == 0) {
		if (m->packet->stream_index == m->video_stream_index) {
			err = avcodec_send_packet(m->video_codec_context, m->packet);
			av_packet_unref(m->packet);
		}
		else {
			av_packet_unref(m->packet);
			goto RETRY;
		}

		if (err < 0) {
			printf("[Error] Can not send packet to codec: %s.\n", av_err2str(err));
			return CPYMO_ERR_UNKNOWN;
		}
	}
	else {
		printf("[Error] Could not read packet: %s.\n", av_err2str(err));
		return CPYMO_ERR_UNKNOWN;
	}
	
	return CPYMO_ERR_SUCC;
}

static error_t cpymo_movie_send_video_frame_to_backend(cpymo_movie *m)
{
RETRY: {
	int err = avcodec_receive_frame(m->video_codec_context, m->video_frame);
	if (err == 0) {
		switch (m->video_frame->format) {
		case AV_PIX_FMT_YUV420P:
		case AV_PIX_FMT_YUV422P:
		case AV_PIX_FMT_YUV420P16:
		case AV_PIX_FMT_YUV422P16:
			cpymo_backend_movie_update_yuv_surface(
				m->video_frame->data[0],
				(size_t)m->video_frame->linesize[0],
				m->video_frame->data[1],
				(size_t)m->video_frame->linesize[1],
				m->video_frame->data[2],
				(size_t)m->video_frame->linesize[2]
			);
			break;
		case AV_PIX_FMT_YUYV422:
			cpymo_backend_movie_update_yuyv_surface(
				m->video_frame->data[0],
				(size_t)m->video_frame->linesize[0]
			);
		default: assert(false);
		};

		m->video_current_frame_time =
			(float)
			(m->video_frame->best_effort_timestamp
				* av_q2d(m->format_context->streams[m->video_stream_index]->time_base));

		av_frame_unref(m->video_frame);

		if (m->video_current_frame_time < m->current_time)
			goto RETRY;

		return CPYMO_ERR_SUCC;
	}
	else if (err == AVERROR(EAGAIN)) {
		error_t err = cpymo_movie_send_packets(m);
		if (err == CPYMO_ERR_NO_MORE_CONTENT) return CPYMO_ERR_NO_MORE_CONTENT;
		else if (err == CPYMO_ERR_SUCC) { goto RETRY; }
		else {
			printf("[Error] Failed to request more frames.\n");
			goto RETRY;
		}
	}
	else if (err == AVERROR_EOF) { return CPYMO_ERR_NO_MORE_CONTENT; }
	else {
		printf("[Error] Failed to receive frame.\n");
		return CPYMO_ERR_UNKNOWN;
	}
} }

static error_t cpymo_movie_update(cpymo_engine *e, void *ui_data, float dt)
{
	cpymo_movie *m = (cpymo_movie *)ui_data;
	m->current_time += dt;

	if (m->video_current_frame_time < m->current_time) {
		error_t err = cpymo_movie_send_video_frame_to_backend(m);
		if (err == CPYMO_ERR_NO_MORE_CONTENT) {
			cpymo_ui_exit(e);
			return CPYMO_ERR_SUCC;
		}
		else if (err == CPYMO_ERR_SUCC)
			cpymo_engine_request_redraw(e);
	}

	if (CPYMO_INPUT_JUST_RELEASED(e, skip)) {
		if (m->skip_pressed) m->skip_pressed = false;
		else {
			cpymo_ui_exit(e);
			return CPYMO_ERR_SUCC;
		}
	}

	return CPYMO_ERR_SUCC;
}

static void cpymo_movie_draw(const cpymo_engine *e, const void *ui_data)
{
	cpymo_backend_movie_draw_surface();
}

static void cpymo_movie_delete(cpymo_engine *e, void *ui_data)
{
	cpymo_movie *m = (cpymo_movie *)ui_data;

	cpymo_audio_bgm_stop(e);

	if (m->current_bgm_name) {
		cpymo_audio_bgm_play(
			e, 
			cpymo_str_pure(m->current_bgm_name), 
			true);
		free(m->current_bgm_name);
	}

	if (m->video_frame) av_frame_free(&m->video_frame);
	if (m->packet) av_packet_free(&m->packet);
	if (m->video_codec_context) avcodec_free_context(&m->video_codec_context);
	if (m->format_context) avformat_close_input(&m->format_context);

	#ifdef DONT_PASS_PATH_TO_FFMPEG
		if (m->io_context) {
			void *buf = m->io_context->buffer;
			avio_context_free(&m->io_context);
			if (buf) av_free(buf);
		}

		cpymo_package_stream_reader_close(&m->stream_reader);
	#endif

	if (m->backend_inited) cpymo_backend_movie_free_surface();
}

error_t cpymo_movie_play(cpymo_engine * e, cpymo_str videoname)
{
	char *current_bgm_name = NULL;

	{
		const char *current_bgm_name_src = cpymo_audio_get_bgm_name(e);
		if (current_bgm_name_src) {
			current_bgm_name = (char *)malloc(strlen(current_bgm_name_src) + 1);
			if (current_bgm_name)
				strcpy(current_bgm_name, current_bgm_name_src);
		}
	}

	cpymo_audio_bgm_stop(e);
	cpymo_audio_se_stop(e);
	cpymo_audio_vo_stop(e);

	switch (cpymo_backend_movie_how_to_play()) {
	case cpymo_backend_movie_how_to_play_unsupported:
		printf("[Warning] This platform does not support video playing.\n");
		return CPYMO_ERR_SUCC;
	case cpymo_backend_movie_how_to_play_send_surface:
		break;
	};
	
	cpymo_movie *m = NULL;
	error_t err = 
		cpymo_ui_enter(
			(void **)&m, 
			e, 
			sizeof(*m), 
			&cpymo_movie_update, 
			&cpymo_movie_draw, 
			&cpymo_movie_delete);
	CPYMO_THROW(err);

	#ifdef DONT_PASS_PATH_TO_FFMPEG
		m->io_context = NULL;
		memset(&m->stream_reader, 0, sizeof(m->stream_reader));
	#endif

	m->current_bgm_name = current_bgm_name;
	m->format_context = NULL;
	m->video_codec_context = NULL;
	m->no_more_content = false;
	m->packet = NULL;
	m->video_frame = NULL;
	m->current_time = 0;
	m->backend_inited = false;
	m->skip_pressed = e->input.skip;

	#define THROW(ERR_COND, ERRCODE, MESSAGE) \
		if (ERR_COND) { \
			if (path) free(path); \
			printf("[Error] %s: %s.\n", MESSAGE, path); \
			cpymo_ui_exit(e); \
			return ERRCODE; \
		}

	#define THROW_AVERR(ERR_COND, ERRCODE) \
		THROW(ERR_COND, ERRCODE, av_err2str(averr));

	#define THROW_CPYMO_IF(ERR_COND, ERR) \
		THROW(ERR_COND, ERR, cpymo_error_message(ERR));

	char *path = NULL;
	err = cpymo_assetloader_get_video_path(&path, videoname, &e->assetloader);
	THROW(err != CPYMO_ERR_SUCC, err, "[Error] Faild to get video path");

	#ifdef DONT_PASS_PATH_TO_FFMPEG
		err = cpymo_package_stream_reader_from_file(&m->stream_reader, path);
		THROW_CPYMO_IF(err != CPYMO_ERR_SUCC, err);

		#ifndef FFMPEG_MOVIE_AVIO_BUFFER_SIZE
		#define FFMPEG_MOVIE_AVIO_BUFFER_SIZE 1024 * 1024
		#endif

		void *io_buffer = av_malloc(FFMPEG_MOVIE_AVIO_BUFFER_SIZE);
		THROW_CPYMO_IF(io_buffer == NULL, CPYMO_ERR_OUT_OF_MEM);

		extern int cpymo_audio_packaged_audio_ffmpeg_read_packet(
			void *opaque, uint8_t *buf, int buf_size);
		extern int64_t cpymo_audio_packaged_audio_ffmpeg_seek(
			void *opaque, int64_t offset, int whence);
			
		m->io_context = avio_alloc_context(
			(unsigned char *)io_buffer, FFMPEG_MOVIE_AVIO_BUFFER_SIZE,
			0, &m->stream_reader,
			&cpymo_audio_packaged_audio_ffmpeg_read_packet,
			NULL,
			&cpymo_audio_packaged_audio_ffmpeg_seek);
		
		if (m->io_context == NULL) {
			av_free(io_buffer);
			THROW_CPYMO_IF(true, CPYMO_ERR_OUT_OF_MEM);
		}

		m->format_context = avformat_alloc_context();
		THROW_CPYMO_IF(m->format_context == NULL, CPYMO_ERR_OUT_OF_MEM);

		m->format_context->pb = m->io_context;
		m->format_context->flags |= AVFMT_FLAG_CUSTOM_IO;
		#define PATH_ARG ""
	#else
		#define PATH_ARG path
	#endif

	int averr = avformat_open_input(&m->format_context, PATH_ARG, NULL, NULL);
	#undef PATH_ARG
	if (averr != 0) {
		if (path) free(path);
		cpymo_ui_exit(e);
		return CPYMO_ERR_CAN_NOT_OPEN_FILE;
	}

	averr = avformat_find_stream_info(m->format_context, NULL);
	THROW_AVERR(averr < 0, CPYMO_ERR_NOT_FOUND);

	m->video_stream_index = av_find_best_stream(m->format_context, AVMEDIA_TYPE_VIDEO, -1, -1, NULL, 0);
	THROW(m->video_stream_index < 0, CPYMO_ERR_NOT_FOUND, "[Error] Could not find video stream");

	const AVCodec *video_codec = 
		avcodec_find_decoder(m->format_context->streams[m->video_stream_index]->codecpar->codec_id);
	THROW(video_codec == NULL, CPYMO_ERR_NOT_FOUND, "[Error] Could not find video codec");

	m->video_codec_context = avcodec_alloc_context3(video_codec);
	THROW(m->video_codec_context == NULL, CPYMO_ERR_UNKNOWN, "[Error] Could not open video codec context");

	averr = avcodec_parameters_to_context(
		m->video_codec_context,
		m->format_context->streams[m->video_stream_index]->codecpar);
	THROW_AVERR(averr < 0, CPYMO_ERR_UNKNOWN);

	averr = avcodec_open2(m->video_codec_context, video_codec, NULL);
	THROW_AVERR(averr, CPYMO_ERR_UNKNOWN);

	m->packet = av_packet_alloc();
	THROW(m->packet == NULL, CPYMO_ERR_OUT_OF_MEM, "[Error] Could not alloc AVPacket");

	m->video_frame = av_frame_alloc();
	THROW(m->video_frame == NULL, CPYMO_ERR_OUT_OF_MEM, "[Error] Could not alloc AVFrame");

	m->video_frame->best_effort_timestamp = 0;
	m->video_current_frame_time = 0;

	int width = m->format_context->streams[m->video_stream_index]->codecpar->width;
	int height = m->format_context->streams[m->video_stream_index]->codecpar->height;

	enum AVPixelFormat format = 
		(enum AVPixelFormat)m->format_context->streams[m->video_stream_index]->codecpar->format;

	enum cpymo_backend_movie_format backend_format;
	switch (format) {
	case AV_PIX_FMT_YUV420P: backend_format = cpymo_backend_movie_format_yuv420p; break;
	case AV_PIX_FMT_YUV422P: backend_format = cpymo_backend_movie_format_yuv422p; break;
	case AV_PIX_FMT_YUV420P16: backend_format = cpymo_backend_movie_format_yuv420p16; break;
	case AV_PIX_FMT_YUV422P16: backend_format = cpymo_backend_movie_format_yuv422p16; break;
	case AV_PIX_FMT_YUYV422: backend_format = cpymo_backend_movie_format_yuyv422; break;
	default: THROW(true, CPYMO_ERR_UNSUPPORTED, "[Error] Movie pixel format unsupported");
	};

	err = cpymo_backend_movie_init_surface((size_t)width, (size_t)height, backend_format);
	THROW(err == CPYMO_ERR_UNSUPPORTED, err, "[Error] Movie backend could not support this video");
	THROW(err != CPYMO_ERR_SUCC, err, "[Error] Movie backend init failed");

	m->backend_inited = true;

	err = cpymo_audio_play_video(e, path);
	THROW(err != CPYMO_ERR_SUCC, err, "[Error] Can not open audio.");
	cpymo_movie_send_video_frame_to_backend(m);
	
	free(path);

	return CPYMO_ERR_SUCC;
}
#endif

#ifdef DISABLE_MOVIE
error_t cpymo_movie_play(cpymo_engine * e, cpymo_str videoname)
{
	return CPYMO_ERR_SUCC;
}
#endif
