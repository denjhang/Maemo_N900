# J2ME LLM

[简体中文](README.md) | **English**

J2ME LLM is a lightweight OpenAI Chat Completions-compatible client for CLDC 1.1 / MIDP 2.0 phones and Java ME emulators. The current version is v0.4.1, with multiple conversations, message edit/regenerate actions, web search, unlockable resource limits, and smoother scrolling through very long messages.

**Download v0.4.1:** [JAR installer](https://github.com/huayuechenfeng/j2me-llm/releases/download/v0.4.1/J2ME-LLM.jar) · [JAD descriptor](https://github.com/huayuechenfeng/j2me-llm/releases/download/v0.4.1/J2ME-LLM.jad) · [Offline configuration generator HTML](https://github.com/huayuechenfeng/j2me-llm/releases/download/v0.4.1/J2ME-LLM-Config-Generator-v0.4.1.html) · [Standalone Windows x64 gateway ZIP](https://github.com/huayuechenfeng/j2me-llm/releases/download/v0.4.1/J2ME-LLM-Gateway-v0.4.1-windows-x64.zip) · [Release notes](https://github.com/huayuechenfeng/j2me-llm/releases/tag/v0.4.1)

> **Project note:** v0.4.1 has completed real-device validation; v0.2.0 was the first public release, while v0.1.0 was an unpublished development and W995 device-testing prototype. Chihoko defined the product direction and performed real-device validation, while design, implementation, testing, and documentation were completed through AI-assisted vibe coding.

## What's new in v0.4.1

- Improved scrolling performance for very long message bubbles: each repaint processes only text lines that intersect the visible clip instead of issuing draw calls for every off-screen line.
- Line wrapping, bubble height, text layout, and appearance are unchanged; the improvement has been validated on a real device.

## What's new in v0.4.0

> **Web search remains an experimental feature.** Search availability, result quality, and network compatibility may be unstable or incomplete. The keyless free mode is a fallback only. A keyed provider such as Brave, Tavily, or Exa is recommended; configure it with the offline configuration generator bundled in the Release, generate a `.j2cfg` file, and import that file on the phone.

- Open `Chats / New` to find an always-visible `+ New chat` first row, then create, switch, rename, or delete independently persisted conversations. Changing a provider profile no longer replaces the current history.
- Edit and resend a user message or regenerate an answer from the selected turn.
- Search + Send with keyless DuckDuckGo + Wikipedia and public SearXNG reference presets, plus Brave, Tavily, Exa, and custom JSON APIs.
- Search results are bounded, persisted with the user turn, and injected as explicitly untrusted reference text.
- Compatible, Recommended, and explicitly unlocked Custom context budgets. The recommended defaults are 131,072 active characters, 64 active/saved messages, and 96,000 request-context characters.
- Compatible, High-performance, and Custom image budgets. High-performance mode allows 512 KiB / 1,048,576-pixel input and 1 MiB returned images while retaining free-memory checks.
- The local TLS gateway now exposes authenticated `/v1/search` for phones that cannot reach modern HTTPS search services.

See the [v0.4 implementation plan](docs/V0.4_IMPLEMENTATION_PLAN.md) for limits, migration, and acceptance criteria.

## What's new in v0.3.0

- Simplified Chinese, English, and system-default UI modes. Auto mode selects Chinese for `zh*` locales and English otherwise.
- The language preference is stored separately in `J2MELLM_UI_PREFS` without changing profiles, configuration packages, or conversations.
- Touch devices use a full-screen chat view with Compose/Stop, Image/Profiles, and More toolbar buttons.
- More provides Profiles, Settings, Language, Reasoning, Clear, and Exit; touch scrolling, hit testing, resize reflow, and pixel-width ellipsis are supported.
- Non-touch devices retain the existing commands and directional-key scrolling in the same universal JAR.

## Highlights

- Four reusable provider profiles: OpenAI, DeepSeek, Kimi, and Custom. Each keeps its own API key, endpoints, model, reasoning settings, multimodal flag, and model cache; v0.4 conversations select a profile independently.
- Automatic migration from the v0.1 `J2MELLM_CFG` and `J2MELLM_CHAT` stores. Legacy RMS data is retained instead of being deleted.
- Recoverable profile and conversation indexes plus independent CRC-protected message records, with automatic backup recovery when a primary index is damaged.
- Model lists are fetched only when requested. The incremental parser reads `data[].id`, caches up to 64 model IDs, and never contacts a provider during startup.
- Reasoning mode (`Auto`, `On`, or `Off`) is independent from whether received reasoning text is expanded or folded in the UI.
- Multimodal support is disabled by default. File APIs, image reads, image decoding, and previews are loaded only when needed.
- Request JSON is measured first and then written directly to the HTTP connection through a 512-byte buffer. Image Base64 is streamed without constructing another full-size encoded string.
- Canvas bubble layouts are cached, and streaming repaints are coalesced to roughly one update every 100 ms.
- Offline `.j2cfg` packages can be generated on Android or a computer, transferred by Bluetooth, imported on the phone, and safely exported for backup.
- An optional Node.js gateway lets legacy TLS clients reach modern HTTPS providers through a trusted local network.

## Provider presets

| Profile | Chat Completions endpoint | Models endpoint | Initial model | Reasoning protocol |
| --- | --- | --- | --- | --- |
| OpenAI | `https://api.openai.com/v1/chat/completions` | `https://api.openai.com/v1/models` | Empty; fetch or enter one | `reasoning_effort` |
| DeepSeek | `https://api.deepseek.com/chat/completions` | `https://api.deepseek.com/models` | `deepseek-v4-flash` | `thinking.type` plus effort |
| Kimi | `https://api.moonshot.cn/v1/chat/completions` | `https://api.moonshot.cn/v1/models` | `kimi-k3` | Model-specific K3/K2 behavior |
| Custom | Editable | Editable or derived from the chat URL | Empty | None, OpenAI effort, thinking object, or always-on |

Built-in profiles reset to their official endpoints. Enable the advanced override only when a compatible gateway is required. Provider models and request fields can change over time, so refresh the catalog on demand and consult the current [OpenAI Models API](https://developers.openai.com/api/reference/resources/models/methods/list), [OpenAI Chat Completions API](https://developers.openai.com/api/reference/resources/chat/subresources/completions/methods/create), [DeepSeek API documentation](https://api-docs.deepseek.com/), and [Kimi model documentation](https://platform.kimi.com/docs/models).

## Installation

Place `J2ME-LLM.jar` and `J2ME-LLM.jad` in the same directory and install through the JAD when possible. The MIDlet requests HTTP and HTTPS access. JSR-75 file read/write permissions are optional and are used only for images and configuration packages.

For a v0.1 upgrade:

1. Do **not** uninstall the existing MIDlet. Uninstalling a Java ME suite usually removes its RMS data.
2. Keep `MIDlet-Name: J2ME LLM` and `MIDlet-Vendor: Chihoko` unchanged, then install the v0.3.0 JAD as an update or replacement.
3. On first launch, verify that the active profile is `Custom (legacy configuration)` and check the endpoint, key, model, and migrated conversation.
4. Export a `.j2cfg` backup after the upgrade succeeds.

RMS ownership belongs to the MIDlet suite, and whether an update is recognized as the same suite still depends on the phone vendor's installer. See the [update and recovery guide](docs/UPDATE_AND_RECOVERY.md) for the complete test matrix.

## Building

The build requires Windows PowerShell and a JDK that provides `java`, `javac`, and `jar`. Downloaded build tools are kept under the project-local `.tools` directory and do not replace the system Java installation.

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\bootstrap.ps1
powershell -ExecutionPolicy Bypass -File .\tools\build.ps1
```

Build outputs:

- `dist/J2ME-LLM.jar`
- `dist/J2ME-LLM.jad`

The release build runs 16 desktop self-tests, compiles with ECJ using Java 1.3 source and CLDC 1.1-compatible class files, and performs Java ME preverification with ProGuard. Do not use `-SkipTests` for release artifacts.

Start MicroEmulator with:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\run-emulator.ps1
```

Run the real RMS upgrade/recovery fixture, which creates v0.1 records, migrates them, corrupts the primary v0.2 record, and verifies backup recovery:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\test-rms-upgrade-recovery.ps1
```

## Offline configuration and Bluetooth transfer

Open [provisioner/index.html](provisioner/index.html) directly on an Android phone or computer. It is a single offline page with no network dependency and does not upload form data.

1. Fill in one or more model profiles and optionally configure a web-search preset, endpoint, and search API key.
2. Generate `J2ME-LLM-config-v2.j2cfg`.
3. Share the file over Bluetooth to the Java ME phone.
4. In J2ME LLM, open `Profiles -> Import configuration` and select the file.
5. After a successful import, delete the plaintext package from the phone, Android downloads, and Bluetooth inbox if it is no longer needed.

The `.j2cfg` envelope uses versioned JSON, a Base64 payload, and CRC-32. This detects transfer corruption but provides **no encryption or source authentication**. API keys remain plaintext. Prefer a revocable, rate-limited gateway token instead of a long-lived account key. See the [provisioner documentation](provisioner/README.md) for the format and offline verification flow.

Configuration export writes `J2ME-LLM-backup-<timestamp>.j2cfg` to the first writable filesystem root. Export uses a temporary file, byte-for-byte verification, and a same-directory rename. v0.4 packages contain provider and search settings, but not conversation history. Importing an older v2 package without a search object preserves the phone's current search settings.

## Reasoning controls

`Settings -> Reasoning mode` controls fields sent in future requests:

- `Auto`: send no reasoning control and let the model decide.
- `On`: enable reasoning using the selected profile protocol and effort.
- `Off`: use `reasoning_effort: none` for OpenAI-style profiles or `thinking.type: disabled` for supported DeepSeek/Kimi K2-style profiles.
- Kimi K3 and K2.7 Code are treated as always-reasoning models. K3 accepts reasoning effort; K2.7 Code does not receive a guessed switch field.

The chat screen's reasoning command only expands or folds reasoning text already received. It does not change request behavior. Not every provider supports every value; if the server rejects a field, return the profile to `Auto`.

## Multimodal and memory behavior

Multimodal mode is off by default. When enabled on a device with JSR-75, the file picker accepts JPG, PNG, GIF, or WebP files up to 96 KiB and 65,536 pixels. Requests use an `image_url` data URL with `detail: low`. Compatible image responses are treated as an extension and remote downloads are limited to 256 KiB.

Image dimensions are read from headers before decoding. Unknown or oversized images never reach `Image.createImage`. A failed preview or low-memory condition should affect only the image preview, not ordinary text chat.

The active conversation is limited to 32 messages and 49,152 weighted characters. A single message is limited to 24,576 content characters and 8,192 reasoning characters. The saved RMS history keeps up to 24 completed messages per profile.

## HTTPS/TLS gateway for legacy phones

Older phones such as the W995 may be unable to negotiate modern TLS versions or trust current certificate chains. [gateway/server.js](gateway/server.js) stores the real upstream key and accepts a separate device token from the phone. Example local endpoints:

- Chat: `http://192.168.1.10:8787/v1/chat/completions`
- Models: `http://192.168.1.10:8787/v1/models`

Plain HTTP on a LAN is not end-to-end encrypted: the device token, prompts, answers, and images can be observed by other systems on that network. Never expose the gateway port directly to the public internet. The emulator configuration should bind to `127.0.0.1`; bind to a LAN address only for real-device testing and protect it with a firewall. See the [gateway guide](gateway/README.md).

## Repository layout

| Path | Purpose |
| --- | --- |
| `src/` | CLDC 1.1 / MIDP 2.0 application source |
| `tests/` | Desktop self-tests and Java ME stubs |
| `tools/` | Toolchain bootstrap, build, emulator, and RMS recovery scripts |
| `provisioner/` | Offline `.j2cfg` generator |
| `gateway/` | Optional legacy-TLS compatibility gateway |
| `docs/` | User, architecture, development, and recovery documentation |
| `config/` | MIDlet manifest source |

## Documentation

- [User guide (Chinese)](docs/USER_GUIDE.md)
- [Update, migration, and recovery (Chinese)](docs/UPDATE_AND_RECOVERY.md)
- [Architecture, protocols, and memory budgets (Chinese)](docs/ARCHITECTURE.md)
- [Development, testing, and release checklist (Chinese)](docs/DEVELOPMENT.md)
- [Offline provisioning package format (Chinese)](provisioner/README.md)
- [TLS compatibility gateway (Chinese)](gateway/README.md)
- [Changelog](CHANGELOG.md)

## Known limitations

- The core protocol is Chat Completions, not the Responses API. Tool calls and standard image generation are not implemented.
- Reasoning fields and compatible image response formats are not standardized across providers; presets cover only known protocols.
- API keys are stored in RMS without a hardware-backed secure element. Security depends on the device, filesystem permissions, and gateway policy.
- `.j2cfg` packages do not back up chat history. RMS is normally unrecoverable after uninstalling the MIDlet.
- An emulator cannot reproduce W995 TLS, fonts, JSR-75 behavior, heap limits, or image decoders. Real-device regression testing remains required for each release.

Contributions and device compatibility reports are welcome.
