# 架构说明

## 组件

```text
server/
├─ gateway.js             总装：创建并启动以下全部服务
├─ server.js              旧 QQ TCP 协议服务（14000）
├─ admin-server.js        本机管理 API + 静态页面（13980，仅 127.0.0.1）
├─ mobile-group-server.js 手机浏览器群管理/WAP 页面（13981）
├─ media-service.js       旧媒体上传兼容入口（80；v0.1.0 不承诺媒体功能）
├─ protocol.js            帧格式、命令与字段编码
├─ symbian-protocol.js    QQ2013 WUP/Accost 适配
├─ jce.js                 JCE/Tars 最小兼容编解码
├─ qqtea.js               QQ-TEA 兼容加解密
├─ store.js               数据模型与业务逻辑
├─ sqlite-persistence.js  SQLite 持久化
├─ virtual-agent.js       虚拟用户运行时（可选）
├─ llm-client.js          OpenAI Chat Completions 兼容客户端（可选）
└─ secrets.js             Windows DPAPI / 环境变量密钥读取
```

塞班原生 QQ2013 桥接（tools/ 目录）：

```text
run-symbian-gateway.ps1    管理员启动器：临时占用旧节点地址、弱主机、防火墙，退出自动恢复
symbian-gateway-session.js 8080 桥接 + 网关会话：把手机发往旧节点的连接转交给 14000
```

桥接数据流：

```text
QQ2013 手机 --WiFi--> 电脑环回上的旧节点地址:8080 --桥接--> 网关 :14000 --业务逻辑--> SQLite
```

## 端口

| 端口 | 用途 | 默认监听 |
| --- | --- | --- |
| 14000/TCP | 旧手机 QQ 协议 | 0.0.0.0 |
| 13980/TCP | 管理台 | 127.0.0.1（仅本机） |
| 13981/TCP | 手机浏览器页面 | 0.0.0.0 |
| 80/TCP | 旧媒体上传入口（v0.1.0 不承诺媒体） | 0.0.0.0 |

## 数据流

```text
手机客户端 --WiFi--> 网关 TCP 14000 --业务逻辑--> SQLite（server/data/private-qq.sqlite）
                                                      |
电脑浏览器 --127.0.0.1:13980--> 管理台 API -----------+
```

## 会话与安全

- 每个登录客户端持有独立会话；登录使用私服账号的 MD5 摘要。
- 会话密钥由网关在 `0x0049` 阶段生成并下发给客户端，后续负载使用 QQ-TEA。
- TCP keepalive 代替旧的空闲超时，避免"看似在线、实际断线"。
- 管理台默认要求仅本机访问；如需远程管理必须显式配置令牌。
- 网关不向任何第三方发送数据。虚拟用户功能只有在你在管理台主动配置了模型接口后才会把对话内容发送给你指定的模型服务；启动时自动整理默认关闭（`start-gateway.bat` 已带 `-SkipStartupMemoryCompaction`）。

## 测试

```powershell
node server\compat-self-test.js     # SQLite/群/状态/双会话兼容回归
node server\gateway-self-test.js    # 虚拟用户、管理 API、LLM mock 综合测试
node server\media-self-test.js      # 媒体链路的服务端回归（不代表已发布媒体功能）
```
