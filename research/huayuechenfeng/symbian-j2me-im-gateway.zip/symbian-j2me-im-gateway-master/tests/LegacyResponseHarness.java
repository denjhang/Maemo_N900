import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Vector;

public final class LegacyResponseHarness {
    private static byte[] hex(String value) {
        byte[] output = new byte[value.length() / 2];
        for (int i = 0; i < output.length; i++) {
            output[i] = (byte) Integer.parseInt(value.substring(i * 2, i * 2 + 2), 16);
        }
        return output;
    }

    private static String hex(byte[] value) {
        StringBuffer output = new StringBuffer(value.length * 2);
        for (int i = 0; i < value.length; i++) {
            int unsigned = value[i] & 0xFF;
            if (unsigned < 16) output.append('0');
            output.append(Integer.toHexString(unsigned));
        }
        return output.toString();
    }

    private static Object field(Object target, String name, Class type) throws Exception {
        Field field = target.getClass().getField(name);
        if (field.getType() != type) {
            for (Field candidate : target.getClass().getFields()) {
                if (candidate.getName().equals(name) && candidate.getType() == type) {
                    field = candidate;
                    break;
                }
            }
        }
        return field.get(target);
    }

    private static Field declaredField(Class owner, String name, Class type) throws Exception {
        for (Class cursor = owner; cursor != null; cursor = cursor.getSuperclass()) {
            for (Field candidate : cursor.getDeclaredFields()) {
                if (candidate.getName().equals(name) && candidate.getType() == type) {
                    candidate.setAccessible(true);
                    return candidate;
                }
            }
        }
        throw new NoSuchFieldException(owner.getName() + "." + name + ":" + type.getName());
    }

    private static Object allocate(Class type) throws Exception {
        Class unsafeClass = Class.forName("sun.misc.Unsafe");
        Field singleton = unsafeClass.getDeclaredField("theUnsafe");
        singleton.setAccessible(true);
        Object unsafe = singleton.get(null);
        return unsafeClass.getMethod("allocateInstance", Class.class).invoke(unsafe, type);
    }

    private static void setStaticByType(Class owner, Class type, Object value) throws Exception {
        for (Field candidate : owner.getDeclaredFields()) {
            if (Modifier.isStatic(candidate.getModifiers()) && candidate.getType() == type) {
                candidate.setAccessible(true);
                candidate.set(null, value);
                return;
            }
        }
        throw new NoSuchFieldException(owner.getName() + " static field of type " + type.getName());
    }

    private static Method methodByReturn(Class owner, String name, Class returnType) throws Exception {
        for (Method candidate : owner.getMethods()) {
            if (candidate.getName().equals(name)
                    && candidate.getParameterTypes().length == 0
                    && candidate.getReturnType() == returnType) {
                return candidate;
            }
        }
        throw new NoSuchMethodException(owner.getName() + "." + name + "():" + returnType.getName());
    }

    private static void exerciseBuddyBusinessHandler(Object decoded) throws Exception {
        Class ksClass = Class.forName("ks");
        Class iClass = Class.forName("i");
        Class dgClass = Class.forName("dg");
        Class jhClass = Class.forName("jh");
        Class dtClass = Class.forName("dt");
        Class gdClass = Class.forName("gd");
        Object store = allocate(ksClass);
        Object buddyContainer = allocate(iClass);
        declaredField(iClass, "a", Vector.class).set(buddyContainer, new Vector());
        declaredField(ksClass, "b", iClass).set(store, buddyContainer);
        Object groupContainer = allocate(dtClass);
        declaredField(dtClass, "a", Vector.class).set(groupContainer, new Vector());
        declaredField(ksClass, "a", dtClass).set(store, groupContainer);
        Object counters = allocate(dgClass);
        declaredField(dgClass, "c", int[].class).set(counters, new int[16]);
        declaredField(ksClass, "a", dgClass).set(store, counters);
        Object statusCounters = allocate(jhClass);
        declaredField(jhClass, "a", int[].class).set(statusCounters, new int[16]);
        Class kkClass = Class.forName("kk");
        setStaticByType(kkClass, ksClass, store);
        setStaticByType(kkClass, jhClass, statusCounters);
        setStaticByType(kkClass, gdClass, allocate(gdClass));

        long[] uins = (long[]) field(decoded, "b", long[].class);
        byte[] relationTypes = (byte[]) field(decoded, "a", byte[].class);
        byte[] groupIndexes = (byte[]) field(decoded, "b", byte[].class);
        Method apply = Class.forName("np").getDeclaredMethod(
            "a", long[].class, byte[].class, byte[].class);
        apply.setAccessible(true);
        apply.invoke(null, uins, relationTypes, groupIndexes);

        Vector buddies = (Vector) methodByReturn(ksClass, "d", Vector.class).invoke(store);
        System.out.println("businessBuddyCount=" + buddies.size());
        if (buddies.size() > 0) {
            Object buddy = buddies.elementAt(0);
            System.out.println("businessUin=" + declaredField(buddy.getClass(), "a", Long.TYPE).getLong(buddy));
            System.out.println("businessGroup=" + declaredField(buddy.getClass(), "a", Short.TYPE).getShort(buddy));
        }
        Vector groups = (Vector) methodByReturn(ksClass, "e", Vector.class).invoke(store);
        System.out.println("businessGroupCount=" + groups.size());
        if (groups.size() > 0) {
            Object group = groups.elementAt(0);
            System.out.println("businessGroupId="
                + declaredField(group.getClass().getSuperclass(), "a", Long.TYPE).getLong(group));
        }
    }

    public static void main(String[] args) throws Exception {
        int command = Integer.parseInt(args[0]);
        byte[] payload = hex(args[1]);
        // A real encrypted response is longer than the 15-byte envelope. The
        // client only uses the separately supplied decrypted payload on that
        // branch, so retain one dummy encrypted byte here.
        byte[] frame = new byte[16];
        frame[0] = 2;
        frame[1] = 0;
        frame[2] = 16;
        frame[3] = 6;
        frame[4] = 8;
        frame[5] = (byte) (command >>> 8);
        frame[6] = (byte) command;
        frame[15] = 3;
        Class codecClass = Class.forName("ik");
        Object codec = codecClass.newInstance();
        Method decode = codecClass.getMethod("a", byte[].class, byte[].class);
        Object result = decode.invoke(codec, frame, payload);
        if (result == null) throw new IllegalStateException("client rejected payload");
        System.out.println("class=" + result.getClass().getName());
        if (command == 84) {
            System.out.println("result=" + field(result, "a", Byte.TYPE));
            long[] uins = (long[]) field(result, "b", long[].class);
            byte[] relationTypes = (byte[]) field(result, "a", byte[].class);
            byte[] groupIndexes = (byte[]) field(result, "b", byte[].class);
            System.out.println("count=" + uins.length);
            if (uins.length > 0) {
                System.out.println("firstUin=" + uins[0]);
                System.out.println("firstRelationType=" + relationTypes[0]);
                System.out.println("firstGroup=" + groupIndexes[0]);
            }
            exerciseBuddyBusinessHandler(result);
        } else if (command == 90) {
            System.out.println("subtype=" + field(result, "a", Short.TYPE));
            System.out.println("uin=" + field(result, "a", Long.TYPE));
            System.out.println("nickname=" + field(result, "a", String.class));
        } else if (command == 107) {
            System.out.println("subtype=" + field(result, "a", Byte.TYPE));
            System.out.println("result=" + field(result, "c", Byte.TYPE));
        } else if (command == 86) {
            System.out.println("subtype=" + field(result, "a", Short.TYPE));
            System.out.println("sender=" + field(result, "b", Long.TYPE));
            System.out.println("text=" + field(result, "a", String.class));
        } else if (command == 105) {
            System.out.println("cursor=" + field(result, "a", Short.TYPE));
            System.out.println("count=" + field(result, "b", Short.TYPE));
            long[] uins = (long[]) field(result, "a", long[].class);
            String[] nicknames = (String[]) field(result, "a", String[].class);
            if (uins.length > 0) {
                System.out.println("firstUin=" + uins[0]);
                System.out.println("firstNickname=" + nicknames[0]);
            }
        } else if (command == 106) {
            System.out.println("subtype=" + field(result, "a", Byte.TYPE));
            System.out.println("result=" + field(result, "b", Byte.TYPE));
            long[] uins = (long[]) field(result, "a", long[].class);
            String[] nicknames = (String[]) field(result, "a", String[].class);
            System.out.println("count=" + uins.length);
            if (uins.length > 0) {
                System.out.println("firstUin=" + uins[0]);
                System.out.println("firstNickname=" + nicknames[0]);
            }
        } else if (command == 109) {
            System.out.println("subtype=" + field(result, "a", Byte.TYPE));
            System.out.println("result=" + field(result, "b", Byte.TYPE));
            if (((Byte) field(result, "a", Byte.TYPE)).byteValue() == 4) {
                System.out.println("groupId=" + field(result, "a", Long.TYPE));
                System.out.println("publicId=" + field(result, "b", Long.TYPE));
                System.out.println("ownerUin=" + field(result, "c", Long.TYPE));
                System.out.println("title=" + field(result, "b", String.class));
                System.out.println("memberCount=" + ((long[]) field(result, "a", long[].class)).length);
            }
        } else if (command == 113) {
            System.out.println("final=" + field(result, "a", Byte.TYPE));
            System.out.println("count=" + field(result, "a", Short.TYPE));
            long[] uins = (long[]) field(result, "a", long[].class);
            short[] statuses = (short[]) field(result, "b", short[].class);
            if (uins.length > 0) {
                System.out.println("firstUin=" + uins[0]);
                System.out.println("firstStatus=" + statuses[0]);
            }
        } else if (command == 114) {
            System.out.println("subtype=" + field(result, "a", Byte.TYPE));
            System.out.println("cursor=" + field(result, "a", Short.TYPE));
        } else if (command == 145) {
            System.out.println("result=" + field(result, "a", Byte.TYPE));
            System.out.println("decision=" + field(result, "b", Byte.TYPE));
        } else if (command == 147) {
            System.out.println("action=" + field(result, "a", Byte.TYPE));
            System.out.println("uin=" + field(result, "a", Long.TYPE));
            System.out.println("result=" + field(result, "b", Byte.TYPE));
        } else if (command == 131) {
            System.out.println("subtype=" + field(result, "a", Byte.TYPE));
            System.out.println("count=" + field(result, "a", Short.TYPE));
        } else if (command == 142) {
            System.out.println("count=" + field(result, "a", Byte.TYPE));
        } else if (command == 144) {
            byte subtype = ((Byte) field(result, "a", Byte.TYPE)).byteValue();
            System.out.println("subtype=" + subtype);
            System.out.println("status=" + field(result, "a", Long.TYPE));
            if (subtype == 6) {
                System.out.println("ticket=" + hex((byte[]) field(result, "c", byte[].class)));
            } else if (subtype == 1) {
                System.out.println("host=" + field(result, "b", Long.TYPE));
                System.out.println("port=" + (((Short) field(result, "b", Short.TYPE)).shortValue() & 0xFFFF));
                System.out.println("fileKey=" + hex((byte[]) field(result, "a", byte[].class)));
                System.out.println("uploadKey=" + hex((byte[]) field(result, "b", byte[].class)));
            }
        } else if (command == 101) {
            short innerCommand = ((Short) field(result, "b", Short.TYPE)).shortValue();
            System.out.println("innerCommand=" + (innerCommand & 0xFFFF));
            System.out.println("subtype=" + field(result, "a", Byte.TYPE));
            if (innerCommand == 181) {
                System.out.println("hash=" + hex((byte[]) field(result, "b", byte[].class)));
            }
        } else if (command == 148) {
            System.out.println("subtype=" + field(result, "a", Byte.TYPE));
            System.out.println("displayName=" + field(result, "a", String.class));
            Object message = field(result, "a", Class.forName("lq"));
            System.out.println("groupId=" + field(message, "a", Long.TYPE));
            System.out.println("sender=" + field(message, "b", Long.TYPE));
            System.out.println("timestamp=" + field(message, "c", Long.TYPE));
            System.out.println("text=" + field(message, "a", String.class));
        } else if (command == 164) {
            System.out.println("count=" + field(result, "a", Short.TYPE));
            long[] groupIds = (long[]) field(result, "a", long[].class);
            String[] publicIds = (String[]) field(result, "a", String[].class);
            if (groupIds.length > 0) {
                System.out.println("firstGroupId=" + groupIds[0]);
                System.out.println("firstPublicId=" + publicIds[0]);
            }
        }
    }
}
