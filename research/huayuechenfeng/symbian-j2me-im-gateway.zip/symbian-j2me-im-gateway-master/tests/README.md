# 交叉验证测试

这些测试使用 Java 反射，加载**你自己提供的客户端 JAR** 中的类来验证网关响应能被原客户端解码和处理。

它们不包含任何客户端代码，也不依赖腾讯文件即可编译；只有运行时需要你自备的 JAR。

## 运行前提

- JDK 8+（`java`、`javac` 可用）
- 你自己合法持有的客户端 JAR（与网关代码在同一个 Java 类路径中）

## 编译

```powershell
javac -encoding UTF-8 -cp <你的JAR> tests\*.java
```

## 运行示例

```powershell
java -cp "<你的JAR>;tests" ClientTeaHarness <编码类> encrypt <十六进制输入> <十六进制密钥>
java -cp "<你的JAR>;tests" LegacyResponseHarness 84 <十六进制负载>
```

`server\self-test.js` 需要设置环境变量 `QQ_TEA_HARNESS_CP` 指向你的 JAR 才能执行客户端 TEA 交叉验证。

## 自动跳过说明

`server\compat-self-test.js`、`server\gateway-self-test.js`、`server\media-self-test.js` 不需要客户端 JAR，可直接运行。只有 `server\self-test.js` 和本目录的 Java 夹具需要用户自备客户端。
