import com.sun.jdi.Bootstrap;
import com.sun.jdi.ClassType;
import com.sun.jdi.Field;
import com.sun.jdi.IntegerValue;
import com.sun.jdi.Method;
import com.sun.jdi.ObjectReference;
import com.sun.jdi.ReferenceType;
import com.sun.jdi.Value;
import com.sun.jdi.VirtualMachine;
import com.sun.jdi.connect.AttachingConnector;
import com.sun.jdi.connect.Connector;
import com.sun.jdi.event.ClassPrepareEvent;
import com.sun.jdi.event.Event;
import com.sun.jdi.event.EventSet;
import com.sun.jdi.event.MethodExitEvent;
import com.sun.jdi.event.VMDisconnectEvent;
import com.sun.jdi.request.ClassPrepareRequest;
import com.sun.jdi.request.EventRequest;
import com.sun.jdi.request.EventRequestManager;
import com.sun.jdi.request.MethodExitRequest;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/** Injects fake test credentials through JDWP after the MIDlet is initialized. */
public final class WtkLoginDriver {
    private static AttachingConnector socketConnector() {
        for (AttachingConnector connector : Bootstrap.virtualMachineManager().attachingConnectors()) {
            if ("com.sun.jdi.SocketAttach".equals(connector.name())) return connector;
        }
        throw new IllegalStateException("JDI socket attaching connector is unavailable");
    }

    private static MethodExitRequest watchStartAppExit(
            EventRequestManager manager, ReferenceType mainMidlet) {
        MethodExitRequest request = manager.createMethodExitRequest();
        request.addClassFilter(mainMidlet);
        request.setSuspendPolicy(EventRequest.SUSPEND_ALL);
        request.enable();
        return request;
    }

    private static ReferenceType onlyClass(VirtualMachine vm, String name) {
        List<ReferenceType> classes = vm.classesByName(name);
        if (classes.size() != 1) throw new IllegalStateException(name + " is not initialized");
        return classes.get(0);
    }

    private static Field field(ReferenceType type, String name, String signature) {
        for (Field field : type.fields()) {
            if (name.equals(field.name()) && signature.equals(field.signature())) return field;
        }
        throw new IllegalStateException("field not found: " + type.name() + "." + name + signature);
    }

    private static Method method(ReferenceType type, String name, String signature) {
        List<Method> methods = type.methodsByName(name, signature);
        if (methods.size() != 1) {
            throw new IllegalStateException("method not found: " + type.name() + "." + name + signature);
        }
        return methods.get(0);
    }

    private static void inject(VirtualMachine vm, MethodExitEvent event) throws Exception {
        ClassType kk = (ClassType) onlyClass(vm, "kk");
        Value npValue = kk.getValue(field(kk, "a", "Lnp;"));
        if (!(npValue instanceof ObjectReference)) throw new IllegalStateException("kk.np is null");
        ObjectReference np = (ObjectReference) npValue;
        Method login = method(np.referenceType(), "a", "(JLjava/lang/String;S)I");
        List<Value> arguments = Arrays.<Value>asList(
            vm.mirrorOf(10001L), vm.mirrorOf("qqtest123"), vm.mirrorOf((short) 0));
        Value result = np.invokeMethod(event.thread(), login, arguments, 0);
        int status = result instanceof IntegerValue ? ((IntegerValue) result).value() : Integer.MIN_VALUE;
        if (status != 0) throw new IllegalStateException("client login initializer returned " + status);
        System.out.println("LOGIN_INJECTED uin=10001 status=" + status);
    }

    public static void main(String[] args) throws Exception {
        String port = args.length == 0 ? "8000" : args[0];
        AttachingConnector connector = socketConnector();
        Map<String, Connector.Argument> arguments = connector.defaultArguments();
        arguments.get("hostname").setValue("127.0.0.1");
        arguments.get("port").setValue(port);
        if (arguments.containsKey("timeout")) arguments.get("timeout").setValue("30000");
        VirtualMachine vm = connector.attach(arguments);
        EventRequestManager manager = vm.eventRequestManager();
        List<ReferenceType> loaded = vm.classesByName("com.tencent.kqq2006.MainMIDlet");
        if (loaded.isEmpty()) {
            ClassPrepareRequest prepare = manager.createClassPrepareRequest();
            prepare.addClassFilter("com.tencent.kqq2006.MainMIDlet");
            prepare.setSuspendPolicy(EventRequest.SUSPEND_ALL);
            prepare.enable();
        } else {
            watchStartAppExit(manager, loaded.get(0));
        }
        vm.resume();

        boolean watched = !loaded.isEmpty();
        while (true) {
            EventSet events = vm.eventQueue().remove(90000L);
            if (events == null) throw new IllegalStateException("timed out waiting for MIDlet initialization");
            boolean done = false;
            for (Event event : events) {
                if (event instanceof ClassPrepareEvent && !watched) {
                    watchStartAppExit(manager, ((ClassPrepareEvent) event).referenceType());
                    watched = true;
                } else if (event instanceof MethodExitEvent) {
                    MethodExitEvent exit = (MethodExitEvent) event;
                    if ("startApp".equals(exit.method().name())) {
                        inject(vm, exit);
                        done = true;
                    }
                } else if (event instanceof VMDisconnectEvent) {
                    throw new IllegalStateException("emulator disconnected before login injection");
                }
            }
            events.resume();
            if (done) {
                vm.dispose();
                return;
            }
        }
    }
}
