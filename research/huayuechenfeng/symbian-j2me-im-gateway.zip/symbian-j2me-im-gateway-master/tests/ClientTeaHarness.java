public final class ClientTeaHarness {
    private static byte[] fromHex(String value) {
        if ((value.length() & 1) != 0) throw new IllegalArgumentException("odd hex length");
        byte[] result = new byte[value.length() / 2];
        for (int i = 0; i < result.length; i++) {
            int high = Character.digit(value.charAt(i * 2), 16);
            int low = Character.digit(value.charAt(i * 2 + 1), 16);
            if (high < 0 || low < 0) throw new IllegalArgumentException("invalid hex");
            result[i] = (byte) ((high << 4) | low);
        }
        return result;
    }

    private static String toHex(byte[] value) {
        StringBuffer output = new StringBuffer(value.length * 2);
        for (int i = 0; i < value.length; i++) {
            int item = value[i] & 0xFF;
            if (item < 16) output.append('0');
            output.append(Integer.toHexString(item));
        }
        return output.toString();
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 4) {
            throw new IllegalArgumentException("codecClass operation inputHex keyHex");
        }
        Class<?> codecClass = Class.forName(args[0]);
        Object codec = codecClass.getDeclaredConstructor().newInstance();
        byte[] input = fromHex(args[2]);
        byte[] key = fromHex(args[3]);
        String methodName;
        if ("decrypt".equals(args[1])) methodName = "a";
        else if ("encrypt".equals(args[1])) methodName = "b";
        else throw new IllegalArgumentException("unknown operation");
        java.lang.reflect.Method method = codecClass.getMethod(
            methodName, new Class<?>[] { byte[].class, byte[].class });
        byte[] output = (byte[]) method.invoke(codec, new Object[] { input, key });
        if (output == null) throw new IllegalStateException("client codec rejected the input");
        System.out.println(toHex(output));
    }
}
