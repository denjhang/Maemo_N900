'use strict';

const assert = require('node:assert/strict');
const http = require('node:http');
const net = require('node:net');
const protocol = require('./protocol');
const symbian = require('./symbian-protocol');
const qqtea = require('./qqtea');
const { close, createGateway, listen, parseArguments } = require('./gateway');
const { protectSecret, unprotectSecret } = require('./secrets');
const { AccountStore, defaultData } = require('./store');
const { displayVirtualTime, parseGroupReplyDecision } = require('./virtual-agent');

class FrameReader {
  constructor(socket) {
    this.buffer = Buffer.alloc(0);
    this.frames = [];
    this.waiters = [];
    socket.on('data', (chunk) => {
      this.buffer = Buffer.concat([this.buffer, chunk]);
      const consumed = protocol.consumeFrames(this.buffer);
      this.buffer = consumed.remainder;
      for (const frame of consumed.frames) {
        const waiter = this.waiters.shift();
        if (waiter) waiter(frame); else this.frames.push(frame);
      }
    });
  }

  next() {
    if (this.frames.length) return Promise.resolve(this.frames.shift());
    return new Promise((resolve) => this.waiters.push(resolve));
  }
}

function getKeyRequest(uin, sequence) {
  const payload = Buffer.alloc(24);
  Buffer.alloc(16, 0x41).copy(payload, 0);
  payload[16] = 1; payload[17] = 1;
  payload.writeUInt16BE(4, 18);
  Buffer.from('test', 'ascii').copy(payload, 20);
  return protocol.createFrame({ command: protocol.COMMAND_GET_KEY, sequence, uin, payload });
}

function loginRequest(uin, sequence, key, password) {
  const digest = protocol.passwordDigest(password);
  const payload = Buffer.alloc(64);
  payload.writeUInt16BE(9, 0); payload.writeUInt16BE(1, 2);
  Buffer.alloc(16, 0x42).copy(payload, 8);
  payload[24] = digest.length; digest.copy(payload, 25);
  payload[41] = 2;
  payload[42] = 4; payload.writeUInt16BE(15, 43); Buffer.alloc(15, 0x43).copy(payload, 45);
  payload[60] = 7; payload.writeUInt16BE(1, 61); payload[63] = 8;
  return protocol.createFrame({
    command: protocol.COMMAND_LOGIN, sequence, uin,
    payload: protocol.encryptPayload(payload, key, (size) => Buffer.alloc(size, 0x33)),
  });
}

function sendTextRequest(uin, targetUin, sequence, key, text) {
  const encoded = protocol.encodeLegacyText(text);
  const bodyLength = encoded.length + 16;
  const payload = Buffer.alloc(6 + bodyLength);
  payload.writeUInt32BE(targetUin, 0);
  payload.writeUInt16BE(bodyLength, 4);
  encoded.copy(payload, 6);
  return protocol.createFrame({
    command: protocol.COMMAND_SEND_TEXT, sequence, uin,
    payload: protocol.encryptPayload(payload, key, (size) => Buffer.alloc(size, 0x44)),
  });
}

async function startMockLlm() {
  const requests = [];
  const server = http.createServer((request, response) => {
    const chunks = [];
    request.on('data', (chunk) => chunks.push(chunk));
    request.on('end', () => {
      const body = JSON.parse(Buffer.concat(chunks).toString('utf8'));
      requests.push(body);
      const compacting = body.messages.some((message) => String(message.content).includes('维护一个虚构人物的一致长期记忆'));
      const decidingGroupReply = body.messages.some((message) => String(message.content)
        .includes('只输出一个英文单词：REPLY 或 SKIP'));
      const skippingGroupReply = body.messages.some((message) => String(message.content)
        .includes('无需回应测试'));
      const generatingGroupReply = body.messages.some((message) => String(message.content)
        .includes('正在旧版手机 QQ 群'));
      let content = '收到啦，我正在用老手机QQ和你聊天。';
      if (compacting) content = '记得测试用户A曾在手机QQ上问候我。';
      else if (decidingGroupReply) content = skippingGroupReply ? 'SKIP' : 'REPLY';
      else if (generatingGroupReply) content = '群里这件事我也想说一句。';
      const encoded = Buffer.from(JSON.stringify({
        id: 'mock', choices: [{ message: { role: 'assistant', content } }],
      }));
      response.writeHead(200, { 'content-type': 'application/json', 'content-length': encoded.length });
      response.end(encoded);
    });
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  return { server, requests, port: server.address().port };
}

async function main() {
  const symbianBuddyRequest = symbian.parseBuddyStatusRequest(
    Buffer.from('0000000000000000000000c80000', 'hex'));
  assert.equal(symbianBuddyRequest.cursor, 0);
  assert.equal(symbianBuddyRequest.pageSize, 200);
  const symbianBuddyPage = symbian.buildBuddyStatusResponse([
    { uin: 20000002, group: 0 },
    { uin: 10001, group: 0 },
  ]);
  assert.equal(symbianBuddyPage[0], 0);
  assert.equal(symbianBuddyPage[15], 1);
  assert.equal(symbianBuddyPage.readUInt16BE(18), 2);
  assert.equal(symbianBuddyPage.readUInt32BE(20), 20000002);
  assert.equal(symbianBuddyPage[24], 1);
  assert.equal(symbianBuddyPage.readUInt16BE(29), 1);
  assert.equal(symbianBuddyPage.readUInt16BE(31), 0);
  assert.equal(symbianBuddyPage.readUInt32BE(33), 10001);
  assert.equal(symbianBuddyPage[37], 1);
  assert.equal(symbianBuddyPage.readUInt16BE(symbianBuddyPage.length - 2), 0);

  const parsedOptions = parseArguments([
    '--trace-protocol', 'True', '--compact-memory-on-start', 'False',
  ], {});
  assert.equal(parsedOptions.traceProtocol, true);
  assert.equal(parsedOptions.compactMemoryOnStart, false);
  if (process.platform === 'win32') {
    const protectedSecret = protectSecret('path-independent-dpapi-test');
    assert.equal(unprotectSecret(protectedSecret), 'path-independent-dpapi-test');
  }
  const localSourceTime = new Date(2026, 7, 1, 12, 34, 56);
  const fixedVirtualTime = displayVirtualTime(localSourceTime, -14);
  assert.match(fixedVirtualTime, /2012年8月1日/);
  assert.match(fixedVirtualTime, /12:34:56/);
  assert.doesNotMatch(fixedVirtualTime, /2026/);
  assert.equal(parseGroupReplyDecision('REPLY'), true);
  assert.equal(parseGroupReplyDecision('{"reply":false}'), false);
  assert.equal(parseGroupReplyDecision('不回复'), false);
  assert.equal(parseGroupReplyDecision('也许吧'), null);
  const mock = await startMockLlm();
  const events = [];
  const store = new AccountStore(null, defaultData());
  store.upsertProvider({
    id: 'mock', name: 'Mock', baseUrl: `http://127.0.0.1:${mock.port}/v1`,
    model: 'mock-model', temperature: 0.8, maxTokens: 100, timeoutMs: 5000,
  });
  store.addAccount({
    uin: 20001, type: 'virtual', nickname: '小栞',
    profile: { realName: '林栞', signature: '正在测试老手机', age: 19, gender: 2, city: '架空市' },
    virtual: {
      providerId: 'mock', identity: '住在架空市的学生', roleCard: '温和、好奇，喜欢旧手机。',
      groupReplyPolicy: 'llm',
      replyDelayMinMs: 0, replyDelayMaxMs: 0,
    },
  });
  assert.equal(store.get(20001).virtual.timezone, undefined);
  assert.equal(store.get(20001).virtual.groupReplyPolicy, 'llm');
  store.requestFriend(10001, 20001, 'test');
  store.acceptFriend(20001, 10001);
  store.requestFriend(10001, 10002, 'offline delivery test');
  store.acceptFriend(10002, 10001);

  const options = {
    host: '127.0.0.1', port: 0, adminHost: '127.0.0.1', adminPort: 0,
    autoAcceptFriends: true, traceProtocol: false, store, sessions: new Map(),
    outboxDeliveryDelayMs: 10,
    logger: (event) => events.push(event),
  };
  const gateway = createGateway(options);
  try {
    const addresses = await listen(gateway, options);
    const indexResponse = await fetch(`http://127.0.0.1:${addresses.adminAddress.port}/`);
    assert.match(await indexResponse.text(), /旧 QQ 世界控制台/);
    const stateResponse = await fetch(`http://127.0.0.1:${addresses.adminAddress.port}/api/state`);
    const state = await stateResponse.json();
    assert.equal(state.accounts.find((account) => account.uin === 20001).type, 'virtual');
    assert.equal(state.settings.virtualTime.yearOffset, -14);
    const mobileIndex = await fetch(
      `http://127.0.0.1:${addresses.mobileAddress.port}/mobile/groups?mode=create`);
    assert.equal(mobileIndex.status, 200);
    assert.match(await mobileIndex.text(), /\/mobile\/groups\/create/);
    const wapCreate = await fetch(
      `http://127.0.0.1:${addresses.mobileAddress.port}/forward.jsp?bid=342`);
    assert.equal(wapCreate.status, 200);
    assert.match(await wapCreate.text(), /\/mobile\/groups\/create/);
    const wapSearch = await fetch(
      `http://127.0.0.1:${addresses.mobileAddress.port}/forward.jsp?bid=205`);
    assert.equal(wapSearch.status, 200);
    assert.match(await wapSearch.text(), /name="mode" value="search"/);
    const wapPlaceholder = await fetch(
      `http://127.0.0.1:${addresses.mobileAddress.port}/forward.jsp?bid=113`);
    assert.equal(wapPlaceholder.status, 200);
    assert.match(await wapPlaceholder.text(), /113/);
    const mobileCreate = await fetch(
      `http://127.0.0.1:${addresses.mobileAddress.port}/mobile/groups/create`, {
        method: 'POST',
        headers: { 'content-type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          uin: '10001', password: 'qqtest123', title: 'Phone group', members: '10002',
        }),
      });
    const mobileCreateText = await mobileCreate.text();
    assert.equal(mobileCreate.status, 201, mobileCreateText);
    assert.ok(store.listGroups().some((group) => group.title === 'Phone group'
      && group.members.some((member) => member.uin === 10002)));
    let timeResponse = await fetch(`http://127.0.0.1:${addresses.adminAddress.port}/api/settings/virtual-time`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ yearOffset: -10 }),
    });
    assert.equal(timeResponse.status, 200);
    assert.equal(store.data.settings.virtualTime.yearOffset, -10);
    timeResponse = await fetch(`http://127.0.0.1:${addresses.adminAddress.port}/api/settings/virtual-time`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ yearOffset: -14 }),
    });
    assert.equal(timeResponse.status, 200);

    store.requestFriend(10002, 20001, '先拒绝这次测试');
    let friendResponse = await fetch(`http://127.0.0.1:${addresses.adminAddress.port}/api/friends/reject`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ receiverUin: 20001, requesterUin: 10002 }),
    });
    assert.equal(friendResponse.status, 200);
    assert.equal(store.get(20001).incomingRequests.length, 0);
    store.requestFriend(10002, 20001, '再同意这次测试');
    friendResponse = await fetch(`http://127.0.0.1:${addresses.adminAddress.port}/api/friends/accept`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ receiverUin: 20001, requesterUin: 10002 }),
    });
    assert.equal(friendResponse.status, 200);
    assert.ok(store.get(20001).friends.includes(10002));

    const socket = net.createConnection({ host: '127.0.0.1', port: addresses.qqAddress.port });
    await new Promise((resolve, reject) => { socket.once('connect', resolve); socket.once('error', reject); });
    const reader = new FrameReader(socket);
    socket.write(getKeyRequest(10001, 1));
    const keyFrame = await reader.next();
    const key = keyFrame.payload.subarray(0, 16);
    socket.write(loginRequest(10001, 2, key, 'qqtest123'));
    const loginFrame = await reader.next();
    assert.equal(loginFrame.status, 0);
    const loginGroupMapping = await reader.next();
    assert.equal(loginGroupMapping.command, protocol.COMMAND_GROUP_MAPPING);

    socket.write(sendTextRequest(10001, 20001, 3, key, '你好，你现在在做什么？'));
    const acknowledgement = await reader.next();
    assert.equal(acknowledgement.command, protocol.COMMAND_SEND_TEXT);
    assert.equal(acknowledgement.status, 0);
    const incoming = await reader.next();
    assert.equal(incoming.command, protocol.COMMAND_INCOMING_TEXT);
    const incomingPlain = protocol.decryptPayload(incoming.payload, key);
    assert.equal(incomingPlain.readUInt16BE(0), 9);
    assert.equal(incomingPlain.readUInt32BE(6), 20001);
    assert.equal(protocol.decodeLegacyText(incomingPlain.subarray(12)),
      '收到啦，我正在用老手机QQ和你聊天。');

    const offlineText = 'offline cross-client delivery';
    socket.write(sendTextRequest(10001, 10002, 4, key, offlineText));
    const offlineAcknowledgement = await reader.next();
    assert.equal(offlineAcknowledgement.command, protocol.COMMAND_SEND_TEXT);
    assert.equal(offlineAcknowledgement.status, 0);
    assert.equal(store.data.outbox.length, 1);

    const secondSocket = net.createConnection({ host: '127.0.0.1', port: addresses.qqAddress.port });
    await new Promise((resolve, reject) => {
      secondSocket.once('connect', resolve); secondSocket.once('error', reject);
    });
    const secondReader = new FrameReader(secondSocket);
    secondSocket.write(getKeyRequest(10002, 1));
    const secondKeyFrame = await secondReader.next();
    const secondKey = secondKeyFrame.payload.subarray(0, 16);
    secondSocket.write(loginRequest(10002, 2, secondKey, 'qqtest456'));
    const secondLoginFrame = await secondReader.next();
    assert.equal(secondLoginFrame.status, 0);
    const secondGroupMapping = await secondReader.next();
    assert.equal(secondGroupMapping.command, protocol.COMMAND_GROUP_MAPPING);
    const offlineIncoming = await secondReader.next();
    assert.equal(offlineIncoming.command, protocol.COMMAND_INCOMING_TEXT);
    const offlineIncomingPlain = protocol.decryptPayload(offlineIncoming.payload, secondKey);
    assert.equal(offlineIncomingPlain.readUInt32BE(6), 10001);
    assert.equal(protocol.decodeLegacyText(offlineIncomingPlain.subarray(12)), offlineText);
    assert.equal(store.data.outbox.length, 0);
    secondSocket.destroy();
    socket.destroy();

    const group = store.createGroup({
      ownerUin: 10001, memberUins: [20001], title: 'LLM 两轮判断测试群',
    });
    store.updateGroupMember(group.id, 20001, { replyPolicy: 'llm' });
    assert.equal(store.getGroup(group.id).members.find(
      (member) => member.uin === 20001).replyPolicy, 'llm');

    let requestCount = mock.requests.length;
    store.saveGroupMessage(group.id, 10001, '小栞，你觉得旧手机还有意思吗？');
    const replyDelivery = gateway.deliverGroup(
      group.id, 10001, '小栞，你觉得旧手机还有意思吗？');
    assert.equal(replyDelivery.virtualQueued, 1);
    let groupQueue = gateway.runtime.queues.get(20001);
    if (groupQueue) await groupQueue;
    assert.equal(mock.requests.length, requestCount + 2);
    assert.equal(mock.requests[requestCount].temperature, 0);
    assert.equal(mock.requests[requestCount].max_tokens, 16);
    assert.ok(mock.requests[requestCount].messages.some((message) =>
      String(message.content).includes('住在架空市的学生')));
    assert.ok(store.recentGroupMessages(group.id, 10).some((message) =>
      message.from === 20001 && message.text === '群里这件事我也想说一句。'));
    assert.ok(events.some((event) => event.event === 'virtual_group_decision'
      && event.policy === 'llm' && event.reply === true && event.round === 1));
    assert.ok(events.some((event) => event.event === 'virtual_group_reply_started'
      && event.groupId === group.id && event.round === 2));

    const virtualGroupMessages = store.recentGroupMessages(group.id, 20)
      .filter((message) => message.from === 20001).length;
    requestCount = mock.requests.length;
    store.saveGroupMessage(group.id, 10001, '无需回应测试：这是别人之间的话题。');
    const skipDelivery = gateway.deliverGroup(
      group.id, 10001, '无需回应测试：这是别人之间的话题。');
    assert.equal(skipDelivery.virtualQueued, 1);
    groupQueue = gateway.runtime.queues.get(20001);
    if (groupQueue) await groupQueue;
    assert.equal(mock.requests.length, requestCount + 1);
    assert.equal(store.recentGroupMessages(group.id, 20)
      .filter((message) => message.from === 20001).length, virtualGroupMessages);
    assert.ok(events.some((event) => event.event === 'virtual_group_decision'
      && event.policy === 'llm' && event.reply === false && event.decisionText === 'SKIP'));

    const activeQueue = gateway.runtime.queues.get(20001);
    if (activeQueue) await activeQueue;
    const compacted = await gateway.runtime.compact(20001);
    assert.equal(compacted.compacted, 2);
    assert.match(store.get(20001).virtual.longTermMemory, /手机QQ/);
    assert.ok(mock.requests[0].messages.some((message) => String(message.content).includes('所有 QQ 会话')));
    assert.ok(mock.requests[0].messages.some((message) => String(message.content).includes('这是你所处世界的真实时间')));
    assert.ok(events.some((event) => event.event === 'virtual_message'));
    assert.ok(events.some((event) => event.event === 'message_sent'
      && event.to === 10002 && event.queuedOffline === true));
    assert.ok(events.some((event) => event.event === 'outbox_delivered'
      && event.from === 10001 && event.to === 10002));
    assert.ok(events.some((event) => event.event === 'memory_compacted'));
  } finally {
    await close(gateway);
    await new Promise((resolve) => mock.server.close(resolve));
  }
  process.stdout.write('QQ virtual gateway self-test passed.\n');
}

main().catch((error) => {
  process.stderr.write(error.stack + '\n');
  process.exitCode = 1;
});
