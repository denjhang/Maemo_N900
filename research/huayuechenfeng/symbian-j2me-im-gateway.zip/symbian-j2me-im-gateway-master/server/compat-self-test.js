'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const net = require('node:net');
const os = require('node:os');
const path = require('node:path');
const protocol = require('./protocol');
const symbian = require('./symbian-protocol');
const { close, createGateway, listen } = require('./gateway');
const { AccountStore, defaultData } = require('./store');

class FrameReader {
  constructor(socket, label) {
    this.label = label || 'socket';
    this.readCount = 0;
    this.buffer = Buffer.alloc(0);
    this.frames = [];
    this.waiters = [];
    socket.on('data', (chunk) => {
      this.buffer = Buffer.concat([this.buffer, chunk]);
      const consumed = protocol.consumeFrames(this.buffer);
      this.buffer = consumed.remainder;
      for (const frame of consumed.frames) {
        const waiter = this.waiters.shift();
        if (waiter) {
          clearTimeout(waiter.timer);
          waiter.resolve(frame);
        } else this.frames.push(frame);
      }
    });
  }

  next(timeoutMs) {
    this.readCount += 1;
    if (this.frames.length) return Promise.resolve(this.frames.shift());
    return new Promise((resolve, reject) => {
      const waiter = { resolve, reject, timer: null };
      waiter.timer = setTimeout(() => {
        const index = this.waiters.indexOf(waiter);
        if (index >= 0) this.waiters.splice(index, 1);
        reject(new Error(`timed out waiting for QQ frame ${this.label}#${this.readCount}`));
      }, timeoutMs || 3000);
      this.waiters.push(waiter);
    });
  }
}

function deterministicRandom(size) {
  return Buffer.alloc(size, 0x5A);
}

function getKeyRequest(uin, sequence) {
  return protocol.createFrame({
    command: protocol.COMMAND_GET_KEY, sequence, uin, payload: Buffer.alloc(24, 0x41),
  });
}

function loginRequest(uin, sequence, key, password, presence) {
  const digest = protocol.passwordDigest(password);
  const payload = Buffer.alloc(42);
  payload.writeUInt16BE(9, 0);
  payload.writeUInt16BE(1, 2);
  payload.writeUInt16BE(Number(presence || 0), 6);
  Buffer.alloc(16, 0x42).copy(payload, 8);
  payload[24] = digest.length;
  digest.copy(payload, 25);
  payload[41] = 0;
  return protocol.createFrame({
    command: protocol.COMMAND_LOGIN, sequence, uin,
    payload: protocol.encryptPayload(payload, key, deterministicRandom),
  });
}

async function connectAndLogin(port, uin, password, presence) {
  const socket = net.createConnection({ host: '127.0.0.1', port });
  await new Promise((resolve, reject) => {
    socket.once('connect', resolve);
    socket.once('error', reject);
  });
  const reader = new FrameReader(socket, String(uin));
  socket.write(getKeyRequest(uin, 1));
  const keyFrame = await reader.next();
  const key = keyFrame.payload.subarray(0, 16);
  socket.write(loginRequest(uin, 2, key, password, presence));
  const login = await reader.next();
  assert.equal(login.status, 0);
  return { socket, reader, key };
}

function encryptedRequest(command, sequence, uin, key, plain) {
  return protocol.createFrame({
    command, sequence, uin,
    payload: protocol.encryptPayload(plain, key, deterministicRandom),
  });
}

function groupSendPayload(groupId, text) {
  const encoded = protocol.encodeLegacyText(text);
  const payload = Buffer.alloc(21 + encoded.length);
  payload[0] = 1;
  payload.writeUInt32BE(groupId, 1);
  let offset = 5;
  payload.writeUInt16BE(0, offset); offset += 2;
  payload.writeUInt16BE(0, offset); offset += 2;
  payload.writeUInt16BE(1, offset); offset += 2;
  payload.writeUInt32BE(1234567890, offset); offset += 4;
  payload.writeUInt16BE(encoded.length, offset); offset += 2;
  encoded.copy(payload, offset); offset += encoded.length;
  payload[offset] = 0; offset += 1;
  payload[offset] = 0; offset += 1;
  payload.writeUInt16BE(0, offset);
  return payload;
}

function parseIncomingGroup(payload) {
  const nameLength = payload[1];
  const displayName = protocol.decodeLegacyText(payload.subarray(2, 2 + nameLength));
  let offset = 2 + nameLength + 2;
  const groupId = payload.readUInt32BE(offset); offset += 5;
  const senderUin = payload.readUInt32BE(offset); offset += 8;
  const timestamp = payload.readUInt32BE(offset); offset += 8;
  const fieldLength = payload.readUInt16BE(offset); offset += 2;
  const messageField = payload.subarray(offset, offset + fieldLength);
  return {
    displayName, groupId, senderUin, timestamp,
    text: protocol.decodeLegacyText(messageField.subarray(10)),
  };
}

function persistenceTest() {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'qq-sqlite-test-'));
  try {
    const legacyFile = path.join(directory, 'accounts.json');
    fs.writeFileSync(legacyFile, JSON.stringify(defaultData()), 'utf8');
    const imported = new AccountStore(legacyFile);
    assert.equal(imported.listAccounts().length, 2);
    assert.match(imported.dataFile, /accounts\.sqlite$/);
    imported.createGroup({
      ownerUin: 10001, memberUins: [10002], title: 'migration test',
    });
    imported.close();
    assert.equal(fs.readFileSync(path.join(directory, 'accounts.sqlite'), { encoding: 'ascii',
      flag: 'r' }).slice(0, 15), 'SQLite format 3');
    const reopened = new AccountStore(path.join(directory, 'accounts.sqlite'));
    assert.equal(reopened.listGroups().length, 1);
    assert.equal(reopened.getGroup(200001).members.length, 2);
    reopened.close();
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
}

function protocolFixturesTest() {
  const metadata = protocol.parseFriendMetadataRequest(
    Buffer.from('03000101312d0100000000', 'hex'));
  assert.deepEqual(metadata, { subtype: 3, uins: [20000001] });
  const metadataResponse = protocol.buildFriendMetadataPayload(metadata, [{
    uin: 20000001, nickname: 'Alice',
  }]);
  assert.equal(metadataResponse[0], 3);
  assert.equal(metadataResponse.readUInt32BE(6), 20000001);
  assert.equal(protocol.decodeLegacyText(metadataResponse.subarray(16)), 'Alice');
  assert.deepEqual(protocol.parseFriendActivityRequest(
    Buffer.from('01000101312d01', 'hex')), { subtype: 1, uins: [20000001] });
  assert.deepEqual(protocol.buildFriendActivityPayload(1), Buffer.from([1, 0, 0]));
  assert.deepEqual(protocol.buildAuxiliaryFeaturesPayload(), Buffer.from([0]));
  assert.deepEqual(symbian.parseAuxiliaryPresenceRequest(
    Buffer.from('8801312d0100', 'hex')), {
    opcode: 0x88, action: 'subscribe', targetUin: 20000001, flag: 0,
  });
  assert.equal(protocol.parsePresenceChangePayload(Buffer.from([30])), 30);
  const groupRequest = protocol.parseGroupSendPayload(groupSendPayload(200001, 'group hello'));
  assert.equal(groupRequest.groupId, 200001);
  assert.equal(groupRequest.text, 'group hello');
  const incoming = parseIncomingGroup(protocol.buildGroupMessagePayload({
    groupId: 200001, senderUin: 10001, displayName: 'J2ME-A', text: 'group hello',
    timestamp: 1234567890,
  }));
  assert.deepEqual(incoming, {
    displayName: 'J2ME-A', groupId: 200001, senderUin: 10001,
    timestamp: 1234567890, text: 'group hello',
  });
}

async function integrationTest() {
  const events = [];
  const store = new AccountStore(null, defaultData());
  store.addAccount({ uin: 10003, nickname: 'J2ME-C', password: 'qqtest789' });
  store.addAccount({
    uin: 20001, nickname: 'Virtual-G', type: 'virtual',
    virtual: { groupReplyPolicy: 'never', replyDelayMinMs: 0, replyDelayMaxMs: 0 },
  });
  store.requestFriend(10001, 10002, 'presence test');
  store.acceptFriend(10002, 10001);
  const group = store.createGroup({
    ownerUin: 10001, memberUins: [10002, 20001], title: 'J2ME test group',
    publicId: 87654321,
  });
  assert.throws(() => store.createGroup({
    ownerUin: 10001, title: 'duplicate number', publicId: group.publicId,
  }), /already exists/);
  const options = {
    host: '127.0.0.1', port: 0, adminHost: '127.0.0.1', adminPort: 0,
    store, sessions: new Map(), compactMemoryOnStart: false,
    logger: (event) => events.push(event),
  };
  const gateway = createGateway(options);
  let first;
  let second;
  try {
    const addresses = await listen(gateway, options);
    first = await connectAndLogin(addresses.qqAddress.port, 10001, 'qqtest123', 10);
    const firstMapping = await first.reader.next();
    assert.equal(firstMapping.command, protocol.COMMAND_GROUP_MAPPING);
    const firstMappingPlain = protocol.decryptPayload(firstMapping.payload, first.key);
    assert.equal(firstMappingPlain.readUInt32BE(11), group.id);

    first.socket.write(encryptedRequest(protocol.COMMAND_BUDDY_LIST, 3, 10001, first.key,
      Buffer.alloc(8)));
    const firstRelations = protocol.decryptPayload((await first.reader.next()).payload, first.key);
    assert.equal(firstRelations.length, 21);
    assert.equal(firstRelations.readUInt32BE(15), group.id);
    assert.equal(firstRelations[19], 4);

    second = await connectAndLogin(addresses.qqAddress.port, 10002, 'qqtest456', 10);
    const presenceOnline = await first.reader.next();
    assert.equal(presenceOnline.command, protocol.COMMAND_BUDDY_DETAILS);
    assert.equal(protocol.decryptPayload(presenceOnline.payload, first.key).readUInt16BE(14), 10);
    const secondMapping = await second.reader.next();
    assert.equal(secondMapping.command, protocol.COMMAND_GROUP_MAPPING);

    second.socket.write(encryptedRequest(protocol.COMMAND_CHANGE_PRESENCE, 3, 10002,
      second.key, Buffer.from([30])));
    assert.equal((await second.reader.next()).command, protocol.COMMAND_CHANGE_PRESENCE);
    const presenceAway = protocol.decryptPayload((await first.reader.next()).payload, first.key);
    assert.equal(presenceAway.readUInt16BE(14), 30);
    second.socket.write(encryptedRequest(protocol.COMMAND_CHANGE_PRESENCE, 4, 10002,
      second.key, Buffer.from([40])));
    await second.reader.next();
    const presenceInvisible = protocol.decryptPayload((await first.reader.next()).payload, first.key);
    assert.equal(presenceInvisible.readUInt16BE(14), 20);

    first.socket.write(encryptedRequest(protocol.COMMAND_FRIEND_METADATA, 5, 10001, first.key,
      Buffer.from('0300010000271200000000', 'hex')));
    const metadataFrame = await first.reader.next();
    assert.equal(metadataFrame.command, protocol.COMMAND_FRIEND_METADATA);
    const metadata = protocol.decryptPayload(metadataFrame.payload, first.key);
    assert.equal(metadata.readUInt32BE(6), 10002);

    first.socket.write(encryptedRequest(protocol.COMMAND_FRIEND_ACTIVITY, 6, 10001, first.key,
      Buffer.from('01000100002712', 'hex')));
    assert.deepEqual(protocol.decryptPayload((await first.reader.next()).payload, first.key),
      Buffer.from([1, 0, 0]));
    first.socket.write(encryptedRequest(protocol.COMMAND_AUXILIARY_FEATURES, 7, 10001, first.key,
      Buffer.from('01050000', 'hex')));
    assert.deepEqual(protocol.decryptPayload((await first.reader.next()).payload, first.key),
      Buffer.from([0]));
    first.socket.write(encryptedRequest(symbian.COMMAND_AUXILIARY_PRESENCE, 8, 10001, first.key,
      Buffer.from('880000271200', 'hex')));

    first.socket.write(encryptedRequest(protocol.COMMAND_GROUP_SERVICE, 9, 10001, first.key,
      Buffer.from([4, 0, 3, 13, 65])));
    const groupInfo = protocol.decryptPayload((await first.reader.next()).payload, first.key);
    assert.equal(groupInfo[0], 4);
    assert.equal(groupInfo[1], 0);
    assert.equal(groupInfo.readUInt32BE(2), group.id);
    assert.equal(protocol.decodeLegacyText(groupInfo.subarray(26, 26 + groupInfo.readUInt16BE(24))),
      group.title);

    const invite = Buffer.alloc(10);
    invite[0] = 2;
    invite.writeUInt32BE(group.id, 1);
    invite[5] = 2;
    invite.writeUInt32BE(10003, 6);
    first.socket.write(encryptedRequest(protocol.COMMAND_GROUP_SERVICE, 10, 10001, first.key, invite));
    assert.deepEqual(protocol.decryptPayload((await first.reader.next()).payload, first.key),
      Buffer.from([2, 0]));
    assert.ok(store.getGroup(group.id).members.some((member) => member.uin === 10003));

    const text = 'hello from J2ME group';
    first.socket.write(encryptedRequest(protocol.COMMAND_GROUP_SEND, 11, 10001, first.key,
      groupSendPayload(group.publicId, text)));
    const groupAck = await first.reader.next();
    assert.equal(groupAck.command, protocol.COMMAND_GROUP_SEND);
    assert.equal(groupAck.status, 0);
    const groupIncoming = await second.reader.next();
    assert.equal(groupIncoming.command, protocol.COMMAND_GROUP_MESSAGE);
    const parsedGroupIncoming = parseIncomingGroup(
      protocol.decryptPayload(groupIncoming.payload, second.key));
    assert.equal(parsedGroupIncoming.groupId, group.publicId);
    assert.equal(parsedGroupIncoming.text, text);
    assert.equal(store.recentGroupMessages(group.id, 10).length, 1);
    assert.ok(events.some((event) => event.event === 'virtual_group_decision'
      && event.policy === 'never' && event.reply === false));
    assert.ok(events.some((event) => event.event === 'symbian_auxiliary_presence_ok'));

    const discussionResponse = await fetch(
      `http://127.0.0.1:${addresses.adminAddress.port}/api/groups`, {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          ownerUin: 10001, memberUins: [10002, 10003], title: 'Admin discussion',
          type: 'discussion', publicId: 76543210,
        }),
      });
    assert.equal(discussionResponse.status, 201);
    const discussion = (await discussionResponse.json()).group;
    assert.equal(discussion.type, 'discussion');
    for (const client of [first, second]) {
      const relationPush = await client.reader.next();
      assert.equal(relationPush.command, protocol.COMMAND_BUDDY_LIST);
      const relation = protocol.decryptPayload(relationPush.payload, client.key);
      assert.equal(relation.readUInt32BE(9), discussion.id);
      assert.equal(relation[13], 4);
      const mappingPush = await client.reader.next();
      assert.equal(mappingPush.command, protocol.COMMAND_GROUP_MAPPING);
      const mapping = protocol.decryptPayload(mappingPush.payload, client.key);
      assert.equal(mapping.readUInt32BE(11), discussion.id);
    }
  } finally {
    if (first) first.socket.destroy();
    if (second) second.socket.destroy();
    await close(gateway);
  }
}

async function main() {
  persistenceTest();
  protocolFixturesTest();
  await integrationTest();
  process.stdout.write('QQ SQLite/group/presence compatibility self-test passed.\n');
}

main().catch((error) => {
  process.stderr.write(error.stack + '\n');
  process.exitCode = 1;
});
