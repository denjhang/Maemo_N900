'use strict';

const childProcess = require('node:child_process');
const path = require('node:path');

function encodedPowerShell(script) {
  return Buffer.from(script, 'utf16le').toString('base64');
}

function runDpapi(script, input) {
  const windowsRoot = process.env.SystemRoot || process.env.WINDIR || 'C:\\Windows';
  const powershell = path.join(
    windowsRoot, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
  const result = childProcess.spawnSync(powershell, [
    '-NoProfile', '-NonInteractive', '-EncodedCommand', encodedPowerShell(script),
  ], { input, encoding: 'utf8', windowsHide: true, timeout: 15000 });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(String(result.stderr || 'DPAPI operation failed').trim());
  return String(result.stdout || '').trim();
}

function protectSecret(secret) {
  const value = String(secret || '');
  if (!value) return '';
  if (process.platform !== 'win32') {
    throw new Error('persistent API keys require Windows DPAPI; use apiKeyEnv on this platform');
  }
  const input = Buffer.from(value, 'utf8').toString('base64');
  return runDpapi([
    'Add-Type -AssemblyName System.Security;',
    '$value=[Console]::In.ReadToEnd();',
    '$plain=[Convert]::FromBase64String($value);',
    '$protected=[Security.Cryptography.ProtectedData]::Protect($plain,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser);',
    '[Console]::Out.Write([Convert]::ToBase64String($protected));',
  ].join(''), input);
}

function unprotectSecret(protectedValue) {
  if (!protectedValue) return '';
  if (process.platform !== 'win32') return '';
  const output = runDpapi([
    'Add-Type -AssemblyName System.Security;',
    '$value=[Console]::In.ReadToEnd();',
    '$protected=[Convert]::FromBase64String($value);',
    '$plain=[Security.Cryptography.ProtectedData]::Unprotect($protected,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser);',
    '[Console]::Out.Write([Convert]::ToBase64String($plain));',
  ].join(''), String(protectedValue));
  return Buffer.from(output, 'base64').toString('utf8');
}

function resolveApiKey(provider) {
  if (provider.apiKeyEnv && process.env[provider.apiKeyEnv]) return process.env[provider.apiKeyEnv];
  return unprotectSecret(provider.apiKeyProtected);
}

module.exports = { protectSecret, resolveApiKey, unprotectSecret };
