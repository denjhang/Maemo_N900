'use strict';

const crypto = require('node:crypto');
const net = require('node:net');
const path = require('node:path');
const protocol = require('./protocol');
const symbian = require('./symbian-protocol');
const { AccountStore } = require('./store');
const { CAPABILITIES } = require('./capabilities');
const mediaProtocol = require('./media-service');

function jsonLogger(event) {
  process.stdout.write(JSON.stringify(Object.assign({
    time: new Date().toISOString(),
  }, event)) + '\n');
}

function createQQServer(options) {
  const settings = Object.assign({
    // Old J2ME builds may stay completely silent between user actions and do
    // not necessarily emit a heartbeat the gateway understands. An
    // application-level idle timeout therefore creates a half-dead UI: the
    // phone still looks online after the server has closed its socket.
    idleTimeoutMs: 0,
    keepAliveInitialDelayMs: 60000,
    traceProtocol: false,
    autoAcceptFriends: true,
    friendPushDelayMs: 150,
    sessionKeyFactory: () => crypto.randomBytes(16),
    logger: jsonLogger,
  }, options || {});
  const dataFile = Object.prototype.hasOwnProperty.call(settings, 'dataFile')
    ? settings.dataFile : path.join(__dirname, 'data', 'private-qq.sqlite');
  const store = settings.store || new AccountStore(dataFile, settings.initialData);
  const sessions = settings.sessions || new Map();

  function visiblePresence(uin) {
    const account = store.get(uin);
    if (account && account.type === 'virtual' && account.enabled) return 10;
    const session = sessions.get(Number(uin));
    if (!session || !session.loggedIn) return 20;
    return session.presence === 40 ? 20 : session.presence;
  }

  function writeEncrypted(session, command, sequence, plain, status) {
    if (!session || !session.sessionKey || session.socket.destroyed) return false;
    session.socket.write(protocol.createFrame({
      command,
      sequence,
      uin: session.uin,
      status: status || 0,
      payload: plain === undefined ? Buffer.alloc(0)
        : protocol.encryptPayload(plain, session.sessionKey),
    }));
    return true;
  }

  function pushPresenceChange(changedUin, reason) {
    const presence = visiblePresence(changedUin);
    for (const friend of store.friendsOf(changedUin)) {
      const target = sessions.get(friend.uin);
      if (!target || !target.loggedIn || target.socket.destroyed) continue;
      target.pushSequence = (target.pushSequence + 1) & 0xFFFF;
      writeEncrypted(target, protocol.COMMAND_BUDDY_DETAILS, target.pushSequence,
        protocol.buildBuddyDetailsPayload([{ uin: changedUin, presence }], true));
      settings.logger({
        event: 'presence_pushed', uin: friend.uin, friendUin: Number(changedUin),
        presence, reason,
      });
    }
  }

  function pushFriendRequestNotification(receiverUin, requesterUin, message, reason) {
    const target = sessions.get(Number(receiverUin));
    if (!target || !target.loggedIn || target.socket.destroyed) return false;
    target.pushSequence = (target.pushSequence + 1) & 0xFFFF;
    writeEncrypted(target, protocol.COMMAND_FRIEND_NOTIFICATION, target.pushSequence,
      protocol.buildFriendRequestNotificationPayload(requesterUin, message));
    settings.logger({
      event: 'friend_request_pushed', uin: target.uin,
      requesterUin: Number(requesterUin), command: '0x0095', reason,
    });
    return true;
  }

  function pushFriendAccepted(leftUin, rightUin, action, reason) {
    const pairs = [
      { session: sessions.get(Number(leftUin)), account: store.get(rightUin) },
      { session: sessions.get(Number(rightUin)), account: store.get(leftUin) },
    ];
    for (const pair of pairs) {
      if (!pair.session || !pair.account || pair.session.socket.destroyed) continue;
      pair.session.pushSequence = (pair.session.pushSequence + 1) & 0xFFFF;
      writeEncrypted(pair.session, protocol.COMMAND_FRIEND_RESULT,
        pair.session.pushSequence, protocol.buildFriendResultPayload(
          action === undefined ? 0 : action, pair.account.uin, 0));
      pair.session.pushSequence = (pair.session.pushSequence + 1) & 0xFFFF;
      writeEncrypted(pair.session, protocol.COMMAND_USER_PROFILE,
        pair.session.pushSequence, protocol.buildUserProfilePayload(pair.account, 2));
      settings.logger({
        event: 'friend_accepted_pushed', uin: pair.session.uin,
        friendUin: pair.account.uin, reason,
      });
    }
  }

  function pushGroupMappings(session, groups, reason) {
    const values = groups || store.groupsOf(session.uin);
    if (!session.loggedIn || session.socket.destroyed || values.length === 0) return false;
    session.pushSequence = (session.pushSequence + 1) & 0xFFFF;
    writeEncrypted(session, protocol.COMMAND_GROUP_MAPPING, session.pushSequence,
      protocol.buildGroupMappingPayload(values));
    settings.logger({
      event: 'group_mapping_pushed', uin: session.uin,
      groupIds: values.map((group) => group.id), reason,
    });
    return true;
  }

  function pushGroupRelations(session, groups, reason) {
    const values = groups || store.groupsOf(session.uin);
    if (!session.loggedIn || session.socket.destroyed || values.length === 0) return false;
    session.pushSequence = (session.pushSequence + 1) & 0xFFFF;
    writeEncrypted(session, protocol.COMMAND_BUDDY_LIST, session.pushSequence,
      protocol.buildBuddyListPayload(values.map((group) => ({
        uin: group.id, relationType: 4, groupIndex: 0,
      }))));
    settings.logger({
      event: 'group_relation_pushed', uin: session.uin,
      groupIds: values.map((group) => group.id), reason,
    });
    return true;
  }

  function pushGroupDiscovery(session, groups, reason) {
    // A live J2ME client needs both pieces: 0x0054 creates hp objects and
    // 0x00A4 records their public-number mapping. This makes newly created or
    // newly invited groups visible without requiring a relogin.
    const relationPushed = pushGroupRelations(session, groups, reason);
    const mappingPushed = pushGroupMappings(session, groups, reason);
    return relationPushed || mappingPushed;
  }

  function setSessionPresence(uin, value, reason) {
    const session = sessions.get(Number(uin));
    if (!session || !session.loggedIn) return false;
    const presence = protocol.normalizePresence(value);
    const changed = session.presence !== presence;
    session.presence = presence;
    if (changed) pushPresenceChange(session.uin, reason || 'changed');
    return true;
  }

  const sockets = new Set();
  const server = net.createServer((socket) => {
    sockets.add(socket);
    const peer = (socket.remoteAddress || 'unknown') + ':' + (socket.remotePort || 0);
    const state = {
      buffer: Buffer.alloc(0),
      sessionKey: null,
      sessionKeyCandidates: [],
      sessionKeyVariant: null,
      auxiliaryKey: null,
      uin: 0,
      account: null,
      loggedIn: false,
      clientFamily: 'legacy',
      presence: 20,
      auxiliaryPresenceSubscriptions: new Set(),
      socket,
      pushSequence: crypto.randomBytes(2).readUInt16BE(0),
    };
    settings.logger({ event: 'connection', peer });
    socket.setNoDelay(true);
    socket.setKeepAlive(true, settings.keepAliveInitialDelayMs);
    if (settings.idleTimeoutMs > 0) socket.setTimeout(settings.idleTimeoutMs);

    socket.on('timeout', () => {
      settings.logger({ event: 'timeout', peer });
      socket.destroy();
    });

    socket.on('data', (chunk) => {
      state.buffer = Buffer.concat([state.buffer, chunk]);
      const consumed = protocol.consumeFrames(state.buffer);
      state.buffer = consumed.remainder;
      for (const frame of consumed.frames) {
        settings.logger({
          event: 'packet', peer, command: '0x' + frame.command.toString(16).padStart(4, '0'),
          sequence: frame.sequence, uin: frame.uin, bytes: frame.length,
        });

        if (frame.command === protocol.COMMAND_GET_KEY) {
          state.uin = frame.uin;
          state.sessionKey = settings.sessionKeyFactory();
          // MobileQQ builds disagree on key placement, and QQ2013 for Symbian
          // merges one byte of its GET_KEY marker into the effective key. Try
          // the compatible forms and keep the one whose QQ-TEA padding is valid.
          state.sessionKeyCandidates = [
            { name: 'payload_first_16', key: state.sessionKey },
            ...(frame.payload.length >= 7 ? [{
              name: 'symbian_client_marker_or_byte_6',
              key: protocol.deriveSymbianSessionKey(state.sessionKey, frame.payload),
            }] : []),
            {
              name: 'envelope_status_then_payload_15',
              key: Buffer.concat([Buffer.from([0]), state.sessionKey.subarray(0, 15)]),
            },
            {
              name: 'payload_skip_first_then_trailing_status',
              key: Buffer.concat([state.sessionKey.subarray(1), Buffer.from([0])]),
            },
          ];
          state.sessionKeyVariant = 'payload_first_16';
          socket.write(protocol.createFrame({
            command: frame.command,
            sequence: frame.sequence,
            uin: frame.uin,
            status: 0,
            payload: protocol.buildGetKeyResponsePayload(state.sessionKey),
          }));
          settings.logger({
            event: 'get_key_ok', peer, uin: frame.uin,
            keyHex: settings.traceProtocol ? state.sessionKey.toString('hex') : undefined,
          });
          continue;
        }

        if (frame.command === protocol.COMMAND_LOGIN) {
          let login = null;
          let loginPlain = null;
          let loginParseError = null;
          if (state.sessionKey) {
            const candidates = state.sessionKeyCandidates.length
              ? state.sessionKeyCandidates : [{ name: 'payload_first_16', key: state.sessionKey }];
            for (const candidate of candidates) {
              loginPlain = protocol.decryptPayload(frame.payload, candidate.key);
              if (loginPlain) {
                state.sessionKey = candidate.key;
                state.sessionKeyVariant = candidate.name;
                if (candidate.name === 'symbian_client_marker_or_byte_6') {
                  state.clientFamily = 'symbian_s60';
                }
                break;
              }
            }
            if (loginPlain) {
              settings.logger({
                event: 'session_key_variant_selected', peer, uin: frame.uin,
                variant: state.sessionKeyVariant,
              });
              try {
                login = protocol.parseLoginRequestPayload(loginPlain);
              } catch (error) {
                loginParseError = error.message;
              }
            }
          }
          const account = login && frame.uin === state.uin
            && login.service === 9 && login.revision === 1
            ? store.authenticate(frame.uin, login.passwordDigest) : null;
          const accepted = account !== null;
          if (!accepted) {
            socket.write(protocol.createFrame({
              command: frame.command,
              sequence: frame.sequence,
              uin: frame.uin,
              status: 10,
            }));
            let reason = 'bad_credentials';
            if (!state.sessionKey) reason = 'missing_session_key';
            else if (!loginPlain) reason = 'decrypt_failed';
            else if (!login) reason = 'unsupported_login_payload';
            else if (frame.uin !== state.uin) reason = 'uin_mismatch';
            else if (login.service !== 9 || login.revision !== 1) {
              reason = 'unsupported_service_revision';
            }
            settings.logger({
              event: 'login_rejected', peer, uin: frame.uin, reason,
              parseError: loginParseError || undefined,
              plainBytes: loginPlain ? loginPlain.length : null,
              plainHex: settings.traceProtocol && loginPlain
                ? loginPlain.toString('hex') : undefined,
              encryptedHex: settings.traceProtocol ? frame.payload.toString('hex') : undefined,
            });
            continue;
          }

          state.loggedIn = true;
          state.account = account;
          state.presence = protocol.normalizePresence(login.presence);
          sessions.set(state.uin, state);
          const success = protocol.buildLoginSuccessPayload({
            port: settings.port || 14000,
            loginIp: settings.loginIp,
          });
          socket.write(protocol.createFrame({
            command: frame.command,
            sequence: frame.sequence,
            uin: frame.uin,
            status: 0,
            payload: protocol.encryptPayload(success, state.sessionKey),
          }));
          settings.logger({
            event: 'login_ok', peer, uin: frame.uin, presence: state.presence,
            clientConstant: login.clientConstant.toString('hex'),
            extensionTypes: login.extensions.map((extension) => extension.type),
          });
          pushPresenceChange(state.uin, 'login');
          pushGroupMappings(state, null, 'login');
          setTimeout(() => {
            if (!state.loggedIn || state.socket.destroyed || !state.account) return;
            for (const request of state.account.incomingRequests) {
              pushFriendRequestNotification(state.uin, request.from, request.message, 'login');
            }
          }, settings.friendPushDelayMs);
          if (settings.deliverOutbox) settings.deliverOutbox(state.uin);
          continue;
        }

        if (frame.command === protocol.COMMAND_LOGOUT && state.loggedIn) {
          state.loggedIn = false;
          if (sessions.get(state.uin) === state) sessions.delete(state.uin);
          pushPresenceChange(state.uin, 'logout');
          state.account = null;
          state.presence = 20;
          state.auxiliaryKey = null;
          socket.write(protocol.createFrame({
            command: frame.command,
            sequence: frame.sequence,
            uin: frame.uin,
            status: 0,
          }));
          settings.logger({ event: 'logout_ok', peer, uin: state.uin });
          // QQ2013 may retain the connection while it tears down and later
          // reinitialises its login engine. Let the client close or reuse the
          // socket instead of sending a server-side FIN immediately after ACK.
          continue;
        }

        if (frame.command === protocol.COMMAND_CHANGE_PRESENCE && state.loggedIn) {
          try {
            const plain = protocol.decryptPayload(frame.payload, state.sessionKey);
            const presence = protocol.parsePresenceChangePayload(plain);
            setSessionPresence(state.uin, presence, 'client_change');
            writeEncrypted(state, frame.command, frame.sequence, Buffer.alloc(0));
            settings.logger({ event: 'presence_changed', peer, uin: state.uin, presence });
          } catch (error) {
            socket.write(protocol.createFrame({
              command: frame.command, sequence: frame.sequence, uin: frame.uin, status: 1,
            }));
            settings.logger({
              event: 'presence_change_rejected', peer, uin: state.uin, message: error.message,
            });
          }
          continue;
        }

        if (frame.command === protocol.COMMAND_AUXILIARY_KEY && state.loggedIn) {
          state.auxiliaryKey = crypto.randomBytes(16);
          const plain = protocol.buildAuxiliaryKeyPayload(state.auxiliaryKey);
          socket.write(protocol.createFrame({
            command: frame.command,
            sequence: frame.sequence,
            uin: frame.uin,
            status: 0,
            payload: protocol.encryptPayload(plain, state.sessionKey),
          }));
          settings.logger({ event: 'auxiliary_key_ok', peer, uin: frame.uin });
          continue;
        }

        // 0x0054 creates the ks.buddy entries. 0x0069 then pages nickname and
        // other metadata onto those existing contacts; it cannot create a
        // missing buddy when the response lookup is made with an empty name.
        if (frame.command === protocol.COMMAND_FRIEND_ROSTER && state.loggedIn) {
          let request;
          try {
            request = protocol.parseFriendRosterRequest(
              protocol.decryptPayload(frame.payload, state.sessionKey));
          } catch (error) {
            settings.logger({
              event: 'friend_roster_rejected', peer, uin: state.uin, message: error.message,
            });
            socket.write(protocol.createFrame({
              command: frame.command, sequence: frame.sequence, uin: frame.uin, status: 1,
            }));
            continue;
          }
          const friends = store.friendsOf(state.uin);
          const plain = protocol.buildFriendRosterPayload(friends.map((friend) => ({
            uin: friend.uin,
            nickname: friend.nickname,
            group: 0,
            presence: visiblePresence(friend.uin),
            attributes: 0,
          })), -1);
          socket.write(protocol.createFrame({
            command: frame.command,
            sequence: frame.sequence,
            uin: frame.uin,
            status: 0,
            payload: protocol.encryptPayload(plain, state.sessionKey),
          }));
          settings.logger({
            event: 'friend_roster_ok', peer, uin: state.uin,
            requestCursor: request.cursor, requestReserved: request.reserved,
            count: friends.length, nextCursor: -1,
          });
          continue;
        }

        if (frame.command === protocol.COMMAND_BUDDY_LIST && state.loggedIn) {
          const request = protocol.decryptPayload(frame.payload, state.sessionKey);
          const firstCursor = request && request.length >= 8 ? request.readUInt32BE(0) : null;
          const secondCursor = request && request.length >= 8 ? request.readUInt32BE(4) : null;
          const friends = store.friendsOf(state.uin);
          // MobileQQ's np handler creates group placeholders from the same
          // 0x0054 relation stream when relationType is 4.  0x00A4 only
          // persists the internal/public number mapping; it does not add a
          // group to the in-memory list by itself.
          const relations = friends.map((friend) => ({
            uin: friend.uin,
            relationType: 1,
            groupIndex: 0,
          }));
          for (const group of store.groupsOf(state.uin)) {
            relations.push({
              uin: group.id,
              relationType: 4,
              groupIndex: 0,
            });
          }
          const plain = protocol.buildBuddyListPayload(relations);
          socket.write(protocol.createFrame({
            command: frame.command,
            sequence: frame.sequence,
            uin: frame.uin,
            status: 0,
            payload: protocol.encryptPayload(plain, state.sessionKey),
          }));
          settings.logger({
            event: 'buddy_list_ok', peer, uin: frame.uin,
            requestCursors: [firstCursor, secondCursor], count: friends.length,
            relationType: 1, groupIndex: 0, nextCursor: 0,
          });
          continue;
        }

        if (frame.command === protocol.COMMAND_BUDDY_DETAILS && state.loggedIn) {
          const request = protocol.decryptPayload(frame.payload, state.sessionKey);
          const subtype = request && request.length >= 1 ? request[0] : null;
          const cursor = request && request.length >= 5 ? request.readUInt32BE(1) : null;
          const friends = store.friendsOf(state.uin);
          const detailEntries = friends.length > 0 ? friends.map((friend) => ({
            uin: friend.uin,
            presence: visiblePresence(friend.uin),
          })) : [{ uin: state.uin, presence: state.presence }];
          const plain = protocol.buildBuddyDetailsPayload(detailEntries, true);
          socket.write(protocol.createFrame({
            command: frame.command,
            sequence: frame.sequence,
            uin: frame.uin,
            status: 0,
            payload: protocol.encryptPayload(plain, state.sessionKey),
          }));
          settings.logger({
            event: 'buddy_details_ok', peer, uin: frame.uin,
            subtype, cursor, count: detailEntries.length, finalPage: true, morePages: false,
            presence: detailEntries.map((entry) => ({ uin: entry.uin, value: entry.presence })),
          });
          continue;
        }

        if (frame.command === protocol.COMMAND_BUDDY_TOKENS && state.loggedIn) {
          let request;
          try {
            request = protocol.parseBuddyTokensRequest(
              protocol.decryptPayload(frame.payload, state.sessionKey));
          } catch (error) {
            settings.logger({
              event: 'buddy_tokens_rejected', peer, uin: state.uin, message: error.message,
            });
            socket.write(protocol.createFrame({
              command: frame.command, sequence: frame.sequence, uin: frame.uin, status: 1,
            }));
            continue;
          }
          const plain = protocol.buildBuddyTokensPayload(request);
          socket.write(protocol.createFrame({
            command: frame.command,
            sequence: frame.sequence,
            uin: frame.uin,
            status: 0,
            payload: protocol.encryptPayload(plain, state.sessionKey),
          }));
          settings.logger({
            event: 'buddy_tokens_ok', peer, uin: state.uin,
            subtype: request.subtype, cursor: request.cursor, targetUin: request.targetUin,
          });
          continue;
        }

        if (frame.command === protocol.COMMAND_FRIEND_METADATA && state.loggedIn) {
          try {
            const request = protocol.parseFriendMetadataRequest(
              protocol.decryptPayload(frame.payload, state.sessionKey));
            const accounts = request.uins.map((uin) => store.get(uin)).filter(Boolean);
            const plain = protocol.buildFriendMetadataPayload(request, accounts);
            writeEncrypted(state, frame.command, frame.sequence, plain);
            settings.logger({
              event: 'friend_metadata_ok', peer, uin: state.uin,
              subtype: request.subtype, requested: request.uins, returned: accounts.length,
            });
          } catch (error) {
            socket.write(protocol.createFrame({
              command: frame.command, sequence: frame.sequence, uin: frame.uin, status: 1,
            }));
            settings.logger({
              event: 'friend_metadata_rejected', peer, uin: state.uin, message: error.message,
            });
          }
          continue;
        }

        if (frame.command === protocol.COMMAND_FRIEND_ACTIVITY && state.loggedIn) {
          try {
            const request = protocol.parseFriendActivityRequest(
              protocol.decryptPayload(frame.payload, state.sessionKey));
            writeEncrypted(state, frame.command, frame.sequence,
              protocol.buildFriendActivityPayload(request.subtype));
            settings.logger({
              event: 'friend_activity_ok', peer, uin: state.uin,
              subtype: request.subtype, requested: request.uins,
            });
          } catch (error) {
            socket.write(protocol.createFrame({
              command: frame.command, sequence: frame.sequence, uin: frame.uin, status: 1,
            }));
            settings.logger({
              event: 'friend_activity_rejected', peer, uin: state.uin, message: error.message,
            });
          }
          continue;
        }

        if (frame.command === protocol.COMMAND_AUXILIARY_FEATURES && state.loggedIn) {
          const request = protocol.decryptPayload(frame.payload, state.sessionKey);
          writeEncrypted(state, frame.command, frame.sequence,
            protocol.buildAuxiliaryFeaturesPayload());
          settings.logger({
            event: 'auxiliary_features_ok', peer, uin: state.uin,
            requestHex: settings.traceProtocol && request ? request.toString('hex') : undefined,
          });
          continue;
        }

        if (frame.command === protocol.COMMAND_SEARCH_USER && state.loggedIn) {
          let search;
          try {
            search = protocol.parseSearchUserPayload(
              protocol.decryptPayload(frame.payload, state.sessionKey));
          } catch (error) {
            settings.logger({ event: 'search_rejected', peer, uin: state.uin, message: error.message });
            continue;
          }
          const results = store.search(search.query, state.uin);
          socket.write(protocol.createFrame({
            command: frame.command, sequence: frame.sequence, uin: frame.uin, status: 0,
            payload: protocol.encryptPayload(protocol.buildSearchUserPayload(results), state.sessionKey),
          }));
          settings.logger({
            event: 'search_ok', peer, uin: state.uin, query: search.query,
            results: results.map((account) => account.uin),
          });
          continue;
        }

        if (frame.command === protocol.COMMAND_USER_PROFILE && state.loggedIn) {
          let request;
          try {
            request = protocol.parseUserProfilePayload(
              protocol.decryptPayload(frame.payload, state.sessionKey));
          } catch (error) {
            settings.logger({ event: 'profile_rejected', peer, uin: state.uin, message: error.message });
            socket.write(protocol.createFrame({
              command: frame.command, sequence: frame.sequence, uin: frame.uin, status: 1,
            }));
            continue;
          }
          const account = store.get(request.targetUin);
          if (!account || ![1, 2, 3].includes(request.subtype)) {
            socket.write(protocol.createFrame({
              command: frame.command, sequence: frame.sequence, uin: frame.uin, status: 1,
            }));
          } else {
            socket.write(protocol.createFrame({
              command: frame.command, sequence: frame.sequence, uin: frame.uin, status: 0,
              payload: protocol.encryptPayload(
                protocol.buildUserProfilePayload(account, request.subtype), state.sessionKey),
            }));
          }
          settings.logger({
            event: 'profile_ok', peer, uin: state.uin, targetUin: request.targetUin,
            found: Boolean(account), subtype: request.subtype,
          });
          continue;
        }

        // The W995 search-results screen first asks whether the selected UIN
        // can be added. Its decoder expects: echoed UIN, result byte, decision
        // byte. Decision 0 makes the same callback send 0x0093/action 0.
        if (frame.command === protocol.COMMAND_FRIEND_PREFLIGHT && state.loggedIn) {
          let request;
          try {
            request = protocol.parseFriendPreflightPayload(
              protocol.decryptPayload(frame.payload, state.sessionKey));
          } catch (error) {
            settings.logger({ event: 'friend_preflight_rejected', peer,
              uin: state.uin, message: error.message });
            continue;
          }
          const requestedAccount = store.get(request.targetUin);
          const result = requestedAccount ? 0 : 153;
          const plain = protocol.buildFriendPreflightPayload(request.targetUin, result, 0);
          socket.write(protocol.createFrame({
            command: frame.command, sequence: frame.sequence, uin: frame.uin, status: 0,
            payload: protocol.encryptPayload(plain, state.sessionKey),
          }));
          settings.logger({
            event: 'friend_preflight_ok', peer, uin: state.uin,
            command: '0x0091', sequence: frame.sequence, targetUin: request.targetUin,
            found: Boolean(requestedAccount), result, decision: 0,
          });
          continue;
        }

        // The search-results UI on the Sony Ericsson build adds a contact via
        // command 0x0093/action 0 after the 0x0091 preflight. Some builds use
        // action 3 directly. It keeps its modal progress form open until
        // a response with the same command and sequence reaches its callback.
        if (frame.command === protocol.COMMAND_FRIEND_RESULT && state.loggedIn) {
          let request;
          try {
            request = protocol.parseFriendResultActionPayload(
              protocol.decryptPayload(frame.payload, state.sessionKey));
          } catch (error) {
            settings.logger({ event: 'friend_result_action_rejected', peer,
              uin: state.uin, message: error.message });
            socket.write(protocol.createFrame({
              command: frame.command, sequence: frame.sequence, uin: frame.uin, status: 0,
              payload: protocol.encryptPayload(
                protocol.buildFriendResultPayload(3, 0, 1, 'Invalid request'), state.sessionKey),
            }));
            continue;
          }
          settings.logger({
            event: 'friend_result_action_received', peer, uin: state.uin,
            command: '0x0093', sequence: frame.sequence,
            action: request.action, targetUin: request.targetUin, value: request.value,
          });
          const requestedAccount = store.get(request.targetUin);
          const inversePending = [0, 3].includes(request.action)
            && state.account.incomingRequests.some(
              (pending) => pending.from === Number(request.targetUin));
          let inverseAccepted = false;
          let requestResult;
          if (inversePending) {
            const result = store.acceptFriend(state.uin, request.targetUin);
            inverseAccepted = result.ok;
            requestResult = result.ok
              ? { ok: true, alreadyFriends: true, acceptedRequest: true } : result;
          } else {
            requestResult = [0, 3].includes(request.action)
              ? store.requestFriend(state.uin, request.targetUin, '')
              : { ok: false, reason: 'unsupported_action' };
          }
          const virtualPolicy = requestedAccount && requestedAccount.type === 'virtual'
            ? requestedAccount.virtual.friendPolicy : null;
          const policyAccepted = requestResult.ok && virtualPolicy
            && ['auto', 'delayed'].includes(virtualPolicy);
          const accepted = requestResult.ok
            && (inverseAccepted || policyAccepted || requestResult.alreadyFriends);
          // Result zero means that the operation was accepted by the server;
          // it does not mean a human recipient has approved the relationship.
          const responseResult = requestResult.ok && virtualPolicy !== 'deny' ? 0 : 1;
          if (requestResult.ok && virtualPolicy === 'deny' && !requestResult.alreadyFriends) {
            store.rejectFriend(request.targetUin, state.uin);
          }
          const completionDelay = policyAccepted && virtualPolicy === 'delayed'
            ? Math.max(1500, Math.min(30000, requestedAccount.virtual.replyDelayMinMs || 5000))
            : settings.friendPushDelayMs;
          setTimeout(() => {
            if (policyAccepted && !requestResult.alreadyFriends) {
              store.acceptFriend(request.targetUin, state.uin);
            }
            if (!socket.destroyed) {
              socket.write(protocol.createFrame({
                command: frame.command, sequence: frame.sequence, uin: frame.uin, status: 0,
                payload: protocol.encryptPayload(protocol.buildFriendResultPayload(
                  request.action, request.targetUin, responseResult,
                  responseResult ? 'Request was not accepted' : ''), state.sessionKey),
              }));
              if (accepted && requestedAccount) {
                state.pushSequence = (state.pushSequence + 1) & 0xFFFF;
                socket.write(protocol.createFrame({
                  command: protocol.COMMAND_USER_PROFILE,
                  sequence: state.pushSequence,
                  uin: state.uin,
                  status: 0,
                  payload: protocol.encryptPayload(
                    protocol.buildUserProfilePayload(requestedAccount, 2), state.sessionKey),
                }));
              }
            }
            const targetSession = sessions.get(request.targetUin);
            if (accepted && targetSession && targetSession.loggedIn
                && !targetSession.socket.destroyed) {
              targetSession.pushSequence = (targetSession.pushSequence + 1) & 0xFFFF;
              targetSession.socket.write(protocol.createFrame({
                command: protocol.COMMAND_FRIEND_RESULT,
                sequence: targetSession.pushSequence,
                uin: targetSession.uin,
                status: 0,
                payload: protocol.encryptPayload(protocol.buildFriendResultPayload(
                  request.action, state.uin, 0), targetSession.sessionKey),
              }));
              targetSession.pushSequence = (targetSession.pushSequence + 1) & 0xFFFF;
              targetSession.socket.write(protocol.createFrame({
                command: protocol.COMMAND_USER_PROFILE,
                sequence: targetSession.pushSequence,
                uin: targetSession.uin,
                status: 0,
                payload: protocol.encryptPayload(
                  protocol.buildUserProfilePayload(state.account, 2), targetSession.sessionKey),
                }));
            }
            if (responseResult === 0 && !accepted && requestedAccount) {
              pushFriendRequestNotification(
                request.targetUin, state.uin, '', 'live_request');
            }
            settings.logger({
              event: 'friend_result_action_ok', peer, uin: state.uin,
              targetUin: request.targetUin, action: request.action,
              accepted, pending: responseResult === 0 && !accepted,
              inverseAccepted, policy: virtualPolicy || 'human-approval',
              command: '0x0093', sequence: frame.sequence, result: responseResult,
            });
          }, completionDelay);
          continue;
        }

        if (frame.command === protocol.COMMAND_FRIEND_ACTION && state.loggedIn) {
          let friendPlain;
          try {
            friendPlain = protocol.decryptPayload(frame.payload, state.sessionKey);
          } catch (error) {
            settings.logger({
              event: 'friend_action_rejected', peer, uin: state.uin,
              message: error.message, stage: 'decrypt',
            });
            socket.write(protocol.createFrame({
              command: frame.command, sequence: frame.sequence, uin: frame.uin, status: 1,
            }));
            continue;
          }

          // Command 0x006B is multiplexed. Only subtype 1 packets long enough
          // to contain a target UIN are friend-add requests; the client also
          // sends short status/housekeeping forms. Treating those forms as a
          // failed add request creates a bogus friend-validation notification.
          if (friendPlain.length < 9 || friendPlain[0] !== 1) {
            const subtype = friendPlain.length > 0 ? friendPlain[0] : 0;
            socket.write(protocol.createFrame({
              command: frame.command, sequence: frame.sequence, uin: frame.uin, status: 0,
              payload: protocol.encryptPayload(
                protocol.buildFriendServiceAck(subtype), state.sessionKey),
            }));
            settings.logger({
              event: 'friend_service_ok', peer, uin: state.uin,
              subtype, requestHex: friendPlain.toString('hex'),
            });
            continue;
          }

          let request;
          try {
            request = protocol.parseFriendActionPayload(friendPlain);
          } catch (error) {
            settings.logger({
              event: 'friend_action_rejected', peer, uin: state.uin,
              message: error.message, requestHex: friendPlain.toString('hex'),
            });
            socket.write(protocol.createFrame({
              command: frame.command, sequence: frame.sequence, uin: frame.uin, status: 0,
              payload: protocol.encryptPayload(protocol.buildFriendActionAck(1, 1), state.sessionKey),
            }));
            continue;
          }
          const requestedAccount = store.get(request.targetUin);
          const inversePending = state.account.incomingRequests.some(
            (pending) => pending.from === Number(request.targetUin));
          let inverseAccepted = false;
          let result;
          if (inversePending) {
            const acceptedRequest = store.acceptFriend(state.uin, request.targetUin);
            inverseAccepted = acceptedRequest.ok;
            result = acceptedRequest.ok
              ? { ok: true, alreadyFriends: true, acceptedRequest: true } : acceptedRequest;
          } else {
            result = store.requestFriend(state.uin, request.targetUin, request.message);
          }
          const virtualPolicy = requestedAccount && requestedAccount.type === 'virtual'
            ? requestedAccount.virtual.friendPolicy : null;
          const autoAccepted = result.ok && virtualPolicy === 'auto';
          const delayedAccepted = result.ok && !result.alreadyFriends && virtualPolicy === 'delayed';
          const accepted = result.ok
            && (inverseAccepted || autoAccepted || result.alreadyFriends);
          let acknowledgementResult = result.ok ? 0 : 1;
          if (result.ok && virtualPolicy === 'deny' && !result.alreadyFriends) {
            store.rejectFriend(request.targetUin, state.uin);
            acknowledgementResult = 1;
          }
          if (autoAccepted && !result.alreadyFriends) {
            store.acceptFriend(request.targetUin, state.uin);
          }
          socket.write(protocol.createFrame({
            command: frame.command, sequence: frame.sequence, uin: frame.uin,
            status: 0,
            payload: protocol.encryptPayload(
              protocol.buildFriendActionAck(acknowledgementResult, request.subtype), state.sessionKey),
          }));
          settings.logger({
            event: 'friend_action_ok', peer, uin: state.uin,
            targetUin: request.targetUin, accepted,
            pending: result.ok && !accepted && !delayedAccepted,
            inverseAccepted, delayed: delayedAccepted,
            policy: virtualPolicy || 'human-approval',
            subtype: request.subtype, action: request.action,
          });
          if (accepted || delayedAccepted) {
            const acceptanceDelay = delayedAccepted
              ? Math.max(1500, Math.min(30000, requestedAccount.virtual.replyDelayMinMs || 5000))
              : settings.friendPushDelayMs;
            setTimeout(() => {
              if (delayedAccepted) store.acceptFriend(request.targetUin, state.uin);
              const pairs = [
                { session: state, account: store.get(request.targetUin) },
                { session: sessions.get(request.targetUin), account: state.account },
              ];
              for (const pair of pairs) {
                if (!pair.session || !pair.account || pair.session.socket.destroyed) continue;
                pair.session.pushSequence = (pair.session.pushSequence + 1) & 0xFFFF;
                pair.session.socket.write(protocol.createFrame({
                  command: protocol.COMMAND_FRIEND_RESULT,
                  sequence: pair.session.pushSequence,
                  uin: pair.session.uin,
                  status: 0,
                  payload: protocol.encryptPayload(
                    protocol.buildFriendResultPayload(request.action, pair.account.uin, 0),
                    pair.session.sessionKey),
                }));
                settings.logger({
                  event: 'friend_result_pushed', uin: pair.session.uin,
                  friendUin: pair.account.uin, action: request.action,
                });
                pair.session.pushSequence = (pair.session.pushSequence + 1) & 0xFFFF;
                pair.session.socket.write(protocol.createFrame({
                  command: protocol.COMMAND_USER_PROFILE,
                  sequence: pair.session.pushSequence,
                  uin: pair.session.uin,
                  status: 0,
                  payload: protocol.encryptPayload(
                    protocol.buildUserProfilePayload(pair.account, 2), pair.session.sessionKey),
                }));
                settings.logger({
                  event: 'friend_profile_pushed', uin: pair.session.uin, friendUin: pair.account.uin,
                });
              }
            }, acceptanceDelay);
          } else if (result.ok && virtualPolicy !== 'deny') {
            pushFriendRequestNotification(
              request.targetUin, state.uin, request.message, 'live_request');
          }
          continue;
        }

        if (frame.command === protocol.COMMAND_GROUP_SYNC && state.loggedIn) {
          const request = protocol.decryptPayload(frame.payload, state.sessionKey);
          writeEncrypted(state, frame.command, frame.sequence, Buffer.alloc(0));
          settings.logger({
            event: 'group_sync_ok', peer, uin: state.uin,
            groups: store.groupsOf(state.uin).map((group) => group.id),
            requestHex: settings.traceProtocol && request ? request.toString('hex') : undefined,
          });
          continue;
        }

        if (frame.command === protocol.COMMAND_GROUP_SERVICE && state.loggedIn) {
          let request;
          try {
            request = protocol.parseGroupServiceRequest(
              protocol.decryptPayload(frame.payload, state.sessionKey));
          } catch (error) {
            socket.write(protocol.createFrame({
              command: frame.command, sequence: frame.sequence, uin: frame.uin, status: 1,
            }));
            settings.logger({
              event: 'group_service_rejected', peer, uin: state.uin, message: error.message,
            });
            continue;
          }
          const group = request.groupId == null ? null : store.getGroup(request.groupId);
          const isMember = group && group.members.some((member) => member.uin === state.uin);
          let result = isMember ? 0 : 1;
          let plain;
          if (request.subtype === 4 && isMember) {
            plain = protocol.buildGroupInfoPayload(group);
          } else if (request.subtype === 26 && isMember && request.text) {
            const saved = store.saveGroupMessage(group.id, state.uin, request.text);
            plain = protocol.buildGroupServiceAck(request.subtype, 0);
            const delivery = settings.deliverGroup
              ? settings.deliverGroup(group.id, state.uin, request.text) : { delivered: 0 };
            settings.logger({
              event: 'group_message_sent', peer, messageId: saved.id,
              groupId: group.id, from: state.uin, text: request.text,
              authorized: true, transport: '0x006d/26', delivery,
            });
          } else if (request.subtype === 2 && isMember && request.action === 2) {
            for (const memberUin of request.memberUins) {
              const invited = store.inviteGroupMember(group.id, state.uin, memberUin);
              if (!invited.ok) result = 1;
              if (invited.ok && !invited.alreadyMember) {
                const invitedSession = sessions.get(Number(memberUin));
                if (invitedSession) pushGroupDiscovery(invitedSession, [group], 'invited');
              }
            }
            plain = protocol.buildGroupServiceAck(request.subtype, result);
          } else {
            // Other maintenance subtypes are acknowledged so their modal UI
            // does not stall, without mutating group membership speculatively.
            plain = protocol.buildGroupServiceAck(request.subtype, result);
          }
          writeEncrypted(state, frame.command, frame.sequence, plain);
          settings.logger({
            event: 'group_service_ok', peer, uin: state.uin,
            subtype: request.subtype, groupId: request.groupId,
            action: request.action, memberUins: request.memberUins, result,
          });
          continue;
        }

        if (frame.command === protocol.COMMAND_GROUP_SEND && state.loggedIn
            && settings.mediaService) {
          const requestPlain = protocol.decryptPayload(frame.payload, state.sessionKey);
          if (requestPlain && settings.mediaService.isNegotiation(state.uin, requestPlain)) {
            try {
              const request = mediaProtocol.parseNegotiation(requestPlain);
              const plain = request.subtype === 6
                ? settings.mediaService.issueTicket(state.uin, request).payload
                : settings.mediaService.register(state.uin, request, socket.localAddress);
              writeEncrypted(state, frame.command, frame.sequence, plain);
              settings.logger({
                event: request.subtype === 6 ? 'media_ticket_issued' : 'media_upload_registered',
                peer, uin: state.uin, targetUin: request.targetUin,
                filename: request.filename, bytes: request.size,
              });
            } catch (error) {
              socket.write(protocol.createFrame({
                command: frame.command, sequence: frame.sequence, uin: frame.uin, status: 1,
              }));
              settings.logger({ event: 'media_negotiation_rejected', peer, uin: state.uin,
                message: error.message });
            }
            continue;
          }
        }

        if (frame.command === protocol.COMMAND_GROUP_SEND && state.loggedIn) {
          let message;
          try {
            message = protocol.parseGroupSendPayload(
              protocol.decryptPayload(frame.payload, state.sessionKey));
          } catch (error) {
            socket.write(protocol.createFrame({
              command: frame.command, sequence: frame.sequence, uin: frame.uin, status: 1,
            }));
            settings.logger({
              event: 'group_message_rejected', peer, uin: state.uin, message: error.message,
            });
            continue;
          }
          const group = store.getGroup(message.groupId);
          const authorized = Boolean(group
            && group.members.some((member) => member.uin === state.uin));
          let saved = null;
          if (authorized) saved = store.saveGroupMessage(group.id, state.uin, message.text);
          writeEncrypted(state, frame.command, frame.sequence, Buffer.alloc(0), authorized ? 0 : 1);
          let delivery = { delivered: 0, virtualQueued: 0 };
          if (authorized && settings.deliverGroup) {
            delivery = settings.deliverGroup(group.id, state.uin, message.text) || delivery;
          }
          settings.logger({
            event: 'group_message_sent', peer, messageId: saved && saved.id,
            groupId: group ? group.id : message.groupId, from: state.uin,
            text: message.text, authorized, delivery,
          });
          continue;
        }

        if (frame.command === protocol.COMMAND_SEND_TEXT && state.loggedIn) {
          let message;
          try {
            message = protocol.parseSendTextPayload(
              protocol.decryptPayload(frame.payload, state.sessionKey));
          } catch (error) {
            settings.logger({ event: 'message_rejected', peer, uin: state.uin, message: error.message });
            continue;
          }
          const friendUins = store.friendsOf(state.uin).map((friend) => friend.uin);
          const authorized = friendUins.includes(message.targetUin);
          const targetAccount = store.get(message.targetUin);
          const target = sessions.get(message.targetUin);
          if (authorized) store.saveMessage(state.uin, message.targetUin, message.text);
          socket.write(protocol.createFrame({
            command: frame.command, sequence: frame.sequence, uin: frame.uin,
            status: authorized ? 0 : 1,
            payload: authorized ? protocol.encryptPayload(Buffer.alloc(0), state.sessionKey) : Buffer.alloc(0),
          }));
          let delivered = false;
          if (authorized && targetAccount && targetAccount.type === 'virtual' && settings.virtualRuntime) {
            delivered = settings.virtualRuntime.receive(message.targetUin, state.uin);
          } else if (authorized && target && target.loggedIn && !target.socket.destroyed) {
            target.pushSequence = (target.pushSequence + 1) & 0xFFFF;
            target.socket.write(protocol.createFrame({
              command: protocol.COMMAND_INCOMING_TEXT,
              sequence: target.pushSequence,
              uin: target.uin,
              status: 0,
              payload: protocol.encryptPayload(
                protocol.buildIncomingTextPayload(state.uin, message.text), target.sessionKey),
            }));
            delivered = true;
          }
          const queuedOffline = authorized && targetAccount
            && targetAccount.type !== 'virtual' && !delivered;
          if (queuedOffline) {
            store.enqueueOutbox(state.uin, message.targetUin, message.text);
          }
          settings.logger({
            event: 'message_sent', peer, from: state.uin, to: message.targetUin,
            text: message.text, authorized, delivered, queuedOffline,
          });
          continue;
        }

        if (frame.command === protocol.COMMAND_EXTENDED_SERVICE && state.loggedIn) {
          const request = protocol.decryptPayload(frame.payload, state.sessionKey);
          const subtype = request && request.length >= 1 ? request[0] : 0;
          const plain = protocol.buildExtendedServicePayload(subtype, state.uin);
          socket.write(protocol.createFrame({
            command: frame.command,
            sequence: frame.sequence,
            uin: frame.uin,
            status: 0,
            payload: protocol.encryptPayload(plain, state.sessionKey),
          }));
          settings.logger({
            event: 'extended_service_ok', peer, uin: frame.uin, subtype,
            requestHex: settings.traceProtocol && request ? request.toString('hex') : undefined,
            responseBytes: plain.length,
          });
          continue;
        }

        if (frame.command === protocol.COMMAND_MEDIA_NOTIFY && state.loggedIn
            && settings.mediaService) {
          try {
            const requestPlain = protocol.decryptPayload(frame.payload, state.sessionKey);
            if (!requestPlain) throw new Error('QQ-TEA decryption failed');
            const request = mediaProtocol.parseServiceEnvelope(requestPlain);
            if (request.subtype === 1) {
              settings.mediaService.announce(state.uin, request, () => {
                writeEncrypted(state, protocol.COMMAND_MEDIA_TRANSFER, frame.sequence,
                  mediaProtocol.buildServiceResult(request.targetUin, 3, request.hash));
              });
              writeEncrypted(state, protocol.COMMAND_MEDIA_TRANSFER, frame.sequence,
                mediaProtocol.buildServiceResult(request.targetUin, 2, request.hash, 1));
            } else {
              writeEncrypted(state, protocol.COMMAND_MEDIA_TRANSFER, frame.sequence,
                mediaProtocol.buildServiceResult(request.targetUin, 2,
                  request.hash || Buffer.alloc(0), 1));
            }
            settings.logger({ event: 'media_announcement_received', peer, uin: state.uin,
              targetUin: request.targetUin, subtype: request.subtype,
              mediaType: request.mediaType, filename: request.filename });
          } catch (error) {
            socket.write(protocol.createFrame({
              command: frame.command, sequence: frame.sequence, uin: frame.uin, status: 1,
            }));
            settings.logger({ event: 'media_announcement_rejected', peer, uin: state.uin,
              message: error.message });
          }
          continue;
        }

        if (frame.command === protocol.COMMAND_MEDIA_COMPLETION && state.loggedIn
            && settings.mediaService) {
          // Upload completion is finalized by the HTTP Range response and the
          // deferred 0x00B5 acknowledgement. This auxiliary packet is safe to
          // acknowledge even though its legacy wrapper carries no new bytes.
          writeEncrypted(state, frame.command, frame.sequence, Buffer.alloc(0));
          settings.logger({ event: 'media_completion_aux_ack', peer, uin: state.uin });
          continue;
        }

        if (frame.command === protocol.COMMAND_MEDIA_TRANSFER && state.loggedIn) {
          const requestPlain = protocol.decryptPayload(frame.payload, state.sessionKey);
          if (!requestPlain) {
            socket.write(protocol.createFrame({
              command: frame.command, sequence: frame.sequence, uin: frame.uin, status: 1,
            }));
            settings.logger({ event: 'media_announcement_rejected', peer, uin: state.uin,
              command: '0x0065', message: 'QQ-TEA decryption failed' });
            continue;
          }
          try {
            const request = mediaProtocol.parseServiceEnvelope(requestPlain);
            if (!settings.mediaService) throw new Error('media service is unavailable');
            if (request.subtype === 1) {
              settings.mediaService.announce(state.uin, request, () => {
                writeEncrypted(state, protocol.COMMAND_MEDIA_TRANSFER, frame.sequence,
                  mediaProtocol.buildServiceResult(request.targetUin, 3, request.hash));
              });
              // The phone waits for this acceptance before it starts or keeps
              // the HTTP uploader alive. Completion is sent separately above.
              writeEncrypted(state, protocol.COMMAND_MEDIA_TRANSFER, frame.sequence,
                mediaProtocol.buildServiceResult(request.targetUin, 2, request.hash, 1));
            } else {
              writeEncrypted(state, protocol.COMMAND_MEDIA_TRANSFER, frame.sequence,
                mediaProtocol.buildServiceResult(request.targetUin, 2,
                  request.hash || Buffer.alloc(0), 1));
            }
            settings.logger({ event: 'media_announcement_received', peer, uin: state.uin,
              command: '0x0065', targetUin: request.targetUin, subtype: request.subtype,
              layout: request.layout, mediaType: request.mediaType, filename: request.filename });
          } catch (error) {
            // 0x0065 also carries unrelated online-picture maintenance
            // packets. Preserve their old non-blocking acknowledgement.
            const peerUin = requestPlain.length >= 16 ? requestPlain.readUInt32BE(12)
              : requestPlain.length >= 10 ? requestPlain.readUInt32BE(6) : 0;
            writeEncrypted(state, frame.command, frame.sequence,
              mediaProtocol.buildOnlinePictureAck(peerUin));
            settings.logger({
              event: 'media_signaling_acknowledged', peer, uin: state.uin,
              command: '0x0065', plainBytes: requestPlain.length,
              fallbackReason: error.message,
              requestHex: settings.traceProtocol ? requestPlain.toString('hex') : undefined,
            });
          }
          continue;
        }

        if (frame.command === symbian.COMMAND_MESSAGE_ACCOST && state.loggedIn) {
          state.clientFamily = 'symbian_s60';
          try {
            const requestPlain = protocol.decryptPayload(frame.payload, state.sessionKey);
            if (!requestPlain) throw new Error('QQ-TEA decryption failed');
            const envelope = symbian.parseAccostEnvelope(requestPlain);
            const response = symbian.createAccostResponse(envelope);
            socket.write(protocol.createFrame({
              command: frame.command,
              sequence: frame.sequence,
              uin: frame.uin,
              status: 0,
              payload: protocol.encryptPayload(response.payload, state.sessionKey),
            }));
            settings.logger({
              event: 'symbian_accost_ok', peer, uin: state.uin,
              servant: envelope.request.servant,
              functionName: envelope.request.functionName,
              requestId: envelope.request.requestId,
              responseKind: response.kind,
              parameterNames: response.parameterNames,
            });
          } catch (error) {
            socket.write(protocol.createFrame({
              command: frame.command,
              sequence: frame.sequence,
              uin: frame.uin,
              status: 1,
            }));
            settings.logger({
              event: 'symbian_accost_rejected', peer, uin: state.uin,
              message: error.message,
            });
          }
          continue;
        }

        if (frame.command === symbian.COMMAND_WUP && state.loggedIn) {
          state.clientFamily = 'symbian_s60';
          try {
            const requestPlain = protocol.decryptPayload(frame.payload, state.sessionKey);
            if (!requestPlain) throw new Error('QQ-TEA decryption failed');
            const envelope = symbian.parseWupEnvelope(requestPlain);
            const response = symbian.createWupResponse(envelope, {
              getDiscussions: () => store.groupsOf(state.uin)
                .filter((group) => group.type === 'discussion'),
              getDiscussion: (groupId) => {
                const group = store.getGroup(groupId);
                return group && group.type === 'discussion'
                  && group.members.some((member) => member.uin === state.uin) ? group : null;
              },
              createDiscussion: (details) => {
                const memberUins = details.memberUins.filter((uin) => uin !== state.uin
                  && Boolean(store.get(uin)));
                return store.createGroup({
                  ownerUin: state.uin,
                  memberUins,
                  type: 'discussion',
                  title: details.title || `${state.account.nickname}的讨论组`,
                });
              },
            });
            socket.write(protocol.createFrame({
              command: frame.command,
              sequence: frame.sequence,
              uin: frame.uin,
              status: 0,
              payload: protocol.encryptPayload(response.payload, state.sessionKey),
            }));
            settings.logger({
              event: 'symbian_wup_ok', peer, uin: state.uin,
              route: envelope.route,
              servant: envelope.request.servant,
              functionName: envelope.request.functionName,
              requestId: envelope.request.requestId,
              responseKind: response.kind,
              groupId: response.group ? response.group.id : undefined,
              requestParameterNames: [...envelope.request.parameters.keys()],
              parameterNames: response.parameterNames,
              requestHex: settings.traceProtocol ? requestPlain.toString('hex') : undefined,
              responseHex: settings.traceProtocol ? response.payload.toString('hex') : undefined,
              suffixHex: settings.traceProtocol && envelope.suffix.length
                ? envelope.suffix.toString('hex') : undefined,
            });
          } catch (error) {
            socket.write(protocol.createFrame({
              command: frame.command,
              sequence: frame.sequence,
              uin: frame.uin,
              status: 1,
            }));
            settings.logger({
              event: 'symbian_wup_rejected', peer, uin: state.uin,
              message: error.message,
            });
          }
          continue;
        }

        if (frame.command === symbian.COMMAND_AUXILIARY_PRESENCE && state.loggedIn) {
          state.clientFamily = 'symbian_s60';
          try {
            const plain = protocol.decryptPayload(frame.payload, state.sessionKey);
            const request = symbian.parseAuxiliaryPresenceRequest(plain);
            if (request.action === 'subscribe') {
              state.auxiliaryPresenceSubscriptions.add(request.targetUin);
            } else {
              state.auxiliaryPresenceSubscriptions.delete(request.targetUin);
            }
            // Captures show this command as a one-way subscription update. A
            // fabricated response payload is riskier than consuming it and
            // delivering actual presence changes through the established
            // buddy-detail push command.
            settings.logger({
              event: 'symbian_auxiliary_presence_ok', peer, uin: state.uin,
              action: request.action, targetUin: request.targetUin, flag: request.flag,
            });
          } catch (error) {
            settings.logger({
              event: 'symbian_auxiliary_presence_rejected', peer, uin: state.uin,
              message: error.message,
            });
          }
          continue;
        }

        if (frame.command === symbian.COMMAND_BUDDY_STATUS && state.loggedIn) {
          state.clientFamily = 'symbian_s60';
          const requestPlain = protocol.decryptPayload(frame.payload, state.sessionKey);
          let request;
          try {
            request = symbian.parseBuddyStatusRequest(requestPlain);
          } catch (error) {
            socket.write(protocol.createFrame({
              command: frame.command, sequence: frame.sequence, uin: frame.uin, status: 1,
            }));
            settings.logger({
              event: 'symbian_buddy_status_rejected', peer, uin: state.uin,
              message: error.message,
            });
            continue;
          }
          const friends = store.friendsOf(state.uin);
          const pageSize = Math.max(1, Math.min(request.pageSize || 200, 200));
          const page = friends.slice(request.cursor, request.cursor + pageSize);
          const finalPage = request.cursor + page.length >= friends.length;
          const plain = symbian.buildBuddyStatusResponse(page.map((friend) => ({
            uin: friend.uin,
            group: 0,
          })), { cursor: request.cursor, finalPage });
          socket.write(protocol.createFrame({
            command: frame.command,
            sequence: frame.sequence,
            uin: frame.uin,
            status: 0,
            payload: protocol.encryptPayload(plain, state.sessionKey),
          }));
          settings.logger({
            event: 'symbian_buddy_status_ok', peer, uin: state.uin,
            result: plain[0], terminal: finalPage, count: page.length,
            cursor: request.cursor, nextCursor: request.cursor + page.length,
            friendUins: page.map((friend) => friend.uin),
            requestHex: settings.traceProtocol ? requestPlain.toString('hex') : undefined,
          });
          continue;
        }

        const unimplementedPlain = state.sessionKey
          ? protocol.decryptPayload(frame.payload, state.sessionKey) : null;
        settings.logger({
          event: 'unimplemented_command', peer, uin: frame.uin,
          command: '0x' + frame.command.toString(16).padStart(4, '0'),
          encryptedBytes: frame.payload.length, loggedIn: state.loggedIn,
          plainBytes: unimplementedPlain ? unimplementedPlain.length : null,
          plainHex: settings.traceProtocol && unimplementedPlain
            ? unimplementedPlain.toString('hex') : undefined,
        });
      }
    });

    socket.on('error', (error) => {
      settings.logger({ event: 'socket_error', peer, message: error.message });
    });
    socket.on('close', () => {
      sockets.delete(socket);
      const wasOnline = state.loggedIn && sessions.get(state.uin) === state;
      if (sessions.get(state.uin) === state) sessions.delete(state.uin);
      state.loggedIn = false;
      state.presence = 20;
      if (wasOnline) pushPresenceChange(state.uin, 'disconnect');
      settings.logger({ event: 'disconnect', peer, uin: state.uin || undefined });
    });
  });
  server.qqStore = store;
  server.qqSessions = sessions;
  server.closeAllConnections = () => {
    for (const socket of sockets) socket.destroy();
  };
  server.setPresence = setSessionPresence;
  server.pushGroupMappings = (uin, groups, reason) => {
    const session = sessions.get(Number(uin));
    return session ? pushGroupMappings(session, groups, reason || 'server') : false;
  };
  server.pushGroupDiscovery = (uin, groups, reason) => {
    const session = sessions.get(Number(uin));
    return session ? pushGroupDiscovery(session, groups, reason || 'server') : false;
  };
  server.pushFriendAccepted = (leftUin, rightUin, reason) => {
    pushFriendAccepted(leftUin, rightUin, 0, reason || 'server');
  };
  server.pushFriendRequest = (receiverUin, requesterUin, message, reason) =>
    pushFriendRequestNotification(
      receiverUin, requesterUin, message, reason || 'server');
  return server;
}

function parseArguments(args, environment) {
  const values = {
    host: environment.QQ_LISTEN_ADDRESS || '127.0.0.1',
    port: Number(environment.QQ_PORT || 14000),
    testUin: Number(environment.QQ_TEST_UIN || 10001),
    testPassword: environment.QQ_TEST_PASSWORD || 'qqtest123',
    traceProtocol: environment.QQ_TRACE_PROTOCOL === '1',
    dataFile: environment.QQ_DATA_FILE || path.join(__dirname, 'data', 'private-qq.sqlite'),
    autoAcceptFriends: environment.QQ_AUTO_ACCEPT_FRIENDS !== '0',
  };
  const mappings = {
    '--host': 'host', '--port': 'port', '--uin': 'testUin', '--password': 'testPassword',
    '--trace-protocol': 'traceProtocol',
    '--data': 'dataFile', '--auto-accept-friends': 'autoAcceptFriends',
  };
  for (let index = 0; index < args.length; index += 2) {
    const key = mappings[args[index]];
    if (!key || args[index + 1] === undefined) throw new Error('invalid command-line arguments');
    values[key] = key === 'port' || key === 'testUin' ? Number(args[index + 1])
      : key === 'traceProtocol' || key === 'autoAcceptFriends'
        ? args[index + 1] === 'true' || args[index + 1] === '1'
        : args[index + 1];
  }
  if (!Number.isInteger(values.port) || values.port < 0 || values.port > 65535) {
    throw new Error('port must be between 0 and 65535');
  }
  if (!Number.isInteger(values.testUin) || values.testUin <= 0 || values.testUin > 0xFFFFFFFF) {
    throw new Error('test UIN must fit in an unsigned 32-bit integer');
  }
  if (!/^[\x20-\x7E]+$/.test(values.testPassword)) {
    throw new Error('test password must use printable ASCII characters');
  }
  return values;
}

if (require.main === module) {
  try {
    const options = parseArguments(process.argv.slice(2), process.env);
    const server = createQQServer(options);
    server.listen(options.port, options.host, () => {
      const address = server.address();
      jsonLogger({
        event: 'listening', host: address.address, port: address.port,
        accounts: [10001, 10002], autoAcceptFriends: options.autoAcceptFriends,
        capabilities: CAPABILITIES,
        warning: 'Use only the documented fake test password; never enter a real QQ password.',
      });
    });
  } catch (error) {
    process.stderr.write('QQ private server failed: ' + error.message + '\n');
    process.exitCode = 1;
  }
}

module.exports = { createQQServer, parseArguments };
