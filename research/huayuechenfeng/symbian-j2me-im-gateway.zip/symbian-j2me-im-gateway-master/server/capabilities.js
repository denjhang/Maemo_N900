'use strict';

const CAPABILITIES = Object.freeze({
  protocolVersion: 1,
  accounts: true,
  search: true,
  friendRequests: true,
  friendRequestNotifications: true,
  reciprocalFriendApproval: true,
  presence: true,
  presenceStates: Object.freeze(['online', 'offline', 'away', 'invisible']),
  textMessages: true,
  // 群聊/讨论组尚未达到发布验收标准，公开版本不承诺该功能。
  groups: false,
  discussions: false,
  groupInvitations: false,
  mobileGroupManagement: false,
  virtualGroupReplies: false,
  storage: 'sqlite',
  userProfiles: true,
  virtualUsers: true,
  globalMemory: true,
  openAICompatibleProviders: true,
  localAdmin: true,
  // 图片/语音发送尚未通过发布验收，公开版本不承诺媒体功能。
  media: Object.freeze({
    released: false,
    images: false,
    voice: false,
    video: false,
  }),
});

module.exports = { CAPABILITIES };
