'use strict';

const assert = require('node:assert/strict');
const net = require('node:net');
const { close, createGateway, listen } = require('./gateway');
const {
  MediaTransferService, buildOnlinePictureAck, buildServiceResult,
  parseNegotiation, parseServiceEnvelope,
} = require('./media-service');
const protocol = require('./protocol');
const { AccountStore, defaultData } = require('./store');

class FrameReader {
  constructor(socket) {
    this.buffer = Buffer.alloc(0);
    this.frames = [];
    this.waiters = [];
    socket.on('data', (chunk) => {
      this.buffer = Buffer.concat([this.buffer, chunk]);
      const consumed = protocol.consumeFrames(this.buffer);
      this.buffer = consumed.remainder;
      for (const frame of consumed.frames) {
        const waiter = this.waiters.shift();
        if (waiter) waiter(frame); else this.frames.push(frame);
      }
    });
  }

  next() {
    if (this.frames.length) return Promise.resolve(this.frames.shift());
    return new Promise((resolve) => this.waiters.push(resolve));
  }
}

function encryptedFrame(command, sequence, uin, key, payload) {
  return protocol.createFrame({
    command, sequence, uin,
    payload: protocol.encryptPayload(payload, key, (size) => Buffer.alloc(size, 0x31)),
  });
}

function getKeyRequest(uin, sequence) {
  return protocol.createFrame({ command: protocol.COMMAND_GET_KEY, sequence, uin,
    payload: Buffer.alloc(24, 0x41) });
}

function loginRequest(uin, sequence, key, password) {
  const digest = protocol.passwordDigest(password);
  const payload = Buffer.alloc(42);
  payload.writeUInt16BE(9, 0); payload.writeUInt16BE(1, 2);
  Buffer.alloc(16, 0x42).copy(payload, 8);
  payload[24] = digest.length; digest.copy(payload, 25);
  payload[41] = 0;
  return encryptedFrame(protocol.COMMAND_LOGIN, sequence, uin, key, payload);
}

function ticketRequest(targetUin) {
  const payload = Buffer.alloc(13);
  payload[0] = 6;
  payload.writeUInt32BE(targetUin, 1);
  payload.writeUInt32BE(123, 5);
  payload.writeUInt32BE(456, 9);
  return payload;
}

function registrationRequest(ticket, filename, hash, size) {
  const name = protocol.encodeLegacyText(filename);
  const path = protocol.encodeLegacyText('C:\\');
  const payload = Buffer.alloc(7 + ticket.length + 2 + ticket.length + 2 + 4
    + 2 + name.length + 1 + hash.length + 1 + hash.length + 2 + path.length);
  let offset = 0;
  payload[offset] = 1; offset += 1;
  payload.writeUInt32BE(0, offset); offset += 4;
  payload.writeUInt16BE(ticket.length, offset); offset += 2;
  ticket.copy(payload, offset); offset += ticket.length;
  payload.writeUInt16BE(ticket.length, offset); offset += 2;
  ticket.copy(payload, offset); offset += ticket.length;
  payload.writeUInt16BE(0, offset); offset += 2;
  payload.writeUInt32BE(size, offset); offset += 4;
  payload.writeUInt16BE(name.length, offset); offset += 2;
  name.copy(payload, offset); offset += name.length;
  payload[offset] = hash.length; offset += 1;
  hash.copy(payload, offset); offset += hash.length;
  payload[offset] = hash.length; offset += 1;
  hash.copy(payload, offset); offset += hash.length;
  payload.writeUInt16BE(path.length, offset); offset += 2;
  path.copy(payload, offset);
  return payload;
}

function announcementRequest(from, to, filename, hash, mediaType, size) {
  const name = protocol.encodeLegacyText(filename);
  const payload = Buffer.alloc(56 + name.length + hash.length);
  payload.writeUInt32BE(from, 2);
  payload.writeUInt32BE(to, 6);
  payload.writeUInt16BE(0x00B5, 26);
  payload.writeUInt16BE(1, 45);
  payload[47] = 1;
  payload.writeUInt16BE(name.length, 48);
  name.copy(payload, 50);
  let offset = 50 + name.length;
  payload[offset] = hash.length; offset += 1;
  hash.copy(payload, offset); offset += hash.length;
  payload[offset] = mediaType; offset += 1;
  payload.writeUInt32BE(size, offset);
  return payload;
}

function realAnnouncementRequest(from, to, filename, hash, mediaType, size) {
  const name = protocol.encodeLegacyText(filename);
  const payload = Buffer.alloc(62 + name.length + hash.length);
  // Captured 0x0065 packets repeat the peer at offset 0, then carry the
  // authenticated sender and target in the six-byte service prefix.
  payload.writeUInt32BE(to, 0);
  payload.writeUInt32BE(from, 8);
  payload.writeUInt32BE(to, 12);
  payload.writeUInt16BE(0x00B5, 32);
  payload.writeUInt16BE(5, 40);
  payload[52] = 1;
  payload[53] = 1;
  payload.writeUInt16BE(name.length, 54);
  name.copy(payload, 56);
  let offset = 56 + name.length;
  payload[offset] = hash.length; offset += 1;
  hash.copy(payload, offset); offset += hash.length;
  payload[offset] = mediaType; offset += 1;
  payload.writeUInt32BE(size, offset);
  return payload;
}

async function main() {
  const image = Buffer.from('ffd8ffe000104a4649460001ffd9', 'hex');
  const hash = Buffer.alloc(16, 0x5A);
  const ticketParsed = parseNegotiation(ticketRequest(10002));
  assert.equal(ticketParsed.targetUin, 10002);
  assert.equal(buildOnlinePictureAck(10002)[50], 2);
  assert.equal(buildServiceResult(10002, 3, hash)[53], 3);
  assert.equal(parseServiceEnvelope(
    announcementRequest(10001, 10002, 'legacy.jpg', hash, 2, image.length)).layout,
  'service26');

  const store = new AccountStore(null, defaultData());
  const events = [];
  const gateway = createGateway({
    host: '127.0.0.1', port: 0, adminHost: '127.0.0.1', adminPort: 0,
    mobileHost: '127.0.0.1', mobilePort: 0, compactMemoryOnStart: false,
    store, sessions: new Map(), logger: (event) => events.push(event),
  });
  try {
    const addresses = await listen(gateway, {
      host: '127.0.0.1', port: 0, adminHost: '127.0.0.1', adminPort: 0,
      mobileHost: '127.0.0.1', mobilePort: 0, compactMemoryOnStart: false,
    });
    assert.ok(gateway.mediaService instanceof MediaTransferService);
    const issued = gateway.mediaService.issueTicket(10001, ticketParsed);
    const announcement = parseServiceEnvelope(
      realAnnouncementRequest(10001, 10002, 'photo.jpg', hash, 2, image.length));
    assert.equal(announcement.layout, 'service32');
    assert.equal(announcement.senderUin, 10001);
    assert.equal(announcement.targetUin, 10002);
    let acknowledged = false;
    gateway.mediaService.announce(10001, announcement, () => { acknowledged = true; });
    const registration = parseNegotiation(
      registrationRequest(issued.transfer.ticket, 'photo.jpg', hash, image.length));
    gateway.mediaService.register(10001, registration, '127.0.0.1');
    assert.equal(gateway.mediaService.pendingByHash.get(`10001:${hash.toString('hex')}`),
      issued.transfer);
    assert.equal(issued.transfer.targetUin, 10002);
    assert.equal(typeof issued.transfer.acknowledge, 'function');
    const upload = await fetch(`http://127.0.0.1:${addresses.mediaUploadAddress.port}/?ver=1223`
      + `&ukey=${issued.transfer.uploadKey.toString('hex')}`
      + `&filekey=${issued.transfer.legacyHash.toString('hex')}&filesize=${image.length}`, {
      method: 'POST', headers: { Range: 'bytes=0-' }, body: image,
    });
    assert.equal(upload.status, 200);
    assert.equal(upload.headers.get('user-returncode'), '0');
    assert.equal(Number(upload.headers.get('range')), image.length);
    assert.equal(acknowledged, true);
    const media = store.getMedia(issued.transfer.id);
    assert.equal(media.mimeType, 'image/jpeg');
    assert.deepEqual(media.content, image);
    const raw = await fetch(
      `http://127.0.0.1:${addresses.mobileAddress.port}/mobile/media/${media.id}/raw`);
    assert.equal(raw.status, 200);
    assert.deepEqual(Buffer.from(await raw.arrayBuffer()), image);
    assert.ok(store.messagesForVirtual(10002).some((message) => message.text.includes(media.id)));
    assert.ok(events.some((event) => event.event === 'media_http_connection'));
    assert.ok(events.some((event) => event.event === 'media_http_request'));
    assert.ok(events.some((event) => event.event === 'mobile_http_connection'));
    assert.ok(events.some((event) => event.event === 'mobile_http_request'));

    const socket = net.createConnection({ host: '127.0.0.1', port: addresses.qqAddress.port });
    await new Promise((resolve, reject) => {
      socket.once('connect', resolve); socket.once('error', reject);
    });
    const reader = new FrameReader(socket);
    socket.write(getKeyRequest(10001, 20));
    const keyFrame = await reader.next();
    const key = keyFrame.payload.subarray(0, 16);
    socket.write(loginRequest(10001, 21, key, 'qqtest123'));
    assert.equal((await reader.next()).status, 0);

    const voice = Buffer.from('#!AMR\nlegacy-voice-test', 'ascii');
    const voiceHash = Buffer.alloc(16, 0x6B);
    socket.write(encryptedFrame(protocol.COMMAND_GROUP_SEND, 22, 10001, key,
      ticketRequest(10002)));
    const ticketResponse = protocol.decryptPayload((await reader.next()).payload, key);
    assert.equal(ticketResponse[0], 6);
    const wireTicket = ticketResponse.subarray(9, 9 + ticketResponse.readUInt16BE(7));
    socket.write(encryptedFrame(protocol.COMMAND_MEDIA_TRANSFER, 23, 10001, key,
      realAnnouncementRequest(10001, 10002, 'voice.amr', voiceHash, 3, voice.length)));
    const acceptanceFrame = await reader.next();
    assert.equal(acceptanceFrame.command, protocol.COMMAND_MEDIA_TRANSFER);
    const acceptancePlain = protocol.decryptPayload(acceptanceFrame.payload, key);
    assert.equal(acceptancePlain.readUInt16BE(32), 0x00B5);
    assert.equal(acceptancePlain[53], 2);
    assert.equal(acceptancePlain[54], 1);
    assert.deepEqual(acceptancePlain.subarray(56), voiceHash);
    socket.write(encryptedFrame(protocol.COMMAND_GROUP_SEND, 24, 10001, key,
      registrationRequest(wireTicket, 'voice.amr', voiceHash, voice.length)));
    const targetResponse = protocol.decryptPayload((await reader.next()).payload, key);
    assert.equal(targetResponse[0], 1);
    const fileKeyLength = targetResponse.readUInt16BE(33);
    const wireFileKey = targetResponse.subarray(35, 35 + fileKeyLength);
    let targetOffset = 35 + fileKeyLength;
    const uploadKeyLength = targetResponse.readUInt16BE(targetOffset); targetOffset += 2;
    const wireUploadKey = targetResponse.subarray(targetOffset, targetOffset + uploadKeyLength);
    const wireUpload = await fetch(`http://127.0.0.1:${addresses.mediaUploadAddress.port}/?ver=1223`
      + `&ukey=${wireUploadKey.toString('hex')}&filekey=${wireFileKey.toString('hex')}`, {
      method: 'POST', headers: { Range: 'bytes=0-' }, body: voice,
    });
    assert.equal(wireUpload.status, 200);
    const finishFrame = await reader.next();
    assert.equal(finishFrame.command, protocol.COMMAND_MEDIA_TRANSFER);
    const finishPlain = protocol.decryptPayload(finishFrame.payload, key);
    assert.equal(finishPlain.readUInt16BE(32), 0x00B5);
    assert.equal(finishPlain[53], 3);
    assert.deepEqual(finishPlain.subarray(55), voiceHash);
    const storedVoice = store.listMediaFor(10002, 10).find((item) => item.mediaType === 3);
    assert.ok(storedVoice);
    assert.deepEqual(store.getMedia(storedVoice.id).content, voice);
    socket.end();
  } finally {
    await close(gateway);
  }
  process.stdout.write('QQ image/voice media self-test passed.\n');
}

main().catch((error) => {
  process.stderr.write(`${error.stack || error.message}\n`);
  process.exitCode = 1;
});
