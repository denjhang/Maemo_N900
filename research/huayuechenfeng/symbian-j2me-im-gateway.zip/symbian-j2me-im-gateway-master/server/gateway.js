'use strict';

const path = require('node:path');
const protocol = require('./protocol');
const { createAdminServer } = require('./admin-server');
const { createMobileGroupServer } = require('./mobile-group-server');
const { CAPABILITIES } = require('./capabilities');
const { createQQServer } = require('./server');
const { AccountStore } = require('./store');
const { MediaTransferService } = require('./media-service');
const { VirtualAgentRuntime } = require('./virtual-agent');

function jsonLogger(event) {
  process.stdout.write(JSON.stringify(Object.assign({ time: new Date().toISOString() }, event)) + '\n');
}

function parseArguments(args, environment) {
  const options = {
    host: environment.QQ_LISTEN_ADDRESS || '127.0.0.1',
    port: Number(environment.QQ_PORT || 14000),
    dataFile: environment.QQ_DATA_FILE || path.join(__dirname, 'data', 'private-qq.sqlite'),
    traceProtocol: environment.QQ_TRACE_PROTOCOL === '1',
    autoAcceptFriends: environment.QQ_AUTO_ACCEPT_FRIENDS !== '0',
    adminHost: environment.QQ_ADMIN_ADDRESS || '127.0.0.1',
    adminPort: Number(environment.QQ_ADMIN_PORT || 13980),
    adminToken: environment.QQ_ADMIN_TOKEN || '',
    mobileHost: environment.QQ_MOBILE_ADDRESS || '127.0.0.1',
    mobilePort: Number(environment.QQ_MOBILE_PORT || 13981),
    mediaUploadHost: environment.QQ_MEDIA_UPLOAD_ADDRESS || '127.0.0.1',
    mediaUploadPort: Number(environment.QQ_MEDIA_UPLOAD_PORT || 80),
    compactMemoryOnStart: environment.QQ_COMPACT_MEMORY_ON_START !== '0',
  };
  const mapping = {
    '--host': 'host', '--port': 'port', '--data': 'dataFile',
    '--trace-protocol': 'traceProtocol', '--auto-accept-friends': 'autoAcceptFriends',
    '--admin-host': 'adminHost', '--admin-port': 'adminPort', '--admin-token': 'adminToken',
    '--mobile-host': 'mobileHost', '--mobile-port': 'mobilePort',
    '--media-upload-host': 'mediaUploadHost', '--media-upload-port': 'mediaUploadPort',
    '--compact-memory-on-start': 'compactMemoryOnStart',
  };
  for (let index = 0; index < args.length; index += 2) {
    const name = mapping[args[index]];
    if (!name || args[index + 1] === undefined) throw new Error('invalid gateway command-line arguments');
    const value = args[index + 1];
    if (name === 'port' || name === 'adminPort' || name === 'mobilePort'
        || name === 'mediaUploadPort') options[name] = Number(value);
    else if (name === 'traceProtocol' || name === 'autoAcceptFriends'
        || name === 'compactMemoryOnStart') {
      const normalized = String(value).toLowerCase();
      options[name] = normalized === 'true' || normalized === '1';
    } else options[name] = value;
  }
  for (const name of ['port', 'adminPort', 'mobilePort', 'mediaUploadPort']) {
    if (!Number.isInteger(options[name]) || options[name] < 0 || options[name] > 65535) {
      throw new Error(`${name} must be between 0 and 65535`);
    }
  }
  if (!['127.0.0.1', '::1', 'localhost'].includes(options.adminHost) && !options.adminToken) {
    throw new Error('a non-local admin interface requires QQ_ADMIN_TOKEN or --admin-token');
  }
  return options;
}

function createGateway(options) {
  const logger = options.logger || jsonLogger;
  const store = options.store || new AccountStore(options.dataFile);
  const sessions = options.sessions || new Map();
  const outboxDeliveryDelayMs = Number.isFinite(Number(options.outboxDeliveryDelayMs))
    ? Math.max(0, Number(options.outboxDeliveryDelayMs)) : 3500;
  let runtime;

  async function deliverText(fromUin, toUin, text) {
    const target = sessions.get(Number(toUin));
    if (!target || !target.loggedIn || target.socket.destroyed) return false;
    target.pushSequence = (target.pushSequence + 1) & 0xFFFF;
    const frame = protocol.createFrame({
      command: protocol.COMMAND_INCOMING_TEXT,
      sequence: target.pushSequence,
      uin: target.uin,
      status: 0,
      payload: protocol.encryptPayload(
        protocol.buildIncomingTextPayload(Number(fromUin), text), target.sessionKey),
    });
    target.socket.write(frame);
    logger({
      event: 'text_pushed', command: '0x0056', sequence: target.pushSequence,
      from: Number(fromUin), to: Number(toUin), bytes: frame.length,
    });
    return true;
  }

  function deliverGroup(groupId, fromUin, text, deliveryOptions) {
    const group = store.getGroup(groupId);
    if (!group) return { delivered: 0, virtualQueued: 0 };
    const sender = store.get(fromUin);
    let delivered = 0;
    let virtualQueued = 0;
    for (const member of group.members) {
      if (member.uin === Number(fromUin)) continue;
      const account = store.get(member.uin);
      if (account && account.type === 'virtual') {
        if ((!deliveryOptions || deliveryOptions.triggerVirtual !== false) && runtime
            && runtime.receiveGroup(account.uin, group.id, Number(fromUin), text)) {
          virtualQueued += 1;
        }
        continue;
      }
      const target = sessions.get(member.uin);
      if (!target || !target.loggedIn || target.socket.destroyed) continue;
      target.pushSequence = (target.pushSequence + 1) & 0xFFFF;
      const frame = protocol.createFrame({
        command: protocol.COMMAND_GROUP_MESSAGE,
        sequence: target.pushSequence,
        uin: target.uin,
        status: 0,
        payload: protocol.encryptPayload(protocol.buildGroupMessagePayload({
          // mb/lq resolves incoming messages through hp.b(), which is the
          // public group number populated by the 0x006D group-info response.
          groupId: group.publicId,
          senderUin: Number(fromUin),
          displayName: sender ? sender.nickname : String(fromUin),
          text,
        }), target.sessionKey),
      });
      target.socket.write(frame);
      delivered += 1;
      logger({
        event: 'group_message_pushed', command: '0x0094', sequence: target.pushSequence,
        groupId: group.id, from: Number(fromUin), to: target.uin, bytes: frame.length,
      });
    }
    return { delivered, virtualQueued };
  }

  runtime = new VirtualAgentRuntime({
    store, logger, deliver: deliverText, deliverGroup,
  });
  const deliverOutbox = (uin) => setTimeout(async () => {
    const pending = store.takeOutbox(uin);
    for (const entry of pending) {
      const delivered = await deliverText(entry.from, entry.to, entry.text);
      if (!delivered) store.enqueueOutbox(entry.from, entry.to, entry.text);
      else logger({ event: 'outbox_delivered', id: entry.id, from: entry.from, to: entry.to });
    }
  }, outboxDeliveryDelayMs);

  const mediaService = new MediaTransferService({
    store, logger, httpPort: options.mediaUploadPort,
    onComplete: async (media, uploadHost) => {
      const kind = media.mediaType === 1 || media.mediaType === 2
        ? '图片' : media.mediaType === 3 ? '语音' : '文件';
      const host = String(uploadHost || options.mobileHost || '127.0.0.1').replace(/^::ffff:/, '');
      const port = mediaService.httpPort || Number(options.mediaUploadPort || 80);
      const text = `【${kind}】http://${host}:${port}/mobile/media/${encodeURIComponent(media.id)}`;
      store.saveMessage(media.from, media.to, text);
      const account = store.get(media.to);
      let delivered = false;
      if (account && account.type === 'virtual' && runtime) {
        delivered = runtime.receive(media.to, media.from);
      } else {
        delivered = await deliverText(media.from, media.to, text);
      }
      if (!delivered && (!account || account.type !== 'virtual')) {
        store.enqueueOutbox(media.from, media.to, text);
      }
      logger({ event: 'media_link_delivered', mediaId: media.id, from: media.from,
        to: media.to, delivered, url: text.slice(text.indexOf('http')) });
    },
  });

  const qqServer = createQQServer(Object.assign({}, options, {
    store, sessions, logger, virtualRuntime: runtime, deliverOutbox, deliverGroup, mediaService,
  }));
  const adminServer = createAdminServer({
    store, runtime, logger, token: options.adminToken,
    deliverGroup,
    setPresence: (uin, presence) => qqServer.setPresence(uin, presence, 'admin'),
    pushGroupDiscovery: (group, memberUins, reason) => {
      for (const uin of memberUins) qqServer.pushGroupDiscovery(uin, [group], reason);
    },
    pushFriendAccepted: (leftUin, rightUin, reason) =>
      qqServer.pushFriendAccepted(leftUin, rightUin, reason),
  });
  const mobileServer = createMobileGroupServer({
    store, logger, mediaService, requestEvent: 'mobile_http_request',
    pushGroupDiscovery: (group, memberUins, reason) => {
      for (const uin of memberUins) qqServer.pushGroupDiscovery(uin, [group], reason);
    },
  });
  // QQ2009's J2ME uploader omits the colon when the negotiated HTTP port is
  // not 80. A second listener on port 80 preserves the exact legacy URL while
  // the management/WAP pages remain on the configurable mobile port.
  const mediaUploadServer = createMobileGroupServer({
    store, logger, mediaService, requestEvent: 'media_http_request',
    errorEvent: 'media_http_error',
    pushGroupDiscovery: (group, memberUins, reason) => {
      for (const uin of memberUins) qqServer.pushGroupDiscovery(uin, [group], reason);
    },
  });
  return {
    qqServer, adminServer, mobileServer, mediaUploadServer,
    store, sessions, runtime, mediaService, logger, deliverText, deliverGroup,
  };
}

async function listen(gateway, options) {
  await Promise.all([
    new Promise((resolve, reject) => {
      gateway.qqServer.once('error', reject);
      gateway.qqServer.listen(options.port, options.host, resolve);
    }),
    new Promise((resolve, reject) => {
      gateway.adminServer.once('error', reject);
      gateway.adminServer.listen(options.adminPort, options.adminHost, resolve);
    }),
    new Promise((resolve, reject) => {
      gateway.mobileServer.once('error', reject);
      gateway.mobileServer.listen(options.mobilePort === undefined ? 0 : options.mobilePort,
        options.mobileHost || '127.0.0.1', resolve);
    }),
    new Promise((resolve, reject) => {
      gateway.mediaUploadServer.once('error', reject);
      gateway.mediaUploadServer.listen(
        options.mediaUploadPort === undefined ? 0 : options.mediaUploadPort,
        options.mediaUploadHost || '127.0.0.1', resolve);
    }),
  ]);
  const qqAddress = gateway.qqServer.address();
  const adminAddress = gateway.adminServer.address();
  const mobileAddress = gateway.mobileServer.address();
  const mediaUploadAddress = gateway.mediaUploadServer.address();
  gateway.mediaService.setHttpPort(mediaUploadAddress.port);
  gateway.logger({
    event: 'gateway_listening',
    qq: { host: qqAddress.address, port: qqAddress.port },
    admin: { host: adminAddress.address, port: adminAddress.port },
    mobile: { host: mobileAddress.address, port: mobileAddress.port },
    mediaUpload: { host: mediaUploadAddress.address, port: mediaUploadAddress.port },
    accounts: gateway.store.listAccounts().map((account) => ({ uin: account.uin, type: account.type })),
    capabilities: CAPABILITIES,
  });
  if (options.compactMemoryOnStart !== false) {
    gateway.runtime.compactAll().then((results) => {
      gateway.logger({ event: 'startup_memory_compaction_finished', results });
    }).catch((error) => {
      gateway.logger({ event: 'startup_memory_compaction_failed', message: error.message });
    });
  } else {
    gateway.logger({ event: 'startup_memory_compaction_skipped' });
  }
  return { qqAddress, adminAddress, mobileAddress, mediaUploadAddress };
}

async function close(gateway) {
  const closeHttpServer = (server) => new Promise((resolve) => {
    server.close(resolve);
    if (typeof server.closeAllConnections === 'function') server.closeAllConnections();
  });
  await Promise.all([
    new Promise((resolve) => {
      gateway.qqServer.close(resolve);
      if (typeof gateway.qqServer.closeAllConnections === 'function') {
        gateway.qqServer.closeAllConnections();
      }
    }),
    closeHttpServer(gateway.adminServer),
    closeHttpServer(gateway.mobileServer),
    closeHttpServer(gateway.mediaUploadServer),
  ]);
  gateway.store.close();
}

if (require.main === module) {
  try {
    const options = parseArguments(process.argv.slice(2), process.env);
    const gateway = createGateway(options);
    listen(gateway, options).catch((error) => {
      process.stderr.write('QQ gateway failed: ' + error.message + '\n');
      process.exitCode = 1;
    });
    const shutdown = () => close(gateway).finally(() => process.exit(0));
    process.once('SIGINT', shutdown);
    process.once('SIGTERM', shutdown);
  } catch (error) {
    process.stderr.write('QQ gateway failed: ' + error.message + '\n');
    process.exitCode = 1;
  }
}

module.exports = { close, createGateway, listen, parseArguments };
