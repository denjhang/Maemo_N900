'use strict';

const path = require('node:path');
const { AccountStore } = require('./store');

function main(args) {
  let dataFile = path.join(__dirname, 'data', 'private-qq.sqlite');
  if (args[0] === '--data') {
    if (!args[1]) throw new Error('--data requires a file path');
    dataFile = args[1];
    args = args.slice(2);
  }
  const store = new AccountStore(dataFile);
  const command = args[0];
  if (command === 'list') {
    for (const account of store.data.accounts) {
      process.stdout.write(JSON.stringify({
        uin: account.uin,
        nickname: account.nickname,
        friends: account.friends,
        pendingRequests: account.incomingRequests.length,
      }) + '\n');
    }
    return;
  }
  if (command === 'add' && args.length === 4) {
    const account = store.addAccount(Number(args[1]), args[2], args[3]);
    process.stdout.write(JSON.stringify({ event: 'account_added', uin: account.uin }) + '\n');
    return;
  }
  if (command === 'reset-password' && args.length === 3) {
    const account = store.resetPassword(Number(args[1]), args[2]);
    process.stdout.write(JSON.stringify({ event: 'password_reset', uin: account.uin }) + '\n');
    return;
  }
  throw new Error('usage: manage-accounts.js [--data FILE] list | add UIN NICKNAME PASSWORD | reset-password UIN PASSWORD');
}

try { main(process.argv.slice(2)); }
catch (error) {
  process.stderr.write('Account management failed: ' + error.message + '\n');
  process.exitCode = 1;
}
