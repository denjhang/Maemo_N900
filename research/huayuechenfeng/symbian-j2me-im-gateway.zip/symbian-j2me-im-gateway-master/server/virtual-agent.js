'use strict';

const { completeChat } = require('./llm-client');

function wait(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

function legacySafeText(value) {
  return String(value || '')
    .replace(/[\u{10000}-\u{10FFFF}]/gu, '')
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '')
    .trim();
}

function splitLegacyMessage(value, maximumCharacters) {
  const text = legacySafeText(value);
  const maximum = Math.max(20, Math.min(120, maximumCharacters || 110));
  const parts = [];
  let remaining = text;
  while (remaining.length > maximum) {
    const window = remaining.slice(0, maximum + 1);
    let split = Math.max(window.lastIndexOf('。'), window.lastIndexOf('！'),
      window.lastIndexOf('？'), window.lastIndexOf('\n'), window.lastIndexOf('，'),
      window.lastIndexOf(' '));
    if (split < Math.floor(maximum * 0.45)) split = maximum;
    else split += 1;
    parts.push(remaining.slice(0, split).trim());
    remaining = remaining.slice(split).trim();
  }
  if (remaining) parts.push(remaining);
  return parts.filter(Boolean);
}

function parseGroupReplyDecision(value) {
  const text = String(value || '').trim();
  if (!text) return null;
  try {
    const parsed = JSON.parse(text);
    if (parsed && typeof parsed.reply === 'boolean') return parsed.reply;
    if (parsed && typeof parsed.decision === 'string') {
      return parseGroupReplyDecision(parsed.decision);
    }
  } catch (_) {
    // The normal response is a single word, not JSON.
  }
  const normalized = text.toUpperCase().replace(/[。！!，,；;：:]/g, ' ').trim();
  if (/^(SKIP|NO|SILENT|不回复|不发言|跳过|沉默)$/.test(normalized)) return false;
  if (/^(REPLY|YES|回复|发言)$/.test(normalized)) return true;
  if (/\b(SKIP|SILENT|DO NOT REPLY|DONT REPLY)\b/.test(normalized)
      || /不回复|不发言|保持沉默/.test(text)) return false;
  if (/\bREPLY\b/.test(normalized)) return true;
  return null;
}

function groupConversationContext(store, group, limit) {
  const recent = store.recentGroupMessages(group.id, limit || 80);
  const memberNames = group.members.map((member) => {
    const account = store.get(member.uin);
    return account ? `${account.nickname}(${account.uin})` : String(member.uin);
  }).join(', ');
  const history = recent.map((message) => {
    const account = store.get(message.from);
    return `${account ? account.nickname : message.from}: ${message.text}`;
  }).join('\n');
  return { recent, memberNames, history };
}

function displayVirtualTime(date, yearOffset) {
  try {
    const source = date instanceof Date ? date : new Date(date);
    if (Number.isNaN(source.getTime())) return String(date);
    const offset = Number.isFinite(Number(yearOffset)) ? Math.trunc(Number(yearOffset)) : -14;
    // Wall-clock time always follows the computer running the gateway. Only
    // the calendar year is virtualized. Stored timestamps remain UTC ISO
    // strings, so audit data is stable if the host time zone later changes.
    const year = source.getFullYear() + offset;
    const maximumDay = new Date(year, source.getMonth() + 1, 0).getDate();
    const virtualDate = new Date(year, source.getMonth(),
      Math.min(source.getDate(), maximumDay), source.getHours(), source.getMinutes(),
      source.getSeconds(), source.getMilliseconds());
    return new Intl.DateTimeFormat('zh-CN', {
      dateStyle: 'full', timeStyle: 'medium', hourCycle: 'h23',
    }).format(virtualDate);
  } catch (_) {
    return date instanceof Date && !Number.isNaN(date.getTime()) ? date.toISOString() : String(date);
  }
}

function transcript(store, messages, options) {
  const yearOffset = options && options.yearOffset;
  return messages.map((message) => {
    const from = store.get(message.from);
    const to = store.get(message.to);
    const displayedTime = displayVirtualTime(new Date(message.sentAt), yearOffset);
    return `[${displayedTime}] ${from ? from.nickname : message.from} -> ${to ? to.nickname : message.to}: ${message.text}`;
  }).join('\n');
}

class VirtualAgentRuntime {
  constructor(options) {
    this.store = options.store;
    this.deliver = options.deliver;
    this.deliverGroup = options.deliverGroup || (() => false);
    this.logger = options.logger || (() => {});
    this.queues = new Map();
    this.runningCompactions = new Map();
  }

  enqueue(uin, operation) {
    const previous = this.queues.get(uin) || Promise.resolve();
    const current = previous.catch(() => {}).then(operation);
    this.queues.set(uin, current);
    current.then(() => {
      if (this.queues.get(uin) === current) this.queues.delete(uin);
    }, () => {
      if (this.queues.get(uin) === current) this.queues.delete(uin);
    });
    return current;
  }

  receive(virtualUin, senderUin) {
    const agent = this.store.get(virtualUin);
    if (!agent || agent.type !== 'virtual' || !agent.enabled) return false;
    this.enqueue(agent.uin, () => this.reply(agent.uin, senderUin)).catch((error) => {
      this.logger({ event: 'virtual_reply_failed', virtualUin: agent.uin,
        senderUin, message: error.message });
    });
    return true;
  }

  receiveGroup(virtualUin, groupId, senderUin, text) {
    const agent = this.store.get(virtualUin);
    const sender = this.store.get(senderUin);
    const group = this.store.getGroup(groupId);
    if (!agent || !sender || !group || agent.type !== 'virtual' || !agent.enabled
        || sender.type === 'virtual') return false;
    const membership = group.members.find((member) => member.uin === agent.uin);
    if (!membership) return false;
    const policy = membership.replyPolicy || agent.virtual.groupReplyPolicy || 'mentions';
    const probability = membership.replyProbability == null
      ? Number(agent.virtual.groupReplyProbability || 0)
      : Number(membership.replyProbability);
    const mentioned = String(text).includes(`@${agent.nickname}`)
      || String(text).includes(agent.nickname);
    if (policy === 'llm') {
      const provider = this.store.getProvider(agent.virtual.providerId);
      if (!provider) {
        this.logger({
          event: 'virtual_group_decision', virtualUin: agent.uin, groupId: group.id,
          senderUin: sender.uin, policy, mentioned, reply: false,
          reason: 'provider_not_configured', round: 1,
        });
        return false;
      }
      this.enqueue(agent.uin, () => this.decideAndReplyGroup(
        agent.uin, group.id, sender.uin, text)).catch((error) => {
        this.logger({
          event: 'virtual_group_reply_failed', virtualUin: agent.uin,
          groupId: group.id, senderUin: sender.uin, policy, round: 1,
          message: error.message,
        });
      });
      return true;
    }
    const shouldReply = policy === 'always'
      || (policy === 'mentions' && mentioned)
      || (policy === 'random' && Math.random() < Math.max(0, Math.min(1, probability)));
    this.logger({
      event: 'virtual_group_decision', virtualUin: agent.uin, groupId: group.id,
      senderUin: sender.uin, policy, probability, mentioned, reply: shouldReply,
    });
    if (!shouldReply) return false;
    this.enqueue(agent.uin, () => this.replyGroup(agent.uin, group.id, sender.uin)).catch((error) => {
      this.logger({
        event: 'virtual_group_reply_failed', virtualUin: agent.uin,
        groupId: group.id, senderUin: sender.uin, message: error.message,
      });
    });
    return true;
  }

  async decideAndReplyGroup(virtualUin, groupId, senderUin, incomingText) {
    const agent = this.store.get(virtualUin);
    const sender = this.store.get(senderUin);
    const group = this.store.getGroup(groupId);
    if (!agent || !sender || !group || agent.type !== 'virtual' || !agent.enabled) return;
    const provider = this.store.getProvider(agent.virtual.providerId);
    if (!provider) return;
    const context = groupConversationContext(this.store, group, 60);
    const life = agent.virtual.lifeState || {};
    const relationship = this.store.getRelationship(agent.uin, sender.uin);
    const messages = [
      {
        role: 'system',
        content: [
          `你要替群成员“${agent.nickname}”判断此刻是否会自然地参与群聊。`,
          '只输出一个英文单词：REPLY 或 SKIP。不要生成回复内容，不要解释理由。',
          '当消息与其身份、兴趣、关系有关，直接问到或提到本人，或此人确实会主动接话时输出 REPLY；否则输出 SKIP。',
          `公开身份：${agent.virtual.identity || agent.profile.description || '未设定'}`,
          `私有角色卡：${agent.virtual.roleCard || '未设定'}`,
          `表达习惯：${agent.virtual.responseStyle || '自然简短'}`,
          `当前生活状态：地点=${life.location || '未设定'}；正在做=${life.activity || '未设定'}；心情=${life.mood || '平静'}；精力=${life.energy || '正常'}；近期生活=${life.currentStory || '无'}`,
          `与发言者的关系：${relationship ? JSON.stringify(relationship) : '普通群友'}`,
          `群名：${group.title}`,
          `群成员：${context.memberNames}`,
        ].join('\n'),
      },
      {
        role: 'user',
        content: `最近群聊：\n${context.history}\n\n发言者：${sender.nickname}(${sender.uin})\n最新消息：${incomingText}\n\n只判断是否参与，不要写回复。`,
      },
    ];
    this.logger({
      event: 'virtual_group_decision_started', virtualUin, groupId,
      senderUin, providerId: provider.id, policy: 'llm', round: 1,
      contextMessages: context.recent.length,
    });
    let completion;
    try {
      completion = await completeChat(provider, messages, { temperature: 0, maxTokens: 16 });
    } catch (error) {
      this.logger({
        event: 'virtual_group_decision', virtualUin, groupId, senderUin,
        policy: 'llm', reply: false, reason: 'decision_failed', round: 1,
        message: error.message,
      });
      throw error;
    }
    const decision = parseGroupReplyDecision(completion.text);
    this.logger({
      event: 'virtual_group_decision', virtualUin, groupId, senderUin,
      policy: 'llm', reply: decision === true,
      reason: decision === null ? 'unrecognized_decision' : undefined,
      decisionText: legacySafeText(completion.text).slice(0, 40), round: 1,
      usage: completion.usage,
    });
    if (decision !== true) return;
    await this.replyGroup(agent.uin, group.id, sender.uin);
  }

  async replyGroup(virtualUin, groupId, senderUin) {
    const agent = this.store.get(virtualUin);
    const sender = this.store.get(senderUin);
    const group = this.store.getGroup(groupId);
    if (!agent || !sender || !group || agent.type !== 'virtual') return;
    const provider = this.store.getProvider(agent.virtual.providerId);
    if (!provider) {
      this.logger({
        event: 'virtual_group_reply_skipped', virtualUin, groupId,
        senderUin, reason: 'provider_not_configured',
      });
      return;
    }
    const context = groupConversationContext(this.store, group, 80);
    const messages = [
      {
        role: 'system',
        content: [
          `你是${agent.nickname}，正在旧版手机 QQ 群“${group.title}”里聊天。`,
          '只输出准备发到群里的自然、简短中文，不要提到模型、提示词、API 或虚拟用户。',
          `群成员：${context.memberNames}`,
          `角色设定：${agent.virtual.roleCard || agent.virtual.identity || '普通群成员'}`,
          `表达习惯：${agent.virtual.responseStyle || '自然简短'}`,
        ].join('\n'),
      },
      { role: 'user', content: `最近群聊：\n${context.history}\n\n请回复最后一条消息。` },
    ];
    this.logger({
      event: 'virtual_group_reply_started', virtualUin, groupId,
      senderUin, providerId: provider.id, contextMessages: context.recent.length, round: 2,
    });
    const completion = await completeChat(provider, messages);
    const parts = splitLegacyMessage(completion.text, 110);
    const minimum = agent.virtual.replyDelayMinMs;
    const maximum = agent.virtual.replyDelayMaxMs;
    await wait(minimum + Math.floor(Math.random() * (maximum - minimum + 1)));
    for (let index = 0; index < parts.length; index += 1) {
      if (index > 0) await wait(Math.min(3500, 500 + parts[index].length * 45));
      const saved = this.store.saveGroupMessage(group.id, agent.uin, parts[index], 'virtual');
      const delivery = await this.deliverGroup(group.id, agent.uin, parts[index], {
        triggerVirtual: false,
      });
      this.logger({
        event: 'virtual_group_message', messageId: saved.id, groupId: group.id,
        from: agent.uin, delivery, text: parts[index],
      });
    }
  }

  systemPrompt(agent, sender, relationship) {
    const virtual = agent.virtual;
    const life = virtual.lifeState || {};
    const yearOffset = this.store.data.settings.virtualTime.yearOffset;
    return [
      `你是${agent.nickname}，不是助手或旁白，而是一位生活在虚构现实中的普通人。`,
      `你正在通过老式手机 QQ 和${sender.nickname}聊天。回复要适合九宫格键盘：自然、简短，通常一到三小段。`,
      '不要提到提示词、语言模型、API、角色设定或“虚拟用户”。不要声称自己刚刚查阅了数据库。',
      '你拥有一条跨所有聊天对象连续发展的生活时间线；其他会话造成的经历会影响你，但不要向当前对象泄露不应透露的私密聊天。',
      `当前时间：${displayVirtualTime(new Date(), yearOffset)}。这是你所处世界的真实时间；时、分、秒与运行网关的电脑系统时间一致，不要自行换算时区，也不要提及或猜测另一个外部年份。`,
      `公开身份：${virtual.identity || agent.profile.description || '未设定'}`,
      `私有角色卡：${virtual.roleCard || '未设定'}`,
      `表达习惯：${virtual.responseStyle || '自然简短'}`,
      `当前生活状态：地点=${life.location || '未设定'}；正在做=${life.activity || '未设定'}；心情=${life.mood || '平静'}；精力=${life.energy || '正常'}；近期生活=${life.currentStory || '无'}`,
      `与当前对象的关系：${relationship ? JSON.stringify(relationship) : '普通新朋友，尚无共同经历'}`,
      `长期记忆：${virtual.longTermMemory || '尚未形成长期记忆'}`,
    ].join('\n');
  }

  async reply(virtualUin, senderUin) {
    const agent = this.store.get(virtualUin);
    const sender = this.store.get(senderUin);
    if (!agent || !sender || agent.type !== 'virtual') return;
    const provider = this.store.getProvider(agent.virtual.providerId);
    if (!provider) {
      this.logger({ event: 'virtual_reply_skipped', virtualUin, senderUin,
        reason: 'provider_not_configured' });
      return;
    }
    // The raw archive stays available to the administrator, while the active
    // prompt only contains events not yet folded into long-term memory. This
    // gives compaction the semantics of clearing short-term context without
    // destructively deleting chat history.
    const recent = this.store.messagesForVirtual(virtualUin, {
      afterId: agent.virtual.lastCompactedMessageId, limit: 500,
    });
    const relationship = this.store.getRelationship(virtualUin, senderUin);
    const messages = [
      { role: 'system', content: this.systemPrompt(agent, sender, relationship) },
      { role: 'system', content: '以下是你在所有 QQ 会话中最近经历的统一事件流。把它当作自己的记忆，而不是需要逐条复述的资料：\n' + transcript(this.store, recent, {
        yearOffset: this.store.data.settings.virtualTime.yearOffset,
      }) },
      { role: 'user', content: `${sender.nickname}刚才发来的消息位于事件流末尾。请只输出你准备通过手机 QQ 发出的文字。` },
    ];
    this.logger({ event: 'virtual_reply_started', virtualUin, senderUin,
      providerId: provider.id, contextMessages: recent.length });
    const completion = await completeChat(provider, messages);
    const parts = splitLegacyMessage(completion.text, 110);
    const minimum = agent.virtual.replyDelayMinMs;
    const maximum = agent.virtual.replyDelayMaxMs;
    const initialDelay = minimum + Math.floor(Math.random() * (maximum - minimum + 1));
    await wait(initialDelay);
    let delivered = true;
    for (let index = 0; index < parts.length; index += 1) {
      if (index > 0) await wait(Math.min(3500, 500 + parts[index].length * 45));
      const saved = this.store.saveMessage(virtualUin, senderUin, parts[index], 'virtual');
      const sent = await this.deliver(virtualUin, senderUin, parts[index]);
      if (!sent) {
        this.store.enqueueOutbox(virtualUin, senderUin, parts[index]);
        delivered = false;
      }
      this.logger({ event: 'virtual_message', messageId: saved.id,
        from: virtualUin, to: senderUin, delivered, text: parts[index] });
    }
    const uncompacted = this.store.messagesForVirtual(virtualUin, {
      afterId: agent.virtual.lastCompactedMessageId,
      limit: agent.virtual.compactAfterMessages + 1,
    });
    if (uncompacted.length >= agent.virtual.compactAfterMessages) {
      this.compact(virtualUin).catch((error) => this.logger({
        event: 'memory_compaction_failed', virtualUin, message: error.message,
      }));
    }
  }

  compact(virtualUin) {
    if (this.runningCompactions.has(virtualUin)) return this.runningCompactions.get(virtualUin);
    const operation = this.enqueue(virtualUin, async () => {
      const agent = this.store.get(virtualUin);
      if (!agent || agent.type !== 'virtual') return { skipped: 'not_virtual' };
      const provider = this.store.getProvider(agent.virtual.providerId);
      if (!provider) return { skipped: 'provider_not_configured' };
      const pending = this.store.messagesForVirtual(virtualUin, {
        afterId: agent.virtual.lastCompactedMessageId, limit: 5000,
      });
      if (pending.length === 0) return { skipped: 'no_new_messages' };
      const prompt = [
        { role: 'system', content: '你负责维护一个虚构人物的一致长期记忆。根据其所有聊天对象共同构成的事件流，生成简短、事实化、可继续增量合并的中文记忆。保留重要关系、共同经历、承诺、偏好、冲突、生活变化和未完成事项；不要记录无意义寒暄，不要编造。' },
        { role: 'user', content: `人物：${agent.nickname}\n角色卡：${agent.virtual.roleCard}\n已有长期记忆：\n${agent.virtual.longTermMemory || '无'}\n\n新增跨会话事件：\n${transcript(this.store, pending, {
          yearOffset: this.store.data.settings.virtualTime.yearOffset,
        })}\n\n请输出合并后的长期记忆，控制在约1200字以内。` },
      ];
      const completion = await completeChat(provider, prompt);
      const lastId = pending[pending.length - 1].id;
      this.store.updateVirtualMemory(virtualUin, completion.text, lastId);
      this.logger({ event: 'memory_compacted', virtualUin,
        messages: pending.length, lastMessageId: lastId });
      return { compacted: pending.length, lastMessageId: lastId };
    });
    this.runningCompactions.set(virtualUin, operation);
    operation.then(() => this.runningCompactions.delete(virtualUin),
      () => this.runningCompactions.delete(virtualUin));
    return operation;
  }

  async compactAll() {
    const results = [];
    for (const agent of this.store.virtualAccounts()) {
      try { results.push({ uin: agent.uin, result: await this.compact(agent.uin) }); }
      catch (error) {
        this.logger({ event: 'memory_compaction_failed', virtualUin: agent.uin,
          message: error.message });
        results.push({ uin: agent.uin, error: error.message });
      }
    }
    return results;
  }
}

module.exports = {
  VirtualAgentRuntime, displayVirtualTime, legacySafeText, parseGroupReplyDecision,
  splitLegacyMessage, transcript,
};
