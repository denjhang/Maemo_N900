'use strict';

const { resolveApiKey } = require('./secrets');

function chatCompletionsUrl(baseUrl) {
  const parsed = new URL(String(baseUrl));
  if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error('LLM base URL must use HTTP or HTTPS');
  const normalized = parsed.toString().replace(/\/$/, '');
  return normalized.endsWith('/chat/completions') ? normalized : normalized + '/chat/completions';
}

function contentText(content) {
  if (typeof content === 'string') return content;
  if (Array.isArray(content)) return content.map((part) => {
    if (typeof part === 'string') return part;
    return part && typeof part.text === 'string' ? part.text : '';
  }).join('');
  return '';
}

async function completeChat(provider, messages, options) {
  if (!provider) throw new Error('LLM provider is not configured');
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), Number(provider.timeoutMs) || 60000);
  try {
    const apiKey = options && Object.prototype.hasOwnProperty.call(options, 'apiKey')
      ? options.apiKey : resolveApiKey(provider);
    const headers = Object.assign({ 'content-type': 'application/json' }, provider.extraHeaders || {});
    if (apiKey) headers.authorization = 'Bearer ' + apiKey;
    const temperatureValue = options && Object.prototype.hasOwnProperty.call(options, 'temperature')
      ? Number(options.temperature) : Number(provider.temperature);
    const maxTokensValue = options && Object.prototype.hasOwnProperty.call(options, 'maxTokens')
      ? Number(options.maxTokens) : Number(provider.maxTokens);
    const temperature = Number.isFinite(temperatureValue)
      ? Math.max(0, Math.min(2, temperatureValue)) : 0.85;
    const maxTokens = Number.isFinite(maxTokensValue)
      ? Math.max(1, Math.min(8192, Math.trunc(maxTokensValue))) : 300;
    const response = await fetch(chatCompletionsUrl(provider.baseUrl), {
      method: 'POST', headers, signal: controller.signal,
      body: JSON.stringify({
        model: provider.model,
        messages,
        temperature,
        max_tokens: maxTokens,
        stream: false,
      }),
    });
    const raw = await response.text();
    if (!response.ok) throw new Error(`LLM HTTP ${response.status}: ${raw.slice(0, 500)}`);
    let data;
    try { data = JSON.parse(raw); } catch (_) { throw new Error('LLM returned invalid JSON'); }
    const text = contentText(data && data.choices && data.choices[0]
      && data.choices[0].message && data.choices[0].message.content).trim();
    if (!text) throw new Error('LLM returned an empty message');
    return { text, usage: data.usage || null, id: data.id || null };
  } finally {
    clearTimeout(timeout);
  }
}

module.exports = { chatCompletionsUrl, completeChat, contentText };
