'use strict';

let state = { settings: { virtualTime: { yearOffset: -14 } }, accounts: [], groups: [], providers: [], relationships: [], stats: {} };
const byId = (id) => document.getElementById(id);
const formValue = (form, name) => form.elements[name].value;
const numeric = (form, name) => Number(formValue(form, name)) || 0;

function toast(message, error) {
  const element = byId('toast');
  element.textContent = message;
  element.className = error ? 'show error' : 'show';
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => { element.className = ''; }, 3500);
}

async function api(resource, options) {
  const response = await fetch(resource, Object.assign({
    headers: { 'content-type': 'application/json' },
  }, options || {}));
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
  return data;
}

function option(select, value, label) {
  const item = document.createElement('option');
  item.value = value;
  item.textContent = label;
  select.appendChild(item);
}

function accountCard(account, editable) {
  const element = document.createElement('div');
  element.className = 'card';
  const title = document.createElement('h3');
  title.textContent = `${account.nickname} · ${account.uin}`;
  const tag = document.createElement('span');
  tag.className = 'tag';
  tag.textContent = account.type === 'virtual' ? '虚拟用户' : '真人账号';
  const detail = document.createElement('p');
  detail.textContent = `${account.enabled ? '已启用' : '已停用'} · ${account.friends.length} 位好友 · ${account.profile.signature || '暂无签名'}`;
  element.append(title, tag, detail);
  if (editable && account.type === 'virtual') {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'secondary';
    button.textContent = '载入编辑';
    button.addEventListener('click', () => editVirtual(account));
    element.append(button);
  }
  return element;
}

function renderProviders() {
  const cards = state.providers.map((provider) => {
    const element = document.createElement('div');
    element.className = 'card';
    const title = document.createElement('h3');
    title.textContent = provider.name;
    const detail = document.createElement('p');
    detail.textContent = `${provider.baseUrl}\n${provider.model}\n密钥：${provider.hasApiKey ? '已配置' : '未配置'}`;
    detail.style.whiteSpace = 'pre-line';
    const test = document.createElement('button');
    test.type = 'button';
    test.className = 'secondary';
    test.textContent = '测试连接';
    test.addEventListener('click', async () => {
      try {
        const result = await api(`/api/providers/${encodeURIComponent(provider.id)}/test`, { method: 'POST', body: '{}' });
        toast(result.reply);
      } catch (error) { toast(error.message, true); }
    });
    element.append(title, detail, test);
    return element;
  });
  byId('provider-list').replaceChildren(...cards);
}

function renderMemory() {
  const uin = Number(byId('memory-user').value);
  const account = state.accounts.find((value) => value.uin === uin);
  byId('memory-text').textContent = account && account.virtual
    ? account.virtual.longTermMemory || '尚未形成长期记忆' : '请选择虚拟用户';
}

function loadAccountEditor() {
  const form = byId('account-edit-form');
  const uin = Number(formValue(form, 'uin'));
  const account = state.accounts.find((value) => value.uin === uin);
  if (!account) return;
  const profile = account.profile || {};
  setField(form, 'enabled', String(account.enabled));
  setField(form, 'nickname', account.nickname);
  for (const name of ['realName', 'age', 'gender', 'avatar', 'signature']) setField(form, name, profile[name]);
  setField(form, 'newPassword', '');
  form.elements.newPassword.disabled = account.type !== 'human';
}

function renderFriendRequests() {
  const cards = [];
  for (const receiver of state.accounts) {
    for (const request of receiver.incomingRequests || []) {
      const requester = state.accounts.find((account) => account.uin === request.from);
      const element = document.createElement('div'); element.className = 'card';
      const title = document.createElement('h3');
      title.textContent = `${requester ? requester.nickname : request.from} → ${receiver.nickname}`;
      const detail = document.createElement('p');
      detail.textContent = request.message || '没有附言';
      const accept = document.createElement('button'); accept.type = 'button'; accept.textContent = '同意';
      const reject = document.createElement('button'); reject.type = 'button';
      reject.className = 'secondary'; reject.textContent = '拒绝';
      const decide = async (action) => {
        try {
          await api(`/api/friends/${action}`, { method: 'POST', body: JSON.stringify({
            receiverUin: receiver.uin, requesterUin: request.from,
          }) });
          await refresh(); toast(action === 'accept' ? '好友申请已同意' : '好友申请已拒绝');
        } catch (error) { toast(error.message, true); }
      };
      accept.addEventListener('click', () => decide('accept'));
      reject.addEventListener('click', () => decide('reject'));
      element.append(title, detail, accept, reject); cards.push(element);
    }
  }
  if (cards.length === 0) {
    const empty = document.createElement('p'); empty.textContent = '当前没有待处理申请。'; cards.push(empty);
  }
  byId('friend-requests').replaceChildren(...cards);
}

function renderGroups() {
  const groups = state.groups || [];
  const cards = groups.map((group) => {
    const element = document.createElement('div');
    element.className = 'card';
    const title = document.createElement('h3');
    title.textContent = `${group.title} · ${group.publicId}`;
    const tag = document.createElement('span');
    tag.className = 'tag';
    tag.textContent = group.type === 'discussion' ? '讨论组' : 'QQ群';
    const detail = document.createElement('p');
    detail.textContent = `内部 ID ${group.id} · 群主 ${group.ownerUin}\n`
      + group.members.map((member) => `${member.nickname}(${member.uin})`
        + (member.accountType === 'virtual' ? ` [${member.replyPolicy || '默认策略'}]` : '')).join('、');
    detail.style.whiteSpace = 'pre-line';
    element.append(title, tag, detail);
    return element;
  });
  if (cards.length === 0) {
    const empty = document.createElement('p');
    empty.textContent = '还没有群聊或讨论组。';
    cards.push(empty);
  }
  byId('group-list').replaceChildren(...cards);
}

function render() {
  byId('gateway-status').textContent = '网关管理服务已连接';
  const stats = byId('stats');
  stats.replaceChildren();
  const values = [
    ['账号', state.accounts.length],
    ['虚拟用户', state.stats.virtualUsers || 0],
    ['群聊', state.stats.groups || 0],
    ['聊天消息', state.stats.messages || 0],
    ['群消息', state.stats.groupMessages || 0],
    ['离线待投递', state.stats.outbox || 0],
  ];
  for (const [label, value] of values) {
    const item = document.createElement('div'); item.className = 'stat';
    const strong = document.createElement('strong'); strong.textContent = value;
    const span = document.createElement('span'); span.textContent = label;
    item.append(strong, span); stats.append(item);
  }
  const offset = Number(state.settings && state.settings.virtualTime
    ? state.settings.virtualTime.yearOffset : -14);
  const realYear = new Date().getFullYear();
  const timeForm = byId('time-settings-form');
  setField(timeForm, 'yearOffset', offset);
  byId('virtual-time-preview').textContent = `现实 ${realYear} 年 → 虚拟世界 ${realYear + offset} 年（偏移 ${offset >= 0 ? '+' : ''}${offset} 年）`;
  byId('account-cards').replaceChildren(...state.accounts.map((account) => accountCard(account, false)));
  const virtual = state.accounts.filter((account) => account.type === 'virtual');
  byId('virtual-list').replaceChildren(...virtual.map((account) => accountCard(account, true)));

  const providerSelect = byId('virtual-provider');
  const selectedProvider = providerSelect.value;
  providerSelect.replaceChildren(); option(providerSelect, '', '尚未配置');
  state.providers.forEach((provider) => option(providerSelect, provider.id, `${provider.name} · ${provider.model}`));
  providerSelect.value = selectedProvider;

  const relationVirtual = byId('relation-virtual');
  const relationTarget = byId('relation-target');
  const memoryUser = byId('memory-user');
  const accountEditUser = byId('account-edit-user');
  const selectedAccount = accountEditUser.value;
  const selectedMemory = memoryUser.value;
  for (const select of [relationVirtual, relationTarget, memoryUser, accountEditUser]) select.replaceChildren();
  virtual.forEach((account) => {
    option(relationVirtual, account.uin, `${account.nickname} (${account.uin})`);
    option(memoryUser, account.uin, `${account.nickname} (${account.uin})`);
  });
  state.accounts.forEach((account) => {
    option(relationTarget, account.uin, `${account.nickname} (${account.uin})`);
    option(accountEditUser, account.uin, `${account.nickname} (${account.uin})`);
  });
  if (selectedAccount) accountEditUser.value = selectedAccount;
  if (selectedMemory) memoryUser.value = selectedMemory;
  renderProviders();
  renderMemory();
  loadAccountEditor();
  renderFriendRequests();
  renderGroups();
}

function setField(form, name, value) {
  if (form.elements[name]) form.elements[name].value = value === undefined || value === null ? '' : value;
}

function formatLocalTimestamp(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleString('zh-CN', { hourCycle: 'h23' });
}

function editVirtual(account) {
  const form = byId('virtual-form');
  const profile = account.profile || {};
  const agent = account.virtual || {};
  const life = agent.lifeState || {};
  setField(form, 'editingUin', account.uin); setField(form, 'uin', account.uin);
  form.elements.uin.disabled = true;
  setField(form, 'nickname', account.nickname);
  for (const name of ['realName', 'avatar', 'age', 'gender', 'country', 'province', 'city', 'occupation', 'signature']) setField(form, name, profile[name]);
  for (const name of ['providerId', 'friendPolicy', 'groupReplyPolicy',
    'groupReplyProbability', 'identity', 'roleCard', 'responseStyle']) setField(form, name, agent[name]);
  for (const name of ['location', 'activity', 'mood', 'energy', 'currentStory']) setField(form, name, life[name]);
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function virtualBody(form) {
  return {
    uin: numeric(form, 'uin'), type: 'virtual', nickname: formValue(form, 'nickname'),
    profile: {
      realName: formValue(form, 'realName'), avatar: numeric(form, 'avatar'),
      age: numeric(form, 'age'), gender: numeric(form, 'gender'), country: formValue(form, 'country'),
      province: formValue(form, 'province'), city: formValue(form, 'city'),
      occupation: formValue(form, 'occupation'), signature: formValue(form, 'signature'),
    },
    virtual: {
      providerId: formValue(form, 'providerId'), friendPolicy: formValue(form, 'friendPolicy'),
      groupReplyPolicy: formValue(form, 'groupReplyPolicy'),
      groupReplyProbability: Number(formValue(form, 'groupReplyProbability')),
      identity: formValue(form, 'identity'),
      roleCard: formValue(form, 'roleCard'), responseStyle: formValue(form, 'responseStyle'),
      lifeState: {
        location: formValue(form, 'location'), activity: formValue(form, 'activity'),
        mood: formValue(form, 'mood'), energy: formValue(form, 'energy'),
        currentStory: formValue(form, 'currentStory'),
      },
    },
  };
}

async function refresh() {
  state = await api('/api/state');
  render();
}

document.querySelectorAll('nav button').forEach((button) => button.addEventListener('click', () => {
  document.querySelectorAll('nav button').forEach((item) => item.classList.toggle('active', item === button));
  document.querySelectorAll('.page').forEach((page) => page.classList.toggle('active', page.id === 'page-' + button.dataset.page));
}));

byId('group-form').addEventListener('submit', async (event) => {
  event.preventDefault(); const form = event.currentTarget;
  const memberUins = formValue(form, 'memberUins').split(/[\s,，;；]+/)
    .filter(Boolean).map(Number);
  try {
    await api('/api/groups', { method: 'POST', body: JSON.stringify({
      title: formValue(form, 'title'), type: formValue(form, 'type'),
      ownerUin: numeric(form, 'ownerUin'), memberUins,
    }) });
    form.reset(); await refresh(); toast('群聊已创建');
  } catch (error) { toast(error.message, true); }
});

byId('group-invite-form').addEventListener('submit', async (event) => {
  event.preventDefault(); const form = event.currentTarget;
  try {
    await api(`/api/groups/${numeric(form, 'groupId')}/invite`, {
      method: 'POST', body: JSON.stringify({
        inviterUin: numeric(form, 'inviterUin'), memberUin: numeric(form, 'memberUin'),
      }),
    });
    await refresh(); toast('成员已加入群聊');
  } catch (error) { toast(error.message, true); }
});

byId('group-policy-form').addEventListener('submit', async (event) => {
  event.preventDefault(); const form = event.currentTarget;
  try {
    await api(`/api/groups/${numeric(form, 'groupId')}/members/${numeric(form, 'memberUin')}`, {
      method: 'PUT', body: JSON.stringify({
        replyPolicy: formValue(form, 'replyPolicy'),
        replyProbability: Number(formValue(form, 'replyProbability')),
      }),
    });
    await refresh(); toast('群聊回复策略已保存');
  } catch (error) { toast(error.message, true); }
});

byId('group-message-form').addEventListener('submit', async (event) => {
  event.preventDefault(); const form = event.currentTarget;
  try {
    await api(`/api/groups/${numeric(form, 'groupId')}/messages`, {
      method: 'POST', body: JSON.stringify({
        fromUin: numeric(form, 'fromUin'), text: formValue(form, 'text'),
      }),
    });
    form.elements.text.value = ''; await refresh(); toast('群消息已发送');
  } catch (error) { toast(error.message, true); }
});

byId('human-form').addEventListener('submit', async (event) => {
  event.preventDefault(); const form = event.currentTarget;
  try {
    await api('/api/users', { method: 'POST', body: JSON.stringify({
      uin: numeric(form, 'uin'), type: 'human', nickname: formValue(form, 'nickname'),
      password: formValue(form, 'password'),
      profile: { realName: formValue(form, 'realName'), signature: formValue(form, 'signature') },
    }) });
    form.reset(); await refresh(); toast('真人账号已创建');
  } catch (error) { toast(error.message, true); }
});

byId('time-settings-form').addEventListener('submit', async (event) => {
  event.preventDefault(); const form = event.currentTarget;
  try {
    await api('/api/settings/virtual-time', {
      method: 'POST', body: JSON.stringify({ yearOffset: numeric(form, 'yearOffset') }),
    });
    await refresh(); toast('虚拟世界时间已更新');
  } catch (error) { toast(error.message, true); }
});

byId('presence-form').addEventListener('submit', async (event) => {
  event.preventDefault(); const form = event.currentTarget;
  try {
    await api('/api/presence', { method: 'POST', body: JSON.stringify({
      uin: numeric(form, 'uin'), presence: numeric(form, 'presence'),
    }) });
    toast('在线状态已切换并推送');
  } catch (error) { toast(error.message, true); }
});

byId('account-edit-user').addEventListener('change', loadAccountEditor);
byId('account-edit-form').addEventListener('submit', async (event) => {
  event.preventDefault(); const form = event.currentTarget;
  const uin = numeric(form, 'uin');
  try {
    await api(`/api/users/${uin}`, { method: 'PUT', body: JSON.stringify({
      enabled: formValue(form, 'enabled') === 'true', nickname: formValue(form, 'nickname'),
      profile: {
        realName: formValue(form, 'realName'), age: numeric(form, 'age'),
        gender: numeric(form, 'gender'), avatar: numeric(form, 'avatar'),
        signature: formValue(form, 'signature'),
      },
    }) });
    const password = formValue(form, 'newPassword');
    if (password) await api(`/api/users/${uin}/password`, {
      method: 'POST', body: JSON.stringify({ password }),
    });
    await refresh(); toast('账号资料已保存');
  } catch (error) { toast(error.message, true); }
});

byId('virtual-form').addEventListener('submit', async (event) => {
  event.preventDefault(); const form = event.currentTarget;
  const editing = Number(formValue(form, 'editingUin'));
  try {
    const body = virtualBody(form);
    await api(editing ? `/api/users/${editing}` : '/api/users', {
      method: editing ? 'PUT' : 'POST', body: JSON.stringify(body),
    });
    await refresh(); toast(editing ? '虚拟用户已更新' : '虚拟用户已创建');
  } catch (error) { toast(error.message, true); }
});

byId('new-virtual').addEventListener('click', () => {
  const form = byId('virtual-form'); form.reset(); form.elements.editingUin.value = '';
  form.elements.uin.disabled = false;
});

byId('relation-form').addEventListener('submit', async (event) => {
  event.preventDefault(); const form = event.currentTarget;
  try {
    await api('/api/relationships', { method: 'POST', body: JSON.stringify({
      virtualUin: numeric(form, 'virtualUin'), targetUin: numeric(form, 'targetUin'),
      relationship: {
        label: formValue(form, 'label'), addressAs: formValue(form, 'addressAs'),
        closeness: numeric(form, 'closeness'), trust: numeric(form, 'trust'),
        description: formValue(form, 'description'), sharedHistory: formValue(form, 'sharedHistory'),
        privateNotes: formValue(form, 'privateNotes'),
      },
    }) });
    await refresh(); toast('关系已保存');
  } catch (error) { toast(error.message, true); }
});

byId('provider-form').addEventListener('submit', async (event) => {
  event.preventDefault(); const form = event.currentTarget;
  try {
    await api('/api/providers', { method: 'POST', body: JSON.stringify({
      id: formValue(form, 'id'), name: formValue(form, 'name'), baseUrl: formValue(form, 'baseUrl'),
      model: formValue(form, 'model'), apiKey: formValue(form, 'apiKey'), apiKeyEnv: formValue(form, 'apiKeyEnv'),
      temperature: numeric(form, 'temperature'), maxTokens: numeric(form, 'maxTokens'),
    }) });
    form.elements.apiKey.value = ''; await refresh(); toast('LLM 接口已保存');
  } catch (error) { toast(error.message, true); }
});

byId('memory-user').addEventListener('change', renderMemory);
byId('compact-memory').addEventListener('click', async () => {
  const uin = Number(byId('memory-user').value); if (!uin) return;
  try {
    const result = await api(`/api/memory/${uin}/compact`, { method: 'POST', body: '{}' });
    await refresh(); toast(JSON.stringify(result.result));
  } catch (error) { toast(error.message, true); }
});
byId('load-messages').addEventListener('click', async () => {
  const uin = Number(byId('memory-user').value); if (!uin) return;
  try {
    const data = await api(`/api/messages?uin=${uin}&limit=200`);
    const elements = data.messages.map((message) => {
      const item = document.createElement('div'); item.className = 'message';
      const meta = document.createElement('small'); meta.textContent = `${formatLocalTimestamp(message.sentAt)} · ${message.from} → ${message.to}`;
      const text = document.createElement('div'); text.textContent = message.text;
      item.append(meta, text); return item;
    });
    byId('message-list').replaceChildren(...elements);
  } catch (error) { toast(error.message, true); }
});

refresh().catch((error) => {
  byId('gateway-status').textContent = '无法连接管理服务';
  toast(error.message, true);
});
