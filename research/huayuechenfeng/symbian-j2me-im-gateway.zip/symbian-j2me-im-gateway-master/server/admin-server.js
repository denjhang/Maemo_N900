'use strict';

const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');
const { completeChat } = require('./llm-client');
const { protectSecret } = require('./secrets');

const ADMIN_ROOT = path.join(__dirname, 'admin');

function publicAccount(account) {
  return {
    uin: account.uin,
    type: account.type,
    enabled: account.enabled,
    nickname: account.nickname,
    profile: account.profile,
    virtual: account.virtual,
    friends: account.friends,
    incomingRequests: account.incomingRequests,
  };
}

function publicProvider(provider) {
  return Object.assign({}, provider, {
    apiKeyProtected: undefined,
    hasApiKey: Boolean(provider.apiKeyProtected || (provider.apiKeyEnv && process.env[provider.apiKeyEnv])),
  });
}

function publicGroup(group, store) {
  return {
    id: group.id,
    publicId: group.publicId,
    type: group.type,
    ownerUin: group.ownerUin,
    title: group.title,
    createdAt: group.createdAt,
    members: group.members.map((member) => {
      const account = store.get(member.uin);
      return Object.assign({}, member, {
        nickname: account ? account.nickname : String(member.uin),
        accountType: account ? account.type : 'unknown',
      });
    }),
  };
}

function sendJson(response, status, value) {
  const body = Buffer.from(JSON.stringify(value, null, 2) + '\n', 'utf8');
  response.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': body.length,
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
  });
  response.end(body);
}

function sendFile(response, file, contentType) {
  const body = fs.readFileSync(file);
  response.writeHead(200, {
    'content-type': contentType,
    'content-length': body.length,
    'cache-control': contentType.startsWith('text/html') ? 'no-store' : 'public, max-age=60',
    'x-content-type-options': 'nosniff',
    'content-security-policy': "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; frame-ancestors 'none'",
  });
  response.end(body);
}

function readJson(request) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let length = 0;
    request.on('data', (chunk) => {
      length += chunk.length;
      if (length > 1024 * 1024) {
        reject(new Error('request body is larger than 1 MiB'));
        request.destroy();
        return;
      }
      chunks.push(chunk);
    });
    request.on('end', () => {
      try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); }
      catch (_) { reject(new Error('request body is not valid JSON')); }
    });
    request.on('error', reject);
  });
}

function authorized(request, token) {
  if (!token) return true;
  return request.headers.authorization === 'Bearer ' + token;
}

function createAdminServer(options) {
  const store = options.store;
  const runtime = options.runtime;
  const deliverGroup = options.deliverGroup || (() => ({ delivered: 0, virtualQueued: 0 }));
  const setPresence = options.setPresence || (() => false);
  const pushGroupDiscovery = options.pushGroupDiscovery || (() => {});
  const pushFriendAccepted = options.pushFriendAccepted || (() => {});
  const logger = options.logger || (() => {});
  const token = options.token || '';
  return http.createServer(async (request, response) => {
    try {
      const url = new URL(request.url, 'http://localhost');
      if (url.pathname.startsWith('/api/') && !authorized(request, token)) {
        sendJson(response, 401, { error: 'unauthorized' });
        return;
      }
      if (request.method === 'GET' && url.pathname === '/') {
        sendFile(response, path.join(ADMIN_ROOT, 'index.html'), 'text/html; charset=utf-8');
        return;
      }
      if (request.method === 'GET' && url.pathname === '/app.js') {
        sendFile(response, path.join(ADMIN_ROOT, 'app.js'), 'text/javascript; charset=utf-8');
        return;
      }
      if (request.method === 'GET' && url.pathname === '/style.css') {
        sendFile(response, path.join(ADMIN_ROOT, 'style.css'), 'text/css; charset=utf-8');
        return;
      }
      if (request.method === 'GET' && url.pathname === '/api/state') {
        sendJson(response, 200, {
          settings: store.data.settings,
          accounts: store.listAccounts().map(publicAccount),
          relationships: store.data.relationships,
          groups: store.listGroups().map((group) => publicGroup(group, store)),
          providers: store.data.providers.map(publicProvider),
          stats: {
            messages: store.data.messages.length,
            groupMessages: store.data.groupMessages.length,
            groups: store.data.groups.length,
            outbox: store.data.outbox.length,
            virtualUsers: store.virtualAccounts().length,
          },
        });
        return;
      }
      if (request.method === 'POST' && url.pathname === '/api/settings/virtual-time') {
        const body = await readJson(request);
        const virtualTime = store.updateVirtualTime(body.yearOffset);
        logger({ event: 'admin_virtual_time_updated', yearOffset: virtualTime.yearOffset });
        sendJson(response, 200, { virtualTime });
        return;
      }
      if (request.method === 'GET' && url.pathname === '/api/messages') {
        const uin = Number(url.searchParams.get('uin'));
        const limit = Math.max(1, Math.min(500, Number(url.searchParams.get('limit')) || 100));
        const messages = uin ? store.data.messages.filter((message) => message.from === uin || message.to === uin)
          .slice(-limit) : store.data.messages.slice(-limit);
        sendJson(response, 200, { messages });
        return;
      }
      if (request.method === 'GET' && url.pathname === '/api/group-messages') {
        const groupId = Number(url.searchParams.get('groupId'));
        const limit = Math.max(1, Math.min(500, Number(url.searchParams.get('limit')) || 100));
        const messages = groupId ? store.recentGroupMessages(groupId, limit)
          : store.data.groupMessages.slice(-limit);
        sendJson(response, 200, { messages });
        return;
      }
      if (request.method === 'POST' && url.pathname === '/api/users') {
        const body = await readJson(request);
        const account = store.addAccount(body);
        logger({ event: 'admin_user_created', uin: account.uin, type: account.type });
        sendJson(response, 201, { account: publicAccount(account) });
        return;
      }
      if (request.method === 'POST' && url.pathname === '/api/groups') {
        const body = await readJson(request);
        const group = store.createGroup(body);
        pushGroupDiscovery(group, group.members.map((member) => member.uin), 'created');
        logger({
          event: 'admin_group_created', groupId: group.id, type: group.type,
          ownerUin: group.ownerUin, memberUins: group.members.map((member) => member.uin),
        });
        sendJson(response, 201, { group: publicGroup(group, store) });
        return;
      }
      let groupMatch = url.pathname.match(/^\/api\/groups\/(\d+)\/invite$/);
      if (request.method === 'POST' && groupMatch) {
        const body = await readJson(request);
        const group = store.getGroup(Number(groupMatch[1]));
        const result = store.inviteGroupMember(Number(groupMatch[1]),
          body.inviterUin, body.memberUin, body);
        if (!result.ok) throw new Error(result.reason);
        if (!result.alreadyMember) pushGroupDiscovery(group, [Number(body.memberUin)], 'invited');
        logger({
          event: 'admin_group_member_invited', groupId: group.id,
          inviterUin: Number(body.inviterUin), memberUin: Number(body.memberUin),
          alreadyMember: result.alreadyMember,
        });
        sendJson(response, 200, { result, group: publicGroup(group, store) });
        return;
      }
      groupMatch = url.pathname.match(/^\/api\/groups\/(\d+)\/members\/(\d+)$/);
      if (request.method === 'PUT' && groupMatch) {
        const body = await readJson(request);
        const member = store.updateGroupMember(
          Number(groupMatch[1]), Number(groupMatch[2]), body);
        logger({
          event: 'admin_group_member_updated', groupId: Number(groupMatch[1]),
          memberUin: Number(groupMatch[2]), replyPolicy: member.replyPolicy,
          replyProbability: member.replyProbability,
        });
        sendJson(response, 200, { member });
        return;
      }
      groupMatch = url.pathname.match(/^\/api\/groups\/(\d+)\/messages$/);
      if (request.method === 'POST' && groupMatch) {
        const body = await readJson(request);
        const message = store.saveGroupMessage(Number(groupMatch[1]), body.fromUin, body.text);
        const delivery = await deliverGroup(
          Number(groupMatch[1]), Number(body.fromUin), message.text);
        logger({
          event: 'admin_group_message_sent', groupId: message.groupId,
          messageId: message.id, from: message.from, delivery,
        });
        sendJson(response, 201, { message, delivery });
        return;
      }
      if (request.method === 'POST' && url.pathname === '/api/presence') {
        const body = await readJson(request);
        if (!setPresence(body.uin, body.presence)) throw new Error('account is not online');
        logger({
          event: 'admin_presence_changed', uin: Number(body.uin), presence: Number(body.presence),
        });
        sendJson(response, 200, { ok: true });
        return;
      }
      let match = url.pathname.match(/^\/api\/users\/(\d+)$/);
      if (request.method === 'PUT' && match) {
        const body = await readJson(request);
        const account = store.updateAccount(Number(match[1]), body);
        logger({ event: 'admin_user_updated', uin: account.uin });
        sendJson(response, 200, { account: publicAccount(account) });
        return;
      }
      match = url.pathname.match(/^\/api\/users\/(\d+)\/password$/);
      if (request.method === 'POST' && match) {
        const body = await readJson(request);
        const account = store.resetPassword(Number(match[1]), body.password);
        logger({ event: 'admin_password_reset', uin: account.uin });
        sendJson(response, 200, { ok: true });
        return;
      }
      if (request.method === 'POST' && url.pathname === '/api/relationships') {
        const body = await readJson(request);
        const relationship = store.setRelationship(body.virtualUin, body.targetUin, body.relationship || {});
        logger({ event: 'admin_relationship_updated', virtualUin: relationship.virtualUin,
          targetUin: relationship.targetUin });
        sendJson(response, 200, { relationship });
        return;
      }
      if (request.method === 'POST' && url.pathname === '/api/friends/accept') {
        const body = await readJson(request);
        const result = store.acceptFriend(body.receiverUin, body.requesterUin);
        if (!result.ok) throw new Error(result.reason);
        pushFriendAccepted(body.receiverUin, body.requesterUin, 'admin_accepted');
        logger({ event: 'admin_friend_accepted', receiverUin: Number(body.receiverUin),
          requesterUin: Number(body.requesterUin) });
        sendJson(response, 200, { ok: true });
        return;
      }
      if (request.method === 'POST' && url.pathname === '/api/friends/reject') {
        const body = await readJson(request);
        const result = store.rejectFriend(body.receiverUin, body.requesterUin);
        if (!result.ok) throw new Error(result.reason);
        logger({ event: 'admin_friend_rejected', receiverUin: Number(body.receiverUin),
          requesterUin: Number(body.requesterUin) });
        sendJson(response, 200, { ok: true });
        return;
      }
      if (request.method === 'POST' && url.pathname === '/api/providers') {
        const body = await readJson(request);
        const existing = body.id ? store.getProvider(body.id) : null;
        const candidate = Object.assign({}, existing || {}, body);
        delete candidate.apiKey;
        if (body.apiKey) candidate.apiKeyProtected = protectSecret(body.apiKey);
        const provider = store.upsertProvider(candidate);
        logger({ event: 'admin_provider_saved', providerId: provider.id });
        sendJson(response, existing ? 200 : 201, { provider: publicProvider(provider) });
        return;
      }
      match = url.pathname.match(/^\/api\/providers\/([^/]+)\/test$/);
      if (request.method === 'POST' && match) {
        const provider = store.getProvider(decodeURIComponent(match[1]));
        if (!provider) throw new Error('provider was not found');
        const body = await readJson(request);
        const result = await completeChat(provider, [
          { role: 'system', content: '只回复“连接成功”。' },
          { role: 'user', content: '测试连接' },
        ], body.apiKey ? { apiKey: body.apiKey } : undefined);
        sendJson(response, 200, { ok: true, reply: result.text, usage: result.usage });
        return;
      }
      match = url.pathname.match(/^\/api\/memory\/(\d+)\/compact$/);
      if (request.method === 'POST' && match) {
        const result = await runtime.compact(Number(match[1]));
        sendJson(response, 200, { result });
        return;
      }
      sendJson(response, 404, { error: 'not_found' });
    } catch (error) {
      logger({ event: 'admin_error', method: request.method, url: request.url, message: error.message });
      if (!response.headersSent) sendJson(response, 400, { error: error.message });
      else response.destroy();
    }
  });
}

module.exports = {
  createAdminServer, publicAccount, publicGroup, publicProvider, readJson,
};
