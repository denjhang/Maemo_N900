@echo off
setlocal
echo ============================================
echo   Symbian/J2ME IM Compatibility Gateway
echo ============================================
echo.
echo Starting the gateway. Keep this window open.
echo.
echo Admin console:  http://127.0.0.1:13980/
echo Stop the gateway: press Ctrl+C in this window.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\run-private-server.ps1" -ListenAddress 0.0.0.0 -MobileAddress 0.0.0.0 -MediaUploadAddress 0.0.0.0 -SkipStartupMemoryCompaction
echo.
echo Gateway stopped.
pause
