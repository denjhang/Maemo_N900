﻿[CmdletBinding()]
param(
    # 统一模式（默认）：同时启动 J2ME 与塞班 QQ2013 所需端口。
    # -UnifiedGateway 开关用于与 统一网关.bat 启动器兼容；本发布版本固定以统一模式运行。
    [switch]$UnifiedGateway,
    [string]$PhoneIp = '',
    [string]$ComputerIp = ''
)

$ErrorActionPreference = 'Stop'

function Test-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-Administrator)) {
    $quotedScript = '"' + $PSCommandPath + '"'
    $arguments = "-NoProfile -ExecutionPolicy Bypass -File $quotedScript"
    if ($PhoneIp) { $arguments += " -PhoneIp $PhoneIp" }
    if ($ComputerIp) { $arguments += " -ComputerIp $ComputerIp" }
    Start-Process -FilePath 'powershell.exe' -ArgumentList $arguments -Verb RunAs
    exit 0
}

$projectRoot = Split-Path -Parent $PSScriptRoot
$gatewayScript = Join-Path $PSScriptRoot 'symbian-gateway-session.js'
$dataFile = Join-Path $projectRoot 'server\data\private-qq.sqlite'
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$outputDirectory = Join-Path $projectRoot "build\unified-gateway\$stamp"
$logFile = Join-Path $outputDirectory 'gateway.jsonl'

# QQ2013 客户端内置或解析出的旧登录节点（均已退役）。桥接模式需要让电脑
# 在环回接口上临时拥有这些地址，才能接住手机发出的第一个连接请求。
$targets = @(
    '120.196.210.13',
    '120.196.210.14',
    '112.90.140.201',
    '112.90.140.202',
    '58.60.10.62',
    '58.60.12.176'
)
$firewallName = "Symbian QQ gateway unified $stamp"
$j2meFirewallName = "J2ME QQ gateway unified $stamp"
$addedAddresses = New-Object System.Collections.Generic.List[string]
$firewallAdded = $false
$j2meFirewallAdded = $false
$physicalIndex = $null
$loopbackIndex = $null
$physicalWeakReceive = $null
$physicalWeakSend = $null
$loopbackWeakReceive = $null
$loopbackWeakSend = $null
$runError = $null

$systemNode = Get-Command node.exe -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $systemNode) {
    throw 'Node.js was not found. Install Node.js LTS (22.5 or newer) from https://nodejs.org/ and try again.'
}

New-Item -ItemType Directory -Force -Path $outputDirectory | Out-Null

try {
    if ([string]::IsNullOrEmpty($ComputerIp)) {
        $configuration = Get-NetIPConfiguration -ErrorAction Stop |
            Where-Object { $_.IPv4DefaultGateway -and $_.NetAdapter.Status -eq 'Up' } |
            Select-Object -First 1
        if (-not $configuration -or -not $configuration.IPv4Address) {
            throw 'Could not detect the computer LAN IPv4 address. Pass -ComputerIp explicitly.'
        }
        $ComputerIp = ($configuration.IPv4Address | Select-Object -First 1).IPAddress
    }
    $computerAddress = Get-NetIPAddress -AddressFamily IPv4 -IPAddress $ComputerIp -ErrorAction Stop |
        Where-Object { $_.AddressState -ne 'Duplicate' } |
        Select-Object -First 1
    if (-not $computerAddress) { throw "Computer address $ComputerIp was not found on any interface." }
    $physicalIndex = $computerAddress.InterfaceIndex
    $loopbackAddress = Get-NetIPAddress -AddressFamily IPv4 -IPAddress '127.0.0.1' -ErrorAction Stop |
        Select-Object -First 1
    if (-not $loopbackAddress) { throw 'Windows IPv4 loopback interface was not found.' }
    $loopbackIndex = $loopbackAddress.InterfaceIndex

    $requiredPorts = @(80, 8080, 14000, 13980, 13981)
    $busy = Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue |
        Where-Object { $_.LocalPort -in $requiredPorts }
    if ($busy) {
        $description = ($busy | ForEach-Object { "$($_.LocalAddress):$($_.LocalPort) PID=$($_.OwningProcess)" }) -join ', '
        throw "A required port is already in use: $description. Close the other gateway window first."
    }

    # 恢复上次异常退出可能遗留的临时配置（只处理本机环回接口上的目标地址）。
    $staleConfiguration = $false
    foreach ($target in $targets) {
        $existingAddresses = @(Get-NetIPAddress -AddressFamily IPv4 -IPAddress $target -ErrorAction SilentlyContinue)
        $foreignAddresses = @($existingAddresses | Where-Object { $_.InterfaceIndex -ne $loopbackIndex })
        if ($foreignAddresses.Count -gt 0) {
            throw "Target address $target exists on a non-loopback interface. It was not changed."
        }
        foreach ($existingAddress in $existingAddresses) {
            Remove-NetIPAddress -InterfaceIndex $loopbackIndex -IPAddress $target `
                -Confirm:$false -ErrorAction Stop
            $staleConfiguration = $true
        }
    }
    if ($staleConfiguration) {
        Get-NetFirewallRule -ErrorAction SilentlyContinue |
            Where-Object { $_.DisplayName -like 'Symbian QQ gateway *' -or
                $_.DisplayName -like 'J2ME QQ gateway *' } |
            Remove-NetFirewallRule -ErrorAction SilentlyContinue
        Set-NetIPInterface -AddressFamily IPv4 -InterfaceIndex $physicalIndex `
            -WeakHostReceive Disabled -WeakHostSend Disabled -PolicyStore ActiveStore `
            -ErrorAction SilentlyContinue
        Set-NetIPInterface -AddressFamily IPv4 -InterfaceIndex $loopbackIndex `
            -WeakHostReceive Disabled -WeakHostSend Disabled -PolicyStore ActiveStore `
            -ErrorAction SilentlyContinue
        Write-Host 'Recovered temporary network settings left by an earlier interrupted run.' -ForegroundColor Yellow
    }

    $physicalInterface = Get-NetIPInterface -AddressFamily IPv4 -InterfaceIndex $physicalIndex
    $loopbackInterface = Get-NetIPInterface -AddressFamily IPv4 -InterfaceIndex $loopbackIndex
    $physicalWeakReceive = [string]$physicalInterface.WeakHostReceive
    $physicalWeakSend = [string]$physicalInterface.WeakHostSend
    $loopbackWeakReceive = [string]$loopbackInterface.WeakHostReceive
    $loopbackWeakSend = [string]$loopbackInterface.WeakHostSend

    Set-NetIPInterface -AddressFamily IPv4 -InterfaceIndex $physicalIndex `
        -WeakHostReceive Enabled -WeakHostSend Enabled -PolicyStore ActiveStore
    Set-NetIPInterface -AddressFamily IPv4 -InterfaceIndex $loopbackIndex `
        -WeakHostReceive Enabled -WeakHostSend Enabled -PolicyStore ActiveStore

    foreach ($target in $targets) {
        $existing = Get-NetIPAddress -AddressFamily IPv4 -IPAddress $target -ErrorAction SilentlyContinue
        if ($existing) { throw "Target address $target is already configured. It was not changed." }
        New-NetIPAddress -InterfaceIndex $loopbackIndex -IPAddress $target -PrefixLength 32 `
            -SkipAsSource $true -PolicyStore ActiveStore | Out-Null
        $addedAddresses.Add($target)
    }

    $remoteScope = if ($PhoneIp) { $PhoneIp } else { 'LocalSubnet' }
    New-NetFirewallRule -DisplayName $firewallName -Direction Inbound -Action Allow `
        -Protocol TCP -LocalPort 8080,14000 -RemoteAddress $remoteScope -Profile Any | Out-Null
    $firewallAdded = $true
    New-NetFirewallRule -DisplayName $j2meFirewallName -Direction Inbound -Action Allow `
        -Protocol TCP -LocalPort 80,14000,13981 -RemoteAddress LocalSubnet -Profile Any | Out-Null
    $j2meFirewallAdded = $true

    Write-Host ''
    Write-Host 'Unified J2ME + Symbian gateway is active.' -ForegroundColor Green
    Write-Host ("Computer gateway address: {0}" -f $ComputerIp)
    if ($PhoneIp) { Write-Host "Phone IP: $PhoneIp" }
    Write-Host 'Management: http://127.0.0.1:13980/'
    Write-Host ("Gateway log: {0}" -f $logFile)
    Write-Host ''
    Write-Host 'Keep the phone Wi-Fi proxy disabled.'
    Write-Host 'Press Enter in this window to stop the gateway and restore all network settings.'
    Write-Host ''

    $sessionArguments = @($gatewayScript, '--output', $logFile, '--data', $dataFile, '--unified')
    & node @sessionArguments
    if ($LASTEXITCODE -ne 0) { throw "Gateway exited with code $LASTEXITCODE." }
} catch {
    $runError = $_
} finally {
    if ($firewallAdded) {
        Remove-NetFirewallRule -DisplayName $firewallName -ErrorAction SilentlyContinue
    }
    if ($j2meFirewallAdded) {
        Remove-NetFirewallRule -DisplayName $j2meFirewallName -ErrorAction SilentlyContinue
    }
    foreach ($target in $addedAddresses) {
        Remove-NetIPAddress -InterfaceIndex $loopbackIndex -IPAddress $target `
            -Confirm:$false -ErrorAction SilentlyContinue
    }
    if ($physicalIndex -and $physicalWeakReceive -and $physicalWeakSend) {
        Set-NetIPInterface -AddressFamily IPv4 -InterfaceIndex $physicalIndex `
            -WeakHostReceive $physicalWeakReceive -WeakHostSend $physicalWeakSend `
            -PolicyStore ActiveStore -ErrorAction SilentlyContinue
    }
    if ($loopbackIndex -and $loopbackWeakReceive -and $loopbackWeakSend) {
        Set-NetIPInterface -AddressFamily IPv4 -InterfaceIndex $loopbackIndex `
            -WeakHostReceive $loopbackWeakReceive -WeakHostSend $loopbackWeakSend `
            -PolicyStore ActiveStore -ErrorAction SilentlyContinue
    }
    Write-Host ''
    Write-Host 'Temporary routing, weak-host settings, and firewall rules were removed.'
}

if ($runError) {
    Write-Host ''
    Write-Host ("Unified gateway failed: {0}" -f $runError.Exception.Message) -ForegroundColor Red
    Read-Host 'Press Enter to close'
    exit 1
}
Read-Host 'Press Enter to close'
