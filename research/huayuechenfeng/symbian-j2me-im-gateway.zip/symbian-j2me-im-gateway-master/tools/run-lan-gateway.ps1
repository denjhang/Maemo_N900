[CmdletBinding()]
param(
    [int]$Port = 14000,
    [string]$DataFile = '',
    [switch]$TraceProtocol,
    [switch]$SkipStartupMemoryCompaction
)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
if ([string]::IsNullOrEmpty($DataFile)) {
$DataFile = Join-Path $projectRoot 'server\data\private-qq.sqlite'
}
$addresses = [System.Net.Dns]::GetHostAddresses([System.Net.Dns]::GetHostName()) |
    Where-Object { $_.AddressFamily -eq [System.Net.Sockets.AddressFamily]::InterNetwork -and
        -not [System.Net.IPAddress]::IsLoopback($_) } |
    ForEach-Object { $_.IPAddressToString }
Write-Warning 'This listens on every network interface. Allow TCP 14000 only on trusted/private LAN profiles.'
Write-Output ('Candidate LAN addresses: ' + ($addresses -join ', '))
Write-Output "Gateway port: $Port"
Write-Output 'Management: http://127.0.0.1:13980/ (local computer only)'
Write-Output 'Mobile groups: http://<computer-ip>:13981/mobile/groups'
Write-Output 'Legacy image/voice upload: http://<computer-ip>:80/'
& (Join-Path $PSScriptRoot 'run-private-server.ps1') -ListenAddress '0.0.0.0' `
    -Port $Port -DataFile $DataFile -TraceProtocol:$TraceProtocol `
    -MobileAddress '0.0.0.0' -MobilePort 13981 `
    -MediaUploadAddress '0.0.0.0' -MediaUploadPort 80 `
    -SkipStartupMemoryCompaction:$SkipStartupMemoryCompaction
exit $LASTEXITCODE
