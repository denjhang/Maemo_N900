[CmdletBinding()]
param(
    [ValidateSet('List', 'Add', 'ResetPassword')]
    [string]$Action = 'List',
    [long]$Uin = 0,
    [string]$Nickname = '',
    [string]$Password = '',
    [string]$DataFile = '',
    [string]$J2meLlmRoot = ''
)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
if ([string]::IsNullOrEmpty($DataFile)) {
$DataFile = Join-Path $projectRoot 'server\data\private-qq.sqlite'
}
$systemNode = Get-Command node.exe -ErrorAction SilentlyContinue | Select-Object -First 1
$node = if ($systemNode) { $systemNode.Source } else { $null }
if ([string]::IsNullOrEmpty($node)) {
    throw 'Node.js was not found. Install Node.js LTS (22.5 or newer) from https://nodejs.org/ and try again.'
}
$manager = Join-Path $projectRoot 'server\manage-accounts.js'
if ($Action -eq 'List') {
    & $node $manager --data $DataFile list
    exit $LASTEXITCODE
}
if ($Uin -le 0) { throw 'Uin is required.' }
if ([string]::IsNullOrEmpty($Password)) {
    $secure = Read-Host 'Private-server password' -AsSecureString
    $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try { $Password = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
}
if ($Action -eq 'Add') {
    if ([string]::IsNullOrEmpty($Nickname)) { $Nickname = [string]$Uin }
    & $node $manager --data $DataFile add ([string]$Uin) $Nickname $Password
} else {
    & $node $manager --data $DataFile reset-password ([string]$Uin) $Password
}
exit $LASTEXITCODE
