[CmdletBinding()]
param(
    [string]$ListenAddress = '127.0.0.1',
    [int]$Port = 14000,
    [string]$DataFile = '',
    [switch]$TraceProtocol,
    [string]$AdminAddress = '127.0.0.1',
    [int]$AdminPort = 13980,
    [string]$MobileAddress = '127.0.0.1',
    [int]$MobilePort = 13981,
    [string]$MediaUploadAddress = '127.0.0.1',
    [int]$MediaUploadPort = 80,
    [switch]$SkipStartupMemoryCompaction,
    [string]$J2meLlmRoot = ''
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$projectRoot = Split-Path -Parent $PSScriptRoot
$systemNode = Get-Command node.exe -ErrorAction SilentlyContinue | Select-Object -First 1
$node = if ($systemNode) { $systemNode.Source } else { $null }
if ([string]::IsNullOrEmpty($node)) {
    throw 'Node.js was not found. Install Node.js LTS (22.5 or newer) from https://nodejs.org/ and try again.'
}
if ([string]::IsNullOrEmpty($DataFile)) {
$DataFile = Join-Path $projectRoot 'server\data\private-qq.sqlite'
}

Write-Warning 'Use only private-server accounts. Never enter a real Tencent QQ password.'
Write-Output "Accounts: $DataFile"
Write-Output "Admin: http://${AdminAddress}:$AdminPort/"
Write-Output "Mobile groups: http://${MobileAddress}:$MobilePort/mobile/groups"
Write-Output "Legacy media upload: http://${MediaUploadAddress}:$MediaUploadPort/"
& $node (Join-Path $projectRoot 'server\gateway.js') `
    --host $ListenAddress --port $Port --data $DataFile `
    --trace-protocol ([string][bool]$TraceProtocol) `
    --admin-host $AdminAddress --admin-port $AdminPort `
    --mobile-host $MobileAddress --mobile-port $MobilePort `
    --media-upload-host $MediaUploadAddress --media-upload-port $MediaUploadPort `
    --compact-memory-on-start ([string](-not [bool]$SkipStartupMemoryCompaction))
exit $LASTEXITCODE
