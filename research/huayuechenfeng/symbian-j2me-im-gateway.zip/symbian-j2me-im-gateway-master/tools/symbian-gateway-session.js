'use strict';

const fs = require('node:fs');
const net = require('node:net');
const path = require('node:path');
const readline = require('node:readline');
const { close, createGateway, listen, parseArguments } = require('../server/gateway');

function argument(name, fallback) {
  const index = process.argv.indexOf(name);
  return index >= 0 && process.argv[index + 1] ? process.argv[index + 1] : fallback;
}

const outputFile = path.resolve(argument('--output', 'symbian-gateway.jsonl'));
const background = process.argv.includes('--background');
const quiet = process.argv.includes('--quiet');
const unified = process.argv.includes('--unified');
const dataFile = path.resolve(argument(
  '--data', path.join(__dirname, '..', 'server', 'data', 'private-qq.sqlite'),
));
fs.mkdirSync(path.dirname(outputFile), { recursive: true });

function logger(event) {
  const record = Object.assign({ time: new Date().toISOString() }, event);
  fs.appendFileSync(outputFile, `${JSON.stringify(record)}\n`);
  const fields = [];
  for (const name of ['peer', 'command', 'uin', 'reason', 'message']) {
    if (record[name] !== undefined) fields.push(`${name}=${record[name]}`);
  }
  if (!quiet) {
    process.stdout.write(`[${record.time}] ${record.event}${fields.length ? ` ${fields.join(' ')}` : ''}\n`);
  }
}

const options = parseArguments([
  '--host', '0.0.0.0',
  '--port', '14000',
  '--data', dataFile,
  '--trace-protocol', 'True',
  '--auto-accept-friends', 'True',
  '--admin-host', '127.0.0.1',
  // The unified launcher exposes the normal local management console. The
  // temporary capture workflow keeps using an ephemeral port.
  '--admin-port', unified ? '13980' : '0',
  '--mobile-host', unified ? '0.0.0.0' : '127.0.0.1',
  '--mobile-port', unified ? '13981' : '0',
  '--media-upload-host', unified ? '0.0.0.0' : '127.0.0.1',
  '--media-upload-port', unified ? '80' : '0',
  '--compact-memory-on-start', 'False',
], process.env);
options.logger = logger;
// If the client follows the address returned by login, keep it on an address
// temporarily owned by the PC instead of sending it to the phone's loopback.
options.loginIp = Buffer.from([120, 196, 210, 14]);

const gateway = createGateway(options);
const bridgeSockets = new Set();
let bridge = null;
let stopping = false;

async function shutdown(exitCode) {
  if (stopping) return;
  stopping = true;
  logger({ event: 'symbian_gateway_shutdown' });
  for (const socket of bridgeSockets) socket.destroy();
  if (bridge) await new Promise((resolve) => bridge.close(resolve));
  await close(gateway);
  process.exit(exitCode || 0);
}

async function main() {
  await listen(gateway, options);
  bridge = net.createServer((phoneSocket) => {
    const peer = `${phoneSocket.remoteAddress}:${phoneSocket.remotePort}`;
    const gatewaySocket = net.connect(14000, '127.0.0.1');
    bridgeSockets.add(phoneSocket);
    bridgeSockets.add(gatewaySocket);
    phoneSocket.setNoDelay(true);
    gatewaySocket.setNoDelay(true);
    logger({ event: 'port_8080_bridge_connection', peer });

    phoneSocket.pipe(gatewaySocket);
    gatewaySocket.pipe(phoneSocket);

    const dispose = () => {
      bridgeSockets.delete(phoneSocket);
      bridgeSockets.delete(gatewaySocket);
    };
    phoneSocket.on('close', dispose);
    gatewaySocket.on('close', dispose);
    phoneSocket.on('error', (error) => {
      logger({ event: 'port_8080_phone_error', peer, message: error.message });
      gatewaySocket.destroy();
    });
    gatewaySocket.on('error', (error) => {
      logger({ event: 'port_8080_gateway_error', peer, message: error.message });
      phoneSocket.destroy();
    });
  });
  await new Promise((resolve, reject) => {
    bridge.once('error', reject);
    bridge.listen(8080, '0.0.0.0', resolve);
  });
  logger({
    event: unified ? 'unified_gateway_ready' : 'symbian_gateway_ready',
    ports: unified ? [80, 8080, 14000, 13980, 13981] : [8080, 14000], outputFile,
  });

  if (background) {
    logger({ event: 'symbian_gateway_background_wait' });
    return;
  }

  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  const prompt = unified
    ? '\nUnified gateway is running. Press Enter to stop it and restore network settings.\n'
    : '\nUse test account 10001 / qqtest123. Try login and wait 45 seconds, then press Enter.\n';
  rl.question(prompt, () => {
      rl.close();
      shutdown(0).catch((error) => {
        process.stderr.write(`${error.stack || error.message}\n`);
        process.exit(1);
      });
    });
}

main().catch((error) => {
  logger({ event: 'symbian_gateway_failed', message: error.message });
  shutdown(1).catch(() => process.exit(1));
});
process.on('SIGINT', () => shutdown(0));
process.on('SIGTERM', () => shutdown(0));
