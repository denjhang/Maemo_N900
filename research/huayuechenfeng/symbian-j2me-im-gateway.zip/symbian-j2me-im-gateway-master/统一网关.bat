@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\run-symbian-gateway.ps1" -UnifiedGateway
if errorlevel 1 pause
