#pragma once

void PrintBacktraceToStderr();
